
import React, { useState, useCallback } from 'react';
import type { ClientProfile, LifecycleStage, FinancialItem, UploadedFile } from './types';
import { Status } from './types';
import Header from './components/Header';
import LifecycleTracker from './components/LifecycleTracker';
import FinancialOverview from './components/FinancialOverview';
import DocumentManager from './components/DocumentManager';
import ScaffolderAI from './components/ScaffolderAI';
import TWCForms from './components/TWCForms';

// This is needed because jspdf and html2canvas are loaded from script tags
declare const jspdf: any;
declare const html2canvas: any;

const MOCK_CLIENT_PROFILE: ClientProfile = {
  name: 'Jane Doe',
  businessName: 'Creative Signs & Designs',
};

const MOCK_LIFECYCLE_STAGES: LifecycleStage[] = [
  {
    id: 'idea',
    name: '1. Idea',
    vrTasks: [
      { id: 'vr1', name: 'Initial Consultation', status: Status.Completed, description: 'Discussed business concept and eligibility.' },
      { id: 'vr2', name: 'Career Counseling', status: Status.Completed, description: 'Explored entrepreneurial skills and interests.' },
      { id: 'vr3', name: 'Benefits Counseling', status: Status.InProgress, description: 'Reviewing impact of business income on benefits.' },
    ],
    workforceTasks: [
      { id: 'wf1', name: 'Market Research Workshop', status: Status.Completed, description: 'Attended local SBDC workshop.' },
      { id: 'wf2', name: 'Feasibility Study', status: Status.InProgress, description: 'Analyzing market viability and competition.' },
    ],
  },
  {
    id: 'build',
    name: '2. Build',
    vrTasks: [
      { id: 'vr4', name: 'Business Plan Development', status: Status.InProgress, description: 'Drafting core sections of the business plan.' },
      { id: 'vr5', name: 'Assistive Technology Assessment', status: Status.NotStarted, description: 'To determine necessary workplace accommodations.' },
    ],
    workforceTasks: [
      { id: 'wf3', name: 'Legal Structure Advising', status: Status.Completed, description: 'Consulted with Legal Aid for LLC setup.' },
      { id: 'wf4', name: 'Register Business Name', status: Status.NotStarted, description: 'DBA registration with the county.' },
    ],
  },
   {
    id: 'grow',
    name: '3. Grow',
    vrTasks: [
      { id: 'vr6', name: 'Marketing Materials Assistance', status: Status.NotStarted, description: 'Funding for initial print and web materials.' },
    ],
    workforceTasks: [
      { id: 'wf5', name: 'Develop Marketing Strategy', status: Status.NotStarted, description: 'Plan for reaching initial customer base.' },
      { id: 'wf6', name: 'Networking Event Attendance', status: Status.NotStarted, description: 'Connect with other local business owners.' },
    ],
  },
  {
    id: 'manage',
    name: '4. Manage',
    vrTasks: [
      { id: 'vr7', name: 'Post-launch Support', status: Status.NotStarted, description: 'Scheduled check-ins for the first 6 months.' },
    ],
    workforceTasks: [
      { id: 'wf7', name: 'Financial Literacy Training', status: Status.NotStarted, description: 'Bookkeeping and cash flow management.' },
      { id: 'wf8', name: 'Hiring Assistance', status: Status.NotStarted, description: 'Resources for finding and hiring first employee.' },
    ],
  },
];

const MOCK_FINANCIAL_ITEMS: FinancialItem[] = [
  { id: 'f1', name: 'TWC Grant (Startup Costs)', amount: 5000, type: 'Income', status: 'Approved' },
  { id: 'f2', name: 'Personal Investment', amount: 1500, type: 'Income', status: 'Paid' },
  { id: 'f3', name: 'Business License Fee', amount: 75, type: 'Expense', status: 'Paid' },
  { id: 'f4', name: 'Software Subscription', amount: 250, type: 'Expense', status: 'Pending' },
];

const App: React.FC = () => {
  const [clientProfile] = useState<ClientProfile>(MOCK_CLIENT_PROFILE);
  const [stages] = useState<LifecycleStage[]>(MOCK_LIFECYCLE_STAGES);
  const [financialItems] = useState<FinancialItem[]>(MOCK_FINANCIAL_ITEMS);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  const handleFileUpload = useCallback((files: FileList) => {
    const newFiles: UploadedFile[] = Array.from(files).map(file => ({
      id: `${file.name}-${Date.now()}`,
      name: file.name,
      size: file.size,
      type: file.type,
    }));
    setUploadedFiles(prev => [...prev, ...newFiles]);
  }, []);
  
  const handleDownloadPDF = async () => {
    const overviewElement = document.getElementById('progress-overview');
    if (!overviewElement) return;

    try {
      // Use html2canvas to render the element to a canvas
      const canvas = await html2canvas(overviewElement, {
          scale: 2, // Higher scale for better quality
          useCORS: true,
      });
      
      const imgData = canvas.toDataURL('image/png');
      
      // Use jspdf to create and save the PDF
      // eslint-disable-next-line new-cap
      const pdf = new jspdf.jsPDF({
          orientation: 'p',
          unit: 'px',
          format: [canvas.width, canvas.height]
      });
      
      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`${clientProfile.name.replace(' ', '_')}_Progress_Overview.pdf`);
    } catch (error) {
        console.error("Error generating PDF:", error);
    }
  };


  return (
    <div className="min-h-screen bg-gray-50">
      <Header clientProfile={clientProfile} />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          <div id="progress-overview" className="lg:col-span-2 space-y-8 bg-gray-50 p-1">
             <LifecycleTracker stages={stages} />
             <FinancialOverview items={financialItems} files={uploadedFiles} onFileUpload={handleFileUpload} />
          </div>

          <aside className="space-y-6">
            <ScaffolderAI />
            <DocumentManager files={uploadedFiles} onDownloadPDF={handleDownloadPDF} />
            <TWCForms />
          </aside>

        </div>
      </main>
    </div>
  );
};

export default App;
