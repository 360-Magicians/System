
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export async function* generateScaffoldingText(prompt: string): AsyncGenerator<string> {
  if (!process.env.API_KEY) {
    yield "Error: API key is not configured. Please set the API_KEY environment variable.";
    return;
  }
  
  try {
    const response = await ai.models.generateContentStream({
      model: "gemini-2.5-flash",
      contents: `You are a helpful assistant for a vocational rehabilitation specialist. Based on the following prompt, generate a concise, professional, and helpful response that can be used in a client's progress report. Prompt: "${prompt}"`,
    });

    for await (const chunk of response) {
      yield chunk.text;
    }
  } catch (error) {
    console.error("Error generating content from Gemini:", error);
    yield `An error occurred while generating the text. Please check the console for details.`;
  }
}
