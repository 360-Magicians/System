
import React from 'react';
import { Card } from './ui/Card';
import { ExternalLinkIcon } from './ui/Icons';

const forms = [
  { name: 'VR Business Plan Forms', url: 'https://www.twc.texas.gov/programs/vocational-rehabilitation/forms#business-plan-forms' },
  { name: 'VR General Forms', url: 'https://www.twc.texas.gov/programs/vocational-rehabilitation/forms#general-forms' },
  { name: 'Workforce Training Grants', url: 'https://www.twc.texas.gov/sites/default/files/oei/docs/workforce-training-grant-opportunities-twc.pdf' },
  { name: 'VR Standards for Providers', url: 'https://www.twc.texas.gov/business-employers/vocational-rehabilitation-providers' },
];

const TWCForms: React.FC = () => {
  return (
    <Card>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">TWC Resources</h3>
      <ul className="space-y-3">
        {forms.map(form => (
          <li key={form.name}>
            <a
              href={form.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex justify-between items-center text-sm font-medium text-indigo-600 hover:text-indigo-800 hover:underline"
            >
              <span>{form.name}</span>
              <ExternalLinkIcon className="h-4 w-4" />
            </a>
          </li>
        ))}
      </ul>
    </Card>
  );
};

export default TWCForms;
