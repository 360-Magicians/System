
import React, { useState } from 'react';
import type { UploadedFile } from '../types';
import { Card } from './ui/Card';
import { DocumentIcon } from './ui/Icons';

// This is needed because jspdf is loaded from a script tag in index.html
declare const jspdf: any;

interface DocumentManagerProps {
  files: UploadedFile[];
  onDownloadPDF: () => Promise<void>;
}

const DocumentManager: React.FC<DocumentManagerProps> = ({ files, onDownloadPDF }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  
  const handleDownload = async () => {
    setIsDownloading(true);
    await onDownloadPDF();
    setIsDownloading(false);
  };

  const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  };

  return (
    <Card>
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Document Center</h3>
      <button
        onClick={handleDownload}
        disabled={isDownloading}
        className="w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300 disabled:cursor-not-allowed"
      >
        {isDownloading ? 'Generating PDF...' : 'Download Overview as PDF'}
      </button>
      <div className="mt-6">
        <h4 className="text-md font-medium text-gray-700 mb-2">Uploaded Files</h4>
        {files.length > 0 ? (
          <ul className="space-y-2">
            {files.map(file => (
              <li key={file.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                <div className="flex items-center space-x-3">
                  <DocumentIcon className="h-6 w-6 text-gray-400" />
                  <div>
                    <p className="text-sm font-medium text-gray-800 truncate" style={{maxWidth: '150px'}}>{file.name}</p>
                    <p className="text-xs text-gray-500">{formatBytes(file.size)}</p>
                  </div>
                </div>
                <button className="text-indigo-600 hover:text-indigo-800 text-sm font-medium">View</button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-gray-500 text-center py-4">No files uploaded yet.</p>
        )}
      </div>
    </Card>
  );
};

export default DocumentManager;
