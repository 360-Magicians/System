
import React, { useState } from 'react';
import { generateScaffoldingText } from '../services/geminiService';
import { Card } from './ui/Card';
import { SparklesIcon } from './ui/Icons';

const ScaffolderAI: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedText, setGeneratedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    setGeneratedText('');

    try {
      const stream = generateScaffoldingText(prompt);
      for await (const chunk of stream) {
        setGeneratedText((prev) => prev + chunk);
      }
    } catch (error) {
      console.error("Scaffolding failed:", error);
      setGeneratedText("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCopy = () => {
    navigator.clipboard.writeText(generatedText);
  };

  return (
    <Card>
      <div className="flex items-center space-x-2 mb-4">
        <SparklesIcon className="h-6 w-6 text-indigo-500" />
        <h3 className="text-lg font-semibold text-gray-800">AI Scaffolder</h3>
      </div>
      <p className="text-sm text-gray-500 mb-4">Need help drafting a note or summary? Describe what you need, and the AI will help you write it.</p>
      
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="e.g., 'Write a brief progress update for a client who has completed their business plan.'"
        className="w-full h-24 p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500 text-sm"
        disabled={isLoading}
      />
      
      <button
        onClick={handleGenerate}
        disabled={isLoading}
        className="mt-2 w-full inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-300"
      >
        {isLoading ? 'Generating...' : 'Generate Text'}
      </button>

      {generatedText && (
        <div className="mt-4 p-4 bg-gray-50 rounded-md border border-gray-200 relative">
          <h4 className="text-sm font-semibold text-gray-700 mb-2">Generated Content</h4>
          <p className="text-sm text-gray-800 whitespace-pre-wrap">{generatedText}</p>
          <button 
            onClick={handleCopy}
            className="absolute top-2 right-2 text-xs bg-gray-200 text-gray-700 hover:bg-gray-300 px-2 py-1 rounded"
          >
            Copy
          </button>
        </div>
      )}
    </Card>
  );
};

export default ScaffolderAI;
