import React, { useState } from 'react';
// FIX: 'Status' is an enum used as a value, so it cannot be a type-only import.
import { type LifecycleStage, type Task, Status } from '../types';
import { Card } from './ui/Card';
import { CheckCircleIcon, ClockIcon, DocumentIcon, XCircleIcon, ChevronDownIcon } from './ui/Icons';

const statusMap: { [key in Status]: { icon: React.ReactNode; color: string } } = {
  [Status.Completed]: { icon: <CheckCircleIcon className="h-5 w-5" />, color: 'text-green-500' },
  [Status.InProgress]: { icon: <ClockIcon className="h-5 w-5" />, color: 'text-blue-500' },
  [Status.NotStarted]: { icon: <DocumentIcon className="h-5 w-5" />, color: 'text-gray-400' },
  [Status.Blocked]: { icon: <XCircleIcon className="h-5 w-5" />, color: 'text-red-500' },
};

const TaskItem: React.FC<{ task: Task }> = ({ task }) => {
  const { icon, color } = statusMap[task.status];
  return (
    <div className="flex items-start space-x-3 py-3 border-b border-gray-100 last:border-b-0">
      <div className={`mt-1 ${color}`}>{icon}</div>
      <div>
        <p className="font-medium text-gray-700">{task.name}</p>
        <p className="text-sm text-gray-500">{task.description}</p>
      </div>
    </div>
  );
};

const Stage: React.FC<{ stage: LifecycleStage; initiallyOpen?: boolean }> = ({ stage, initiallyOpen = false }) => {
  const [isOpen, setIsOpen] = useState(initiallyOpen);
  const totalTasks = stage.vrTasks.length + stage.workforceTasks.length;
  const completedTasks = [...stage.vrTasks, ...stage.workforceTasks].filter(t => t.status === Status.Completed).length;
  const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  return (
    <Card className="mb-4">
      <div className="cursor-pointer" onClick={() => setIsOpen(!isOpen)}>
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-semibold text-gray-800">{stage.name}</h3>
          <div className="flex items-center space-x-4">
            <div className="w-48 bg-gray-200 rounded-full h-2.5">
              <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
            </div>
            <span className="text-sm font-medium text-gray-600">{progress}%</span>
            <ChevronDownIcon className={`h-6 w-6 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </div>
        </div>
      </div>
      {isOpen && (
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h4 className="font-semibold text-gray-700 border-b pb-2 mb-2">Vocational Rehabilitation Lifecycle</h4>
            <div>
              {stage.vrTasks.map(task => <TaskItem key={task.id} task={task} />)}
            </div>
          </div>
          <div>
            <h4 className="font-semibold text-gray-700 border-b pb-2 mb-2">Workforce Solutions Lifecycle</h4>
            <div>
              {stage.workforceTasks.map(task => <TaskItem key={task.id} task={task} />)}
            </div>
          </div>
        </div>
      )}
    </Card>
  );
};

interface LifecycleTrackerProps {
  stages: LifecycleStage[];
}

const LifecycleTracker: React.FC<LifecycleTrackerProps> = ({ stages }) => {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Client Progress Lifecycle</h2>
      {stages.map((stage, index) => (
        <Stage key={stage.id} stage={stage} initiallyOpen={index === 0} />
      ))}
    </div>
  );
};

export default LifecycleTracker;