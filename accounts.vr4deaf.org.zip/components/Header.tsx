
import React from 'react';
import type { ClientProfile } from '../types';

interface HeaderProps {
  clientProfile: ClientProfile;
}

const Header: React.FC<HeaderProps> = ({ clientProfile }) => {
  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="bg-indigo-600 text-white font-bold rounded-full h-12 w-12 flex items-center justify-center text-xl">
            VR
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">{clientProfile.name}</h1>
            <p className="text-sm text-gray-500">{clientProfile.businessName}</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
            <img src="https://vr4deaf.org/wp-content/uploads/2023/12/VR4Deaf-Logo-with-Text-Below.png" alt="VR4Deaf Logo" className="h-12"/>
        </div>
      </div>
    </header>
  );
};

export default Header;
