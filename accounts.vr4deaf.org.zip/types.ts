
export enum Status {
  Completed = 'Completed',
  InProgress = 'In Progress',
  NotStarted = 'Not Started',
  Blocked = 'Blocked',
}

export interface Task {
  id: string;
  name: string;
  status: Status;
  description: string;
}

export interface LifecycleStage {
  id: string;
  name: string;
  vrTasks: Task[];
  workforceTasks: Task[];
}

export interface FinancialItem {
  id: string;
  name: string;
  amount: number;
  type: 'Income' | 'Expense';
  status: 'Pending' | 'Approved' | 'Paid';
}

export interface UploadedFile {
  id: string;
  name: string;
  size: number; // in bytes
  type: string;
}

export interface ClientProfile {
  name: string;
  businessName: string;
}
