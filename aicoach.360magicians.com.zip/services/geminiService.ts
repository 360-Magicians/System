// Fix: The `Pathway` enum is a local type and should be imported from `../types`.
import { GoogleGenAI, Chat } from "@google/genai";
import { ChatMessage, Pathway } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const generateContent = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating content:", error);
    return "Sorry, I encountered an error. Please try again.";
  }
};

export const startChat = (pathway: Pathway, history: ChatMessage[]): Chat => {
    const systemInstruction = pathway === Pathway.JOB 
        ? "You are a friendly and encouraging AI career coach for Deaf and hard-of-hearing job seekers. Keep your responses concise, actionable, and supportive. Use emojis where appropriate to convey a warm tone."
        : "You are a sharp and insightful AI business coach for Deaf and hard-of-hearing entrepreneurs. Provide clear, strategic, and practical advice. Be professional yet approachable.";

    return ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction,
        },
        history,
    });
};

export const generateInterviewQuestions = async (jobDescription: string, resume: string): Promise<string> => {
  const prompt = `
    As an expert career coach for Deaf and hard-of-hearing professionals, generate a list of 10-15 insightful interview questions based on the following job description and resume.
    The questions should cover technical skills, behavioral situations, and cultural fit.
    Also, include 2-3 questions the candidate could ask the interviewer, focusing on accessibility and inclusive company culture.

    Job Description:
    ---
    ${jobDescription}
    ---

    Candidate's Resume:
    ---
    ${resume}
    ---

    Format the output clearly with headings for each section.
  `;
  return generateContent(prompt);
};

export const refineResume = async (jobDescription: string, resume: string): Promise<string> => {
  const prompt = `
    Act as a professional resume writer specializing in helping Deaf professionals.
    Review the provided resume against the job description and give specific, actionable feedback for improvement.
    Focus on:
    1.  Keywords from the job description to include.
    2.  Quantifying achievements with numbers.
    3.  Strengthening the summary statement.
    4.  Highlighting skills relevant to the role.

    Provide the feedback in a clear, bulleted list.

    Job Description:
    ---
    ${jobDescription}
    ---

    Current Resume:
    ---
    ${resume}
    ---
  `;
  return generateContent(prompt);
};

export const getResumeFeedback = async (jobDescription: string, resume: string): Promise<string> => {
  const prompt = `
    As an expert AI career coach, provide specific, actionable feedback to improve the following resume based on the provided job description. Structure your feedback into three distinct sections with markdown formatting:

    ### 🎯 Keyword Alignment
    - List crucial keywords from the job description that are missing or underutilized in the resume.
    - Suggest specific phrases or sentences where these keywords can be naturally integrated.

    ### 📈 Quantifiable Achievements
    - Identify 2-3 bullet points from the resume that could be strengthened with metrics.
    - Provide examples of how to rewrite them using numbers, percentages, or other quantifiable data (e.g., "Managed a team" could become "Led a team of 5 to increase project completion rate by 15%").

    ### ✨ Relevant Skills Spotlight
    - Pinpoint the most critical skills mentioned in the job description.
    - Advise on how to better highlight these skills in the resume, perhaps in a summary section or by reordering bullet points.

    Job Description:
    ---
    ${jobDescription}
    ---

    Candidate's Resume:
    ---
    ${resume}
    ---
  `;
  return generateContent(prompt);
};

export const getSoftSkillsAdvice = async (topic: string): Promise<string> => {
  const prompt = `
    Provide practical advice for a Deaf or hard-of-hearing professional on the topic of "${topic}".
    The advice should be concise, actionable, and address potential communication challenges in the workplace.
    Topics could include professional communication, workplace etiquette, networking, or teamwork.
    Present the advice as a list of tips.
  `;
  return generateContent(prompt);
};

export const generateAslGloss = async (text: string): Promise<string> => {
    const prompt = `
    You are an expert in American Sign Language (ASL). Convert the following English text into ASL gloss.
    Use standard glossing conventions:
    - ALL CAPS for signs.
    - Hyphens for single concepts represented by multiple English words (e.g., LOOK-UP).
    - "+" for compound signs (e.g., FATHER+MOTHER for PARENTS).
    - fs- for fingerspelled words (e.g., fs-JOHN).
    - Use classifiers (CL:) where appropriate.
    - Indicate non-manual signals (NMS) on a line above the gloss (e.g., eyebrows up for wh-questions).

    Your response should contain ONLY the ASL gloss.

    English text to convert:
    ---
    "${text}"
    ---
  `;
  return generateContent(prompt);
};

export const getMotivation = async (): Promise<string> => {
    const prompt = `
        Provide an encouraging and motivational quote or short message for a Deaf job seeker or entrepreneur who might be feeling discouraged.
        Keep it concise and powerful.
    `;
    return generateContent(prompt);
};


export const breakDownBusinessGoal = async (goal: string): Promise<string> => {
  const prompt = `
    As a business coach for Deaf entrepreneurs, take the following high-level business goal and break it down into smaller, manageable weekly tasks for the next 4 weeks.

    Business Goal: "${goal}"

    Present the output in a structured format, like:
    Week 1:
    - Task 1
    - Task 2
    Week 2:
    - Task 1
    - Task 2
    ...and so on.
  `;
  return generateContent(prompt);
};

export const generatePracticalAdvice = async (task: string, details: string): Promise<string> => {
  const prompt = `
    Act as a hands-on business consultant for a Deaf entrepreneur.
    Generate practical content for the following task:

    Task: ${task}
    Details: ${details}

    For example, if the task is "Draft a social media post", generate a compelling post. If it's "Outline a sales pitch", create a structured pitch.
    Ensure the output is ready to be used.
  `;
  return generateContent(prompt);
};


export const findBusinessResources = async (businessType: string): Promise<string> => {
  const prompt = `
    Identify and list valuable online resources, communities, or workshops for a Deaf entrepreneur starting a business in the "${businessType}" sector.
    Include links where possible and a brief description of why each resource is helpful. Focus on resources that are known to be accessible or are specifically for underrepresented founders.
  `;
  return generateContent(prompt);
};

export const transcribeSignLanguage = async (frames: string[]): Promise<string> => {
  if (frames.length === 0) {
    return "No frames were provided for transcription.";
  }

  const imageParts = frames.map(frameData => ({
    inlineData: {
      mimeType: 'image/jpeg',
      data: frameData,
    },
  }));

  const textPart = {
    text: `You are an expert in American Sign Language (ASL). The following is a sequence of images showing a person signing. Transcribe the sign language into English text. Provide only the transcribed text as your response.`
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { 
        parts: [
          textPart,
          ...imageParts
        ],
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error transcribing sign language:", error);
    throw new Error("Failed to transcribe sign language.");
  }
};