import React, { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { CoachDashboard } from './components/CoachDashboard';
import { AuthMethod, UserProfile } from './types';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  const handleLogin = (authMethod: AuthMethod) => {
    setUserProfile({ authMethod });
    setIsAuthenticated(true);
  };
  
  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserProfile(null);
  };

  return (
    <div className="min-h-screen w-full">
      {isAuthenticated && userProfile ? (
        <CoachDashboard onLogout={handleLogout} userProfile={userProfile} />
      ) : (
        <LoginScreen onLogin={handleLogin} />
      )}
    </div>
  );
}

export default App;