import React, { useState, useEffect, useRef, FormEvent } from 'react';
import type { Chat } from '@google/genai';
import { Pathway, ChatMessage } from '../types';
import { startChat, generateAslGloss } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { SendIcon } from './icons/SendIcon';
import { Spinner } from './common/Spinner';
import { SignLanguageIcon } from './icons/SignLanguageIcon';
import { SignLanguageModal } from './SignLanguageModal';
import { VideoIcon } from './icons/VideoIcon';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { LanguageIcon } from './icons/LanguageIcon';

interface AICommandBarProps {
    pathway: Pathway;
    onPlayAsl: (message: string) => void;
}

export const AICommandBar: React.FC<AICommandBarProps> = ({ pathway, onPlayAsl }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSignModalOpen, setIsSignModalOpen] = useState(false);
    const [chat, setChat] = useState<Chat | null>(null);
    const [isHistoryOpen, setIsHistoryOpen] = useState(false);
    const chatContainerRef = useRef<HTMLDivElement>(null);
    
    const chatHistoryRef = useRef<Record<Pathway, ChatMessage[]>>({
        [Pathway.JOB]: [],
        [Pathway.BUSINESS]: [],
    });
    const chatInstanceId = useRef(0);

    // Sync state to ref
    useEffect(() => {
        chatHistoryRef.current[pathway] = messages;
    }, [messages, pathway]);
    
    // Sync ref to state on pathway change
    useEffect(() => {
        chatInstanceId.current += 1; // Invalidate previous async operations
        const currentHistory = chatHistoryRef.current[pathway];
        setMessages(currentHistory);
        setChat(startChat(pathway, currentHistory));
    }, [pathway]);

    // Scroll to bottom
    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [messages]);

    const handleTranscription = (text: string) => {
        setInput(text);
        setIsSignModalOpen(false);
    };

    const sendMessage = async (messageText: string) => {
        if (!messageText.trim() || isLoading || !chat) return;
        
        const callInstanceId = chatInstanceId.current;
        
        setIsHistoryOpen(true);
        setIsLoading(true);

        const userMessage: ChatMessage = { role: 'user', parts: [{ text: messageText }] };
        const modelPlaceholder: ChatMessage = { role: 'model', parts: [{ text: '' }] };
        setMessages(prev => [...prev, userMessage, modelPlaceholder]);

        try {
            const stream = await chat.sendMessageStream({ message: messageText });
            let modelResponse = '';

            for await (const chunk of stream) {
                if (chatInstanceId.current !== callInstanceId) return;

                modelResponse += chunk.text;
                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMsg = newMessages[newMessages.length-1];
                    if(lastMsg && lastMsg.role === 'model'){
                        newMessages[newMessages.length - 1] = { ...lastMsg, parts: [{ text: modelResponse }] };
                    }
                    return newMessages;
                });
            }
        } catch (error) {
            if (chatInstanceId.current !== callInstanceId) return;
            console.error("Chat error:", error);
            const errorMessage: ChatMessage = { role: 'model', parts: [{ text: "Sorry, I'm having trouble connecting. Please try again." }] };
            setMessages(prev => {
                const newMessages = [...prev];
                if(newMessages.length > 0 && newMessages[newMessages.length-1].role === 'model'){
                    newMessages[newMessages.length - 1] = errorMessage;
                } else {
                    newMessages.push(errorMessage);
                }
                return newMessages;
            });
        } finally {
            if (chatInstanceId.current === callInstanceId) {
                 setIsLoading(false);
            }
        }
    };
    
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        sendMessage(input);
        setInput('');
    };

    const handleToggleGloss = async (messageIndex: number) => {
        const updateMessageAtIndex = (updater: (msg: ChatMessage) => ChatMessage) => {
            setMessages(prevMessages => 
                prevMessages.map((msg, idx) => 
                    idx === messageIndex ? updater(msg) : msg
                )
            );
        };
    
        const message = messages[messageIndex];
        if (!message || message.role !== 'model' || !message.parts[0].text) return;
    
        if (message.isGlossVisible) {
            updateMessageAtIndex(msg => ({ ...msg, isGlossVisible: false }));
            return;
        }
    
        if (message.gloss) {
            updateMessageAtIndex(msg => ({ ...msg, isGlossVisible: true }));
            return;
        }
        
        updateMessageAtIndex(msg => ({ ...msg, isGlossVisible: true, isGlossLoading: true }));
    
        try {
            const glossText = await generateAslGloss(message.parts[0].text);
            updateMessageAtIndex(msg => ({ ...msg, gloss: glossText, isGlossLoading: false }));
        } catch (error) {
            console.error("Failed to generate ASL gloss:", error);
            updateMessageAtIndex(msg => ({ ...msg, gloss: "ERROR: Could not generate gloss.", isGlossLoading: false }));
        }
    };

    return (
        <>
            <footer className="fixed bottom-0 left-0 right-0 p-4 z-20">
                <div className="max-w-4xl mx-auto">
                    {isHistoryOpen && (
                        <div ref={chatContainerRef} className="h-[40vh] glass-pane rounded-t-2xl p-4 mb-[-1px] overflow-y-auto space-y-4">
                           {messages.map((msg, index) => (
                                <div key={index} className={`flex items-end gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    {msg.role === 'model' && msg.parts[0].text && (
                                        <div className="flex flex-col self-center mb-1 flex-shrink-0 space-y-1">
                                            <button title="View response in ASL" onClick={() => onPlayAsl(msg.parts[0].text)} className="p-1 text-gray-400 hover:text-[var(--pathway-primary)] transition-colors">
                                                <VideoIcon className="w-5 h-5" />
                                            </button>
                                            <button title="Show ASL Gloss" onClick={() => handleToggleGloss(index)} className={`p-1 text-gray-400 hover:text-[var(--pathway-primary)] transition-colors ${msg.isGlossVisible ? 'text-[var(--pathway-primary)]' : ''}`}>
                                                <LanguageIcon className="w-5 h-5" />
                                            </button>
                                        </div>
                                    )}
                                    <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${msg.role === 'user' ? 'bg-[var(--pathway-primary)] text-white rounded-br-lg' : 'bg-gray-700 text-gray-200 rounded-bl-lg'}`}>
                                        <p className="whitespace-pre-wrap text-sm">{msg.parts[0].text || <Spinner />}</p>
                                        {msg.isGlossVisible && (
                                            <div className="mt-2 pt-2 border-t border-gray-600/50">
                                                {msg.isGlossLoading ? (
                                                    <Spinner />
                                                ) : (
                                                    <p className="whitespace-pre-wrap text-xs font-mono text-teal-300 uppercase tracking-wider">{msg.gloss}</p>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                    <div className="relative glass-pane p-2 rounded-2xl flex items-center space-x-2">
                        <button 
                            onClick={() => setIsHistoryOpen(!isHistoryOpen)} 
                            className="p-2 text-gray-400 hover:text-white"
                            title={isHistoryOpen ? "Collapse History" : "Expand History"}
                        >
                            <ChevronDownIcon className={`w-6 h-6 transition-transform ${isHistoryOpen ? '' : 'rotate-180'}`} />
                        </button>
                        <form onSubmit={handleSubmit} className="flex-grow flex items-center space-x-2">
                             <input
                                type="text"
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Ask your coach anything..."
                                className="w-full p-3 bg-transparent border-none focus:ring-0 focus:outline-none transition text-md"
                                disabled={isLoading}
                            />
                            <button 
                                type="button" 
                                title="Use Sign Language Input" 
                                className="bg-gray-700/50 hover:bg-gray-700 text-gray-300 p-3 rounded-full transition-colors"
                                onClick={() => setIsSignModalOpen(true)}
                            >
                                <SignLanguageIcon className="w-5 h-5"/>
                            </button>
                            <button type="submit" disabled={isLoading || !input.trim()} className="bg-[var(--pathway-primary)] hover:opacity-90 disabled:bg-gray-600 disabled:cursor-not-allowed text-white p-3 rounded-full transition-colors">
                                <SendIcon className="w-5 h-5"/>
                            </button>
                        </form>
                    </div>
                </div>
            </footer>
            <SignLanguageModal 
                isOpen={isSignModalOpen}
                onClose={() => setIsSignModalOpen(false)}
                onTranscription={handleTranscription}
            />
        </>
    );
};