import React from 'react';

interface AIToolCardProps {
    title: string;
    description: string;
    icon: React.FC<React.SVGProps<SVGSVGElement>>;
    onClick: () => void;
}

export const AIToolCard: React.FC<AIToolCardProps> = ({ title, description, icon: Icon, onClick }) => {
    return (
        <button
            onClick={onClick}
            className="group relative p-6 bg-gray-900/50 border border-gray-700 rounded-xl text-left hover:border-[var(--pathway-primary)] transition-all duration-300"
        >
            <div className="absolute inset-0 bg-gradient-to-br from-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="absolute -inset-px rounded-xl bg-gradient-to-r from-[var(--pathway-primary)] to-transparent opacity-0 group-hover:opacity-100 transition-opacity blur-md"></div>

            <div className="relative">
                <div className="p-2 bg-[var(--pathway-primary)]/10 rounded-lg w-fit mb-4">
                    <Icon className="w-6 h-6 text-[var(--pathway-primary)]" />
                </div>
                <h3 className="font-bold text-lg text-white">{title}</h3>
                <p className="text-sm text-gray-400 mt-1">{description}</p>
            </div>
        </button>
    );
};