import React from 'react';
import { ShieldCheckIcon } from '../icons/ShieldCheckIcon';

export const TrustBadge: React.FC = () => {
  return (
    <div className="bg-gray-800/50 border border-rose-500/30 rounded-xl p-6 flex items-center space-x-4">
        <ShieldCheckIcon className="w-12 h-12 text-rose-400 flex-shrink-0"/>
        <div>
            <h3 className="font-bold text-xl text-white flex items-center">
                FibonrostTrust
                <span className="ml-2 text-xs font-semibold bg-rose-500 text-white px-2 py-0.5 rounded-full">Verified</span>
            </h3>
            <p className="text-gray-400 text-sm mt-1">Your profile is validated to build trust with employers and partners.</p>
        </div>
    </div>
  );
};