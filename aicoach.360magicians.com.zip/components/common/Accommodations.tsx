import React from 'react';
import { SettingsIcon } from '../icons/SettingsIcon';

export const Accommodations: React.FC = () => {
  return (
    <div className="bg-gray-800/50 border border-pink-500/30 rounded-xl p-6">
        <div className="flex items-center space-x-4 mb-3">
            <SettingsIcon className="w-8 h-8 text-pink-400 flex-shrink-0" />
            <div>
                <h3 className="font-bold text-xl text-white">Accommodation Hub</h3>
                <p className="text-gray-400 text-sm">Powered by PinkSync</p>
            </div>
        </div>
        <p className="text-gray-300 mb-4">Orchestrate your in-person, online, and offline accommodation needs seamlessly.</p>
        <button className="w-full bg-pink-600 hover:bg-pink-500 text-white font-bold py-2 px-4 rounded-md transition-colors duration-200">
            Manage Preferences
        </button>
    </div>
  );
};
