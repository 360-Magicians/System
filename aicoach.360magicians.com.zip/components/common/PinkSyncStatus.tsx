import React from 'react';
import { SettingsIcon } from '../icons/SettingsIcon';

export const PinkSyncStatus: React.FC = () => {
  return (
    <div className="hidden lg:flex items-center space-x-2 bg-gray-800/50 border border-pink-500/30 rounded-full px-3 py-1.5 text-sm">
        <div className="relative flex items-center justify-center">
            <SettingsIcon className="w-5 h-5 text-pink-400 animate-spin" style={{ animationDuration: '5s' }}/>
            <div className="absolute w-2 h-2 bg-green-400 rounded-full right-0 bottom-0 border-2 border-gray-800"></div>
        </div>
        <span className="font-semibold text-gray-300">PinkSync</span>
        <span className="font-bold text-green-400">Active</span>
    </div>
  );
};
