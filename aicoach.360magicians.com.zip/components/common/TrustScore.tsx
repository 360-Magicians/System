import React from 'react';
import { FibonrostTrustIcon } from '../icons/FibonrostTrustIcon';

export const TrustScore: React.FC = () => {
  return (
    <div className="hidden lg:flex items-center space-x-2 bg-gray-800/50 border border-rose-500/30 rounded-full px-3 py-1.5 text-sm">
        <FibonrostTrustIcon className="w-5 h-5 text-rose-400"/>
        <span className="font-semibold text-gray-300">FibonrostTrust</span>
        <span className="font-bold text-rose-300">98.6</span>
    </div>
  );
};
