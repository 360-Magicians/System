import React from 'react';
import { Pathway } from '../types';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';

interface PathwayToggleProps {
  selectedPathway: Pathway;
  onPathwayChange: (pathway: Pathway) => void;
}

export const PathwayToggle: React.FC<PathwayToggleProps> = ({ selectedPathway, onPathwayChange }) => {
  const isJob = selectedPathway === Pathway.JOB;

  return (
    <div className="relative glass-pane p-1 rounded-full flex items-center w-full max-w-sm mx-auto">
      <div
        className={`absolute top-1 bottom-1 left-1 w-[calc(50%-4px)] rounded-full bg-[var(--pathway-primary)] transition-transform duration-500 ease-in-out`}
        style={{ transform: isJob ? 'translateX(0%)' : 'translateX(100%)' }}
      />
      <button
        onClick={() => onPathwayChange(Pathway.JOB)}
        className="relative z-10 w-1/2 py-2 px-4 rounded-full flex items-center justify-center space-x-2 text-md font-semibold transition-colors duration-300"
      >
        <BriefcaseIcon className="w-5 h-5" />
        <span>Job Seeker</span>
      </button>
      <button
        onClick={() => onPathwayChange(Pathway.BUSINESS)}
        className="relative z-10 w-1/2 py-2 px-4 rounded-full flex items-center justify-center space-x-2 text-md font-semibold transition-colors duration-300"
      >
        <LightbulbIcon className="w-5 h-5" />
        <span>Business</span>
      </button>
    </div>
  );
};