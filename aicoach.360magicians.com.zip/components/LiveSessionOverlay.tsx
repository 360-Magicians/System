import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob, FinishReason } from '@google/genai';
import { Spinner } from './common/Spinner';
import { PhoneOffIcon } from './icons/PhoneOffIcon';

// --- Audio Helper Functions ---
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const blobToBase64 = (blob: globalThis.Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result.split(',')[1]);
        } else {
          reject(new Error("Failed to convert blob to base64"));
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
};


// --- Component ---
interface LiveSessionOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

type Status = 'IDLE' | 'REQUESTING_PERMISSIONS' | 'CONNECTING' | 'LIVE' | 'ENDED' | 'ERROR';
interface TranscriptionTurn {
    user: string;
    model: string;
}

export const LiveSessionOverlay: React.FC<LiveSessionOverlayProps> = ({ isOpen, onClose }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const sessionPromiseRef = useRef<any>(null); // Using `any` to avoid complex session type issues
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const frameIntervalRef = useRef<number | null>(null);

    const [status, setStatus] = useState<Status>('IDLE');
    const [error, setError] = useState<string | null>(null);
    const [transcriptionHistory, setTranscriptionHistory] = useState<TranscriptionTurn[]>([]);
    const [currentInput, setCurrentInput] = useState('');
    const [currentOutput, setCurrentOutput] = useState('');
    const nextStartTimeRef = useRef(0);
    const audioSourcesRef = useRef(new Set<AudioBufferSourceNode>());

    const cleanup = useCallback(() => {
        if (frameIntervalRef.current) clearInterval(frameIntervalRef.current);
        if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
        if (videoRef.current) videoRef.current.srcObject = null;

        scriptProcessorRef.current?.disconnect();
        mediaStreamSourceRef.current?.disconnect();
        inputAudioContextRef.current?.close();
        outputAudioContextRef.current?.close();

        sessionPromiseRef.current?.then((session: any) => session?.close());
        
        frameIntervalRef.current = null;
        streamRef.current = null;
        sessionPromiseRef.current = null;
        inputAudioContextRef.current = null;
        outputAudioContextRef.current = null;
        scriptProcessorRef.current = null;
        mediaStreamSourceRef.current = null;
    }, []);

    const stopSession = useCallback(() => {
        setStatus('ENDED');
        cleanup();
        setTimeout(() => {
            onClose();
            // Reset state for next session
            setStatus('IDLE');
            setTranscriptionHistory([]);
            setCurrentInput('');
            setCurrentOutput('');
            setError(null);
        }, 1500);
    }, [cleanup, onClose]);

    const startSession = useCallback(async () => {
        setStatus('REQUESTING_PERMISSIONS');
        setError(null);
        setTranscriptionHistory([]);
        setCurrentInput('');
        setCurrentOutput('');

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
            streamRef.current = stream;
            if (videoRef.current) videoRef.current.srcObject = stream;
        } catch (err) {
            console.error(err);
            setError("Camera and microphone permissions are required. Please enable them and try again.");
            setStatus('ERROR');
            return;
        }

        setStatus('CONNECTING');

        // Fix: Cast window to `any` to support `webkitAudioContext` for older browsers where TypeScript types may be missing.
        inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        // Fix: Cast window to `any` to support `webkitAudioContext` for older browsers where TypeScript types may be missing.
        outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        nextStartTimeRef.current = 0;
        audioSourcesRef.current.clear();
        
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        sessionPromiseRef.current = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            config: {
                responseModalities: [Modality.AUDIO],
                inputAudioTranscription: {},
                outputAudioTranscription: {},
            },
            callbacks: {
                onopen: () => {
                    setStatus('LIVE');
                    
                    const source = inputAudioContextRef.current!.createMediaStreamSource(streamRef.current!);
                    mediaStreamSourceRef.current = source;
                    const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = scriptProcessor;

                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob = createBlob(inputData);
                        sessionPromiseRef.current.then((session: any) => {
                            session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(inputAudioContextRef.current!.destination);

                    const canvasEl = canvasRef.current!;
                    const videoEl = videoRef.current!;
                    const ctx = canvasEl.getContext('2d')!;
                    frameIntervalRef.current = window.setInterval(() => {
                        canvasEl.width = videoEl.videoWidth;
                        canvasEl.height = videoEl.videoHeight;
                        ctx.drawImage(videoEl, 0, 0, videoEl.videoWidth, videoEl.videoHeight);
                        canvasEl.toBlob(
                            async (blob) => {
                                if (blob) {
                                    const base64Data = await blobToBase64(blob);
                                    sessionPromiseRef.current.then((session: any) => {
                                        session.sendRealtimeInput({ media: { data: base64Data, mimeType: 'image/jpeg' } });
                                    });
                                }
                            }, 'image/jpeg', 0.8
                        );
                    }, 1000 / 4); // 4 FPS
                },
                onmessage: async (message: LiveServerMessage) => {
                    // Handle audio
                    const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData.data;
                    if (audioData) {
                        const outputAudioContext = outputAudioContextRef.current!;
                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                        const audioBuffer = await decodeAudioData(decode(audioData), outputAudioContext, 24000, 1);
                        const source = outputAudioContext.createBufferSource();
                        source.buffer = audioBuffer;
                        source.connect(outputAudioContext.destination);
                        source.addEventListener('ended', () => { audioSourcesRef.current.delete(source); });
                        source.start(nextStartTimeRef.current);
                        nextStartTimeRef.current += audioBuffer.duration;
                        audioSourcesRef.current.add(source);
                    }
                    if (message.serverContent?.interrupted) {
                         for (const source of audioSourcesRef.current.values()) source.stop();
                         audioSourcesRef.current.clear();
                         nextStartTimeRef.current = 0;
                    }
                    // Handle transcriptions
                    if (message.serverContent?.inputTranscription) setCurrentInput(prev => prev + message.serverContent!.inputTranscription!.text);
                    if (message.serverContent?.outputTranscription) setCurrentOutput(prev => prev + message.serverContent!.outputTranscription!.text);
                    if (message.serverContent?.turnComplete) {
                        const fullInput = currentInput + (message.serverContent.inputTranscription?.text || '');
                        const fullOutput = currentOutput + (message.serverContent.outputTranscription?.text || '');
                        if (fullInput.trim() || fullOutput.trim()) {
                           setTranscriptionHistory(prev => [...prev, { user: fullInput, model: fullOutput }]);
                        }
                        setCurrentInput('');
                        setCurrentOutput('');
                    }
                    if (message.finishReason === FinishReason.FINISH_REASON_UNSPECIFIED) {
                        stopSession();
                    }
                },
                onerror: (e) => { console.error('Session error', e); setError("A connection error occurred."); setStatus('ERROR'); cleanup(); },
                onclose: () => { cleanup(); },
            },
        });
    }, [cleanup, stopSession]);

    useEffect(() => {
        if (isOpen) {
            startSession();
        } else {
            cleanup();
        }
        return () => cleanup();
    }, [isOpen, startSession, cleanup]);

    if (!isOpen) return null;

    const statusMessages: Record<Status, string> = {
        IDLE: 'Preparing session...',
        REQUESTING_PERMISSIONS: 'Requesting camera & microphone...',
        CONNECTING: 'Connecting to VR4Deaf Coach...',
        LIVE: 'Live Session in Progress',
        ENDED: 'Session ended.',
        ERROR: 'An error occurred.',
    };

    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-lg flex flex-col items-center justify-center z-50 text-white p-4 animate-fade-in">
            <style>{`.animate-fade-in { animation: fadeIn 0.5s ease-in-out; } @keyframes fadeIn { 0% { opacity: 0; } 100% { opacity: 1; } }`}</style>
            
            <div className="absolute top-4 text-center">
                <h2 className="text-2xl font-bold">{statusMessages[status]}</h2>
                {status === 'LIVE' && <div className="mt-1 text-sm text-gray-300 flex items-center justify-center gap-2"><div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>REC</div>}
                {status === 'ERROR' && <p className="text-red-400 mt-1">{error}</p>}
            </div>

            <div className="relative w-full max-w-4xl aspect-video bg-black rounded-lg overflow-hidden shadow-2xl border border-gray-700">
                {(status === 'REQUESTING_PERMISSIONS' || status === 'CONNECTING') && (
                    <div className="w-full h-full flex flex-col items-center justify-center"><Spinner /></div>
                )}
                <video ref={videoRef} autoPlay muted playsInline className="w-full h-full object-cover transform scale-x-[-1]"></video>
                <canvas ref={canvasRef} className="hidden"></canvas>
                
                {/* Transcription Overlay */}
                <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-black/80 to-transparent p-4 flex flex-col justify-end space-y-2 text-shadow">
                    {transcriptionHistory.slice(-2).map((turn, index) => (
                        <div key={index} className="text-sm opacity-60">
                            <p><span className="font-bold">You:</span> {turn.user}</p>
                            <p><span className="font-bold text-[var(--pathway-secondary)]">Coach:</span> {turn.model}</p>
                        </div>
                    ))}
                    { (currentInput || currentOutput) && (
                         <div className="text-lg">
                            {currentInput && <p><span className="font-bold">You:</span> {currentInput}</p>}
                            {currentOutput && <p><span className="font-bold text-[var(--pathway-secondary)]">Coach:</span> {currentOutput}</p>}
                        </div>
                    )}
                </div>
            </div>

            <div className="absolute bottom-8">
                {status === 'ERROR' ? (
                     <button onClick={onClose} className="px-6 py-3 bg-gray-600 text-white font-bold rounded-full transition-colors hover:bg-gray-500">Close</button>
                ) : (
                    <button onClick={stopSession} className="px-6 py-4 bg-red-600 text-white font-bold rounded-full transition-transform hover:scale-105 flex items-center gap-2">
                        <PhoneOffIcon className="w-6 h-6"/>
                        <span>End Session</span>
                    </button>
                )}
            </div>
        </div>
    );
};