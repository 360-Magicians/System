import React, { useState, useEffect } from 'react';
import { Pathway } from '../types';
import { AIToolCard } from './AIToolCard';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { LightbulbIcon } from './icons/LightbulbIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { GridIcon } from './icons/GridIcon';
import { Spinner } from './common/Spinner';
import * as gemini from '../services/geminiService';
import { DocumentTextIcon } from './icons/DocumentTextIcon';

type Tool = 'resume' | 'interview' | 'skills' | 'goal' | 'guidance' | 'resources' | 'feedback';

const toolsConfig = {
    job: [
        { id: 'resume', title: 'AI Resume Reviewer', description: 'Optimize your resume against a job description.', icon: BriefcaseIcon },
        { id: 'feedback', title: 'Resume Feedback Assistant', description: 'Get actionable feedback on keywords, achievements, and skills.', icon: DocumentTextIcon },
        { id: 'interview', title: 'Interview Simulator', description: 'Practice common questions for your target role.', icon: BriefcaseIcon },
        { id: 'skills', title: 'Soft Skills Coach', description: 'Get advice on professional communication.', icon: BriefcaseIcon },
    ],
    business: [
        { id: 'goal', title: 'Goal Strategist', description: 'Break down large business goals into actionable steps.', icon: LightbulbIcon },
        { id: 'guidance', title: 'Content Generator', description: 'Draft social media posts, emails, and more.', icon: LightbulbIcon },
        { id: 'resources', title: 'Resource Finder', description: 'Discover tools and communities for entrepreneurs.', icon: LightbulbIcon },
    ],
}

export const Workspace: React.FC<{ pathway: Pathway }> = ({ pathway }) => {
    const [activeTool, setActiveTool] = useState<Tool | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [response, setResponse] = useState('');
    const [inputs, setInputs] = useState({ jobDescription: '', resume: '', topic: '', goal: '' });

    useEffect(() => {
        setActiveTool(null);
    }, [pathway]);

    const handleSelectTool = (toolId: Tool) => {
        setActiveTool(toolId);
        setResponse('');
        setInputs({ jobDescription: '', resume: '', topic: '', goal: '' });
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setInputs({ ...inputs, [e.target.name]: e.target.value });
    };

    const handleSubmit = async () => {
        setIsLoading(true);
        setResponse('');
        let result = '';
        try {
            switch(activeTool) {
                case 'resume':
                    result = await gemini.refineResume(inputs.jobDescription, inputs.resume);
                    break;
                case 'feedback':
                    result = await gemini.getResumeFeedback(inputs.jobDescription, inputs.resume);
                    break;
                case 'interview':
                    result = await gemini.generateInterviewQuestions(inputs.jobDescription, inputs.resume);
                    break;
                case 'skills':
                    result = await gemini.getSoftSkillsAdvice(inputs.topic);
                    break;
                case 'goal':
                    result = await gemini.breakDownBusinessGoal(inputs.goal);
                    break;
            }
        } catch (error) {
            result = 'An error occurred. Please try again.';
            console.error(error);
        }
        setResponse(result);
        setIsLoading(false);
    }

    const renderToolInterface = () => {
        if (!activeTool) return null;
        
        return (
            <div className="flex flex-col h-full p-6">
                <button onClick={() => setActiveTool(null)} className="flex items-center space-x-2 text-sm text-gray-400 hover:text-white mb-4">
                    <GridIcon className="w-4 h-4"/>
                    <span>Back to Tools</span>
                </button>
                <div className="flex-grow flex flex-col space-y-4 overflow-y-auto pr-2">
                    { (activeTool === 'resume' || activeTool === 'interview' || activeTool === 'feedback') && (
                        <>
                            <textarea name="jobDescription" value={inputs.jobDescription} onChange={handleInputChange} placeholder="Paste Job Description..." className="w-full h-32 p-3 bg-gray-900/50 border border-gray-700 rounded-md focus:ring-2 focus:ring-[var(--pathway-primary)] focus:outline-none transition" />
                            <textarea name="resume" value={inputs.resume} onChange={handleInputChange} placeholder="Paste Resume..." className="w-full h-48 p-3 bg-gray-900/50 border border-gray-700 rounded-md focus:ring-2 focus:ring-[var(--pathway-primary)] focus:outline-none transition" />
                        </>
                    )}
                    { activeTool === 'skills' && (
                        <input name="topic" value={inputs.topic} onChange={handleInputChange} placeholder="Enter skill topic (e.g. Teamwork)" className="w-full p-3 bg-gray-900/50 border border-gray-700 rounded-md focus:ring-2 focus:ring-[var(--pathway-primary)] focus:outline-none transition" />
                    )}
                     { activeTool === 'goal' && (
                        <textarea name="goal" value={inputs.goal} onChange={handleInputChange} placeholder="Enter a large business goal..." className="w-full h-32 p-3 bg-gray-900/50 border border-gray-700 rounded-md focus:ring-2 focus:ring-[var(--pathway-primary)] focus:outline-none transition" />
                    )}

                    <button onClick={handleSubmit} disabled={isLoading} className="w-full flex justify-center items-center space-x-2 bg-[var(--pathway-primary)] hover:opacity-90 disabled:bg-gray-600 text-white font-bold py-3 px-4 rounded-md transition-all duration-200">
                        <SparklesIcon className="w-5 h-5" />
                        <span>{isLoading ? 'Generating...' : 'Execute'}</span>
                    </button>

                    <div className="flex-grow bg-black/50 rounded-lg p-4 overflow-y-auto border border-gray-700 min-h-[200px]">
                        {isLoading ? <Spinner /> : <pre className="text-gray-200 whitespace-pre-wrap font-sans text-sm">{response}</pre>}
                    </div>
                </div>
            </div>
        )
    }

    const currentTools = pathway === Pathway.JOB ? toolsConfig.job : toolsConfig.business;

    return (
        <div className="w-full h-full glass-pane rounded-2xl">
            {activeTool ? renderToolInterface() : (
                <div className="p-8">
                     <h2 className="text-2xl font-bold text-white mb-6">AI Workspace</h2>
                     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {currentTools.map(tool => (
                            <AIToolCard key={tool.id} {...tool} onClick={() => handleSelectTool(tool.id as Tool)} />
                        ))}
                     </div>
                </div>
            )}
        </div>
    );
};