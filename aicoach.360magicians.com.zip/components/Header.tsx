import React, { useState } from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { UserCircleIcon } from './icons/UserCircleIcon';
import { LogoutIcon } from './icons/LogoutIcon';
import { PathwayToggle } from './PathwayToggle';
import { Pathway } from '../types';
import { ChevronDownIcon } from './icons/ChevronDownIcon';

interface HeaderProps {
    isAuthenticated: boolean;
    onLogout: () => void;
    selectedPathway: Pathway;
    onPathwayChange: (pathway: Pathway) => void;
}

export const Header: React.FC<HeaderProps> = ({ isAuthenticated, onLogout, selectedPathway, onPathwayChange }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
    
  return (
    <header className="py-4 px-4 lg:px-8 flex items-center justify-between h-[80px] flex-shrink-0">
      <div className="flex items-center space-x-3">
        <SparklesIcon className="w-8 h-8 text-[var(--pathway-primary)] transition-colors duration-500" />
        <h1 className="text-2xl md:text-3xl font-bold text-white tracking-wider">VR4Deaf Coach</h1>
      </div>
      
      <div className="absolute left-1/2 -translate-x-1/2 hidden lg:block">
        <PathwayToggle selectedPathway={selectedPathway} onPathwayChange={onPathwayChange} />
      </div>

      {isAuthenticated && (
         <div className="flex items-center space-x-2 md:space-x-4">
            <div className="relative">
                <button 
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                    className="flex items-center space-x-2 px-4 py-2 glass-pane rounded-full hover:bg-gray-800/80 transition-colors"
                >
                    <UserCircleIcon className="w-6 h-6 text-gray-300"/>
                    <span className="font-semibold text-gray-200 hidden sm:inline">Profile</span>
                    <ChevronDownIcon className={`w-5 h-5 text-gray-400 transition-transform ${isMenuOpen ? 'rotate-180' : ''}`} />
                </button>
                {isMenuOpen && (
                     <div className="absolute top-full right-0 mt-2 w-48 glass-pane rounded-lg shadow-lg py-1 z-50">
                         <button 
                            onClick={onLogout}
                            className="w-full flex items-center space-x-3 px-4 py-2 text-gray-300 hover:bg-gray-700/50 transition-colors"
                         >
                            <LogoutIcon className="w-5 h-5"/>
                            <span className="font-semibold">Logout</span>
                         </button>
                     </div>
                )}
            </div>
         </div>
      )}
    </header>
  );
};