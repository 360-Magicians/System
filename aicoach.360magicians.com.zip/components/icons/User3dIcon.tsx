import React from 'react';

export const User3dIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M4 8.76V15.24a2 2 0 0 0 1 1.73l6 3.47a2 2 0 0 0 2 0l6-3.47a2 2 0 0 0 1-1.73V8.76a2 2 0 0 0-1-1.73l-6-3.47a2 2 0 0 0-2 0l-6 3.47a2 2 0 0 0-1 1.73Z"></path>
    <path d="M12 22v-8"></path>
    <path d="M21 7.5V12"></path>
    <path d="m3.5 7.5 8.5 5 8.5-5"></path>
    <path d="M3 15.24 12 10l9 5.24"></path>
  </svg>
);