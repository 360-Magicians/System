import React from 'react';

export const DeafAuthIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    {...props}
    >
    <path d="M8 10V7a4 4 0 1 1 8 0v3"></path>
    <path d="M2 10h20"></path>
    <path d="m14.5 14-1 1"></path>
    <path d="m11.5 17-1 1"></path>
    <path d="M2 10h.01"></path>
    <path d="M17 14h.01"></path>
    <path d="M22 10h-.01"></path>
    <path d="M7 14h.01"></path>
    <path d="M17 17a2.5 2.5 0 0 0-5 0c0 1.6 2.5 3 2.5 3s2.5-1.4 2.5-3Z"></path>
    <path d="M7 17a2.5 2.5 0 0 1 5 0c0 1.6-2.5 3-2.5 3S7 18.4 7 17Z"></path>
  </svg>
);