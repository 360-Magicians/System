import React from 'react';

export const SignLanguageIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M13 18.5a1.5 1.5 0 0 1-3 0v-6a1.5 1.5 0 0 1 3 0v6Z" />
    <path d="M16.5 16.5a1.5 1.5 0 0 1-3 0v-3a1.5 1.5 0 0 1 3 0v3Z" />
    <path d="M19.5 14.5a1.5 1.5 0 0 1-3 0v-1a1.5 1.5 0 0 1 3 0v1Z" />
    <path d="M7 10a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
    <path d="M4 14.5a2.5 2.5 0 0 1 5 0V17a2 2 0 0 1-4 0" />
    <path d="M10 17.5c.5-1 1.5-1.5 2-2.5" />
    <path d="M14 17.5c.5-1 1.5-1.5 2-2.5" />
  </svg>
);