import React from 'react';
import { User3dIcon } from './icons/User3dIcon';
import { VideoPlaceholder } from './VideoPlaceholder';
import { VideoIcon } from './icons/VideoIcon';

interface AvatarDisplayProps {
  isSigning: boolean;
  message: string;
  onStartLiveSession: () => void;
}

export const AvatarDisplay: React.FC<AvatarDisplayProps> = ({ isSigning, message, onStartLiveSession }) => {
  
  const titleText = "DeafAUTH Avatar";
  const subText = "Your personalized 3D model is ready.";

  return (
    <div className="relative w-full h-full glass-pane rounded-2xl flex flex-col justify-center items-center p-6 text-center text-gray-400 overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-10 animate-pan"></div>
      <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-[var(--pathway-glow-start)] to-transparent pointer-events-none"></div>

      {isSigning ? (
        <VideoPlaceholder message={message} />
      ) : (
        <div className="relative z-10 flex flex-col items-center">
            <User3dIcon className="w-20 h-20 mb-4 text-gray-500" />
            <h3 className="font-semibold text-xl text-gray-300">{titleText}</h3>
            <p className="text-sm">{subText}</p>
             <button
              onClick={onStartLiveSession}
              className="mt-6 flex items-center space-x-2 px-6 py-3 bg-[var(--pathway-primary)] hover:opacity-90 text-white font-bold rounded-full transition-all duration-200"
            >
              <VideoIcon className="w-5 h-5" />
              <span>Start Live Session</span>
            </button>
            <div className="absolute -bottom-8 w-32 h-2 rounded-full bg-[var(--pathway-primary)] blur-2xl"></div>
        </div>
      )}
    </div>
  );
};

const style = document.createElement('style');
style.textContent = `
  @keyframes pan {
    0% { background-position: 0% 0%; }
    100% { background-position: 100% 100%; }
  }
  .bg-grid-pattern {
    background-image: linear-gradient(rgba(255, 255, 255, 0.07) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.07) 1px, transparent 1px);
    background-size: 2rem 2rem;
  }
  .animate-pan {
    animation: pan 60s linear infinite;
  }
`;
document.head.append(style);