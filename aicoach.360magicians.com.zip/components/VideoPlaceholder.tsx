import React from 'react';
import { User3dIcon } from './icons/User3dIcon';

export const VideoPlaceholder: React.FC<{ message?: string }> = ({ message }) => {
  return (
    <div className="relative w-full h-full flex flex-col justify-center items-center p-4 text-center overflow-hidden">
      <div className="relative z-10 flex flex-col items-center">
        <User3dIcon className="w-24 h-24 text-[var(--pathway-primary)] animate-pulse" />
        <p className="mt-4 text-lg font-semibold text-white">Your VR4Deaf Coach is signing...</p>
        {message && (
          <p className="mt-2 text-sm text-gray-300 bg-black/50 px-3 py-1 rounded-md max-w-full truncate">
            {`"${message}"`}
          </p>
        )}
      </div>
      <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center space-x-1 h-8">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="w-1 bg-teal-400 rounded-full animate-waveform"
            style={{ 
              animationDelay: `${i * 0.1}s`,
              height: `${Math.random() * 24 + 4}px`
            }}
          ></div>
        ))}
      </div>
    </div>
  );
};

const waveformStyle = document.createElement('style');
waveformStyle.textContent = `
  @keyframes waveform {
    0%, 100% { transform: scaleY(0.5); }
    50% { transform: scaleY(1); }
  }
  .animate-waveform {
    animation: waveform 1.5s ease-in-out infinite;
  }
`;
document.head.append(waveformStyle);