import React, { useState, useRef } from 'react';
import { Pathway, UserProfile } from '../types';
import { Header } from './Header';
import { AvatarDisplay } from './AvatarPlaceholder';
import { Workspace } from './Workspace';
import { AICommandBar } from './AICommandBar';
import { PathwayToggle } from './PathwayToggle';
import { LiveSessionOverlay } from './LiveSessionOverlay';

interface CoachDashboardProps {
  onLogout: () => void;
  userProfile: UserProfile;
}

export const CoachDashboard: React.FC<CoachDashboardProps> = ({ onLogout, userProfile }) => {
  const [pathway, setPathway] = useState<Pathway>(Pathway.JOB);
  const [isSigning, setIsSigning] = useState(false);
  const [signingMessage, setSigningMessage] = useState('');
  const [isLiveSessionOpen, setIsLiveSessionOpen] = useState(false);
  const signingTimerRef = useRef<number | null>(null);

  const handlePlayAsl = (message: string) => {
    // If a signing animation is already in progress, clear the old timer
    // to allow the new one to start immediately. This provides instant feedback.
    if (signingTimerRef.current) {
      clearTimeout(signingTimerRef.current);
    }

    setSigningMessage(message);
    setIsSigning(true);

    const words = message.split(' ').length;
    const estimatedTime = Math.max(4000, words * 300);

    // Set a new timer and store its ID in the ref
    signingTimerRef.current = window.setTimeout(() => {
      setIsSigning(false);
      setSigningMessage('');
      signingTimerRef.current = null; // Clear the ref
    }, estimatedTime);
  };
  
  const pathwayClass = pathway === Pathway.JOB ? 'pathway-job' : 'pathway-business';

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-500 ${pathwayClass}`}>
      <div className="absolute inset-0 w-full h-full bg-gradient-to-br from-background-start to-background-end -z-10" />
      
      <Header 
        isAuthenticated={true} 
        onLogout={onLogout}
        selectedPathway={pathway}
        onPathwayChange={setPathway}
      />
      
      {/* Pathway Toggle for mobile and tablet views */}
      <div className="px-4 sm:px-8 pt-4 lg:hidden">
        <PathwayToggle selectedPathway={pathway} onPathwayChange={setPathway} />
      </div>

      <main className="flex-grow p-4 sm:p-8 flex flex-col lg:flex-row gap-8 pb-32 lg:pb-8">
        {/* Main Workspace Area */}
        <div className="lg:w-2/3 w-full order-2 lg:order-1">
          <Workspace pathway={pathway} />
        </div>
        
        {/* Persistent AI Sidebar */}
        <div className="lg:w-1/3 w-full order-1 lg:order-2 h-[50vh] lg:h-auto">
          <AvatarDisplay 
            isSigning={isSigning} 
            message={signingMessage} 
            onStartLiveSession={() => setIsLiveSessionOpen(true)}
          />
        </div>
      </main>
      
      <AICommandBar pathway={pathway} onPlayAsl={handlePlayAsl} />

      <LiveSessionOverlay 
        isOpen={isLiveSessionOpen}
        onClose={() => setIsLiveSessionOpen(false)}
      />

    </div>
  );
};