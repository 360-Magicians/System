import React, { useState, useEffect } from 'react';
import { SparklesIcon } from './icons/SparklesIcon';
import { AuthMethod } from '../types';
import { Spinner } from './common/Spinner';
import { TicketIcon } from './icons/TicketIcon';

interface LoginScreenProps {
  onLogin: (authMethod: AuthMethod) => void;
}

const deafAuthLoadingSteps = [
    "Authenticating...",
    "Compiling 3D Model...",
    "Loading Avatar Bundle...",
    "Finalizing...",
];

// In a real application, this would be validated against a backend.
const VALID_APPOINTMENT_CODE = 'APPOINTMENT123';

type AppointmentStatus = 'IDLE' | 'CHECKING' | 'INVALID' | 'VERIFIED';

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
    const [status, setStatus] = useState<AppointmentStatus>('IDLE');
    const [appointmentCode, setAppointmentCode] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [loadingStep, setLoadingStep] = useState(0);

    const handleVerifyAppointment = (e: React.FormEvent) => {
        e.preventDefault();
        if (!appointmentCode.trim()) {
            setErrorMessage("Please enter an appointment code.");
            setStatus('INVALID');
            return;
        }

        setStatus('CHECKING');
        setErrorMessage('');

        setTimeout(() => {
            if (appointmentCode.trim().toUpperCase() === VALID_APPOINTMENT_CODE) {
                setStatus('VERIFIED');
            } else {
                setErrorMessage("No appointment found. Please check your code and try again.");
                setStatus('INVALID');
            }
        }, 1500);
    };
    
    useEffect(() => {
        let timer: number;
        if (status === 'VERIFIED') {
            timer = window.setInterval(() => {
                setLoadingStep(prev => {
                    if (prev < deafAuthLoadingSteps.length - 1) {
                        return prev + 1;
                    }
                    clearInterval(timer);
                    return prev;
                });
            }, 800);

            const totalTime = deafAuthLoadingSteps.length * 800 + 500;
            setTimeout(() => {
                onLogin('DeafAUTH');
            }, totalTime);
        }
        return () => clearInterval(timer);
    }, [status, onLogin]);


    const renderContent = () => {
        switch (status) {
            case 'CHECKING':
                return (
                    <div className="flex flex-col items-center justify-center space-y-3 h-[148px]">
                        <Spinner />
                        <p className="text-md font-semibold text-gray-300">
                            Verifying your appointment...
                        </p>
                    </div>
                );
            case 'VERIFIED':
                 return (
                    <div className="flex flex-col items-center justify-center space-y-3 h-[148px]">
                        <Spinner />
                        <p className="text-md font-semibold text-teal-300">
                           Appointment found!
                        </p>
                        <p className="text-sm text-gray-400 transition-opacity">
                            {deafAuthLoadingSteps[loadingStep]}
                        </p>
                    </div>
                );
            case 'IDLE':
            case 'INVALID':
            default:
                return (
                    <form onSubmit={handleVerifyAppointment} className="space-y-4">
                        <div className="relative">
                            <TicketIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                value={appointmentCode}
                                onChange={(e) => {
                                    setAppointmentCode(e.target.value);
                                    if(status === 'INVALID') setStatus('IDLE');
                                }}
                                placeholder="Enter Appointment Code"
                                className="w-full pl-10 pr-4 py-3 bg-gray-900/50 border border-gray-600 rounded-lg focus:ring-2 focus:ring-[var(--pathway-primary)] focus:outline-none transition"
                                aria-invalid={status === 'INVALID'}
                                aria-describedby="error-message"
                            />
                        </div>
                         {status === 'INVALID' && errorMessage && (
                            <p id="error-message" className="text-sm text-red-400">{errorMessage}</p>
                        )}
                        <button 
                            type="submit"
                            className="w-full flex items-center justify-center space-x-3 py-3 px-4 bg-teal-600 hover:bg-teal-500 border border-teal-500 rounded-lg text-lg font-semibold transition-all"
                        >
                            <span>Verify Appointment</span>
                        </button>
                    </form>
                );
        }
    };


  return (
    <div className="min-h-screen w-full flex flex-col justify-center items-center p-4">
      <div className="absolute inset-0 bg-black opacity-30"></div>
      <div className="w-full max-w-md text-center z-10">
        <div className="flex justify-center items-center space-x-4 mb-4">
          <SparklesIcon className="w-12 h-12 text-teal-400" />
          <h1 className="text-4xl md:text-5xl font-bold text-white tracking-wider">VR4Deaf Coach</h1>
        </div>
        <p className="text-gray-400 text-lg mb-10">Your AI-powered partner for career and business success.</p>

        <div className="glass-pane rounded-2xl p-8 space-y-4">
            <div>
              <h2 className="text-xl font-semibold text-gray-200">Appointments Only</h2>
              <p className="text-gray-400 text-sm mt-1">Please enter your code to begin the session.</p>
            </div>
            {renderContent()}
        </div>
        
        <p className="mt-12 text-gray-500 text-sm">Powered by 360 Magicians</p>
      </div>
    </div>
  );
};