import { ReactNode } from "react";

export enum Pathway {
  JOB = 'JOB',
  BUSINESS = 'BUSINESS',
}

export interface ChatMessage {
    role: 'user' | 'model';
    parts: { text: string }[];
    gloss?: string;
    isGlossLoading?: boolean;
    isGlossVisible?: boolean;
}

export type AuthMethod = 'DeafAUTH';

export interface UserProfile {
    authMethod: AuthMethod;
}