import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Brain, CheckCircle, FileText, Boxes, Palette, Cloud, Settings } from "lucide-react"

const categories = [
  {
    name: "IDEA",
    color: "from-purple-500 to-purple-600",
    steps: [
      {
        icon: Brain,
        title: "Vision to Idea",
        description: "Transform your vision into concrete business ideas using ChatGPT and Gen AI assistance.",
        tools: "ChatGPT • Gen AI",
      },
      {
        icon: CheckCircle,
        title: "Idea Validation",
        description: "Validate your concept through market research and expert third-party partner analysis.",
        tools: "Third Party Partners",
      },
    ],
  },
  {
    name: "BUILD",
    color: "from-blue-500 to-blue-600",
    steps: [
      {
        icon: FileText,
        title: "Idea to Proposal",
        description: "Convert validated ideas into structured proposals using our v0-template system.",
        tools: "v0-Template • Our Platform",
      },
      {
        icon: Boxes,
        title: "Proposal to Build Prototype",
        description: "Transform proposals into working prototypes through our DAO pipeline template.",
        tools: "DAO Pipeline • Our Template",
      },
      {
        icon: Palette,
        title: "Prototype to Generated Assets",
        description: "Automatically generate and upload design assets using v0 integration.",
        tools: "v0 • Auto Asset Upload",
        badge: "Coming Soon",
      },
    ],
  },
  {
    name: "GROW",
    color: "from-green-500 to-green-600",
    steps: [
      {
        icon: Cloud,
        title: "BUILD Integration",
        description: "Deploy and integrate with cloud services, Supabase, and other platforms.",
        tools: "Cloud • Supabase • Integrations",
      },
    ],
  },
  {
    name: "MANAGED",
    color: "from-orange-500 to-orange-600",
    steps: [
      {
        icon: Settings,
        title: "Managed Operations",
        description: "Full business management with ongoing support and optimization.",
        tools: "Full Management Suite",
      },
    ],
  },
]

export function ProcessSection() {
  return (
    <section className="py-20 px-4 bg-gradient-to-br from-purple-50/50 to-blue-50/50 dark:from-purple-950/10 dark:to-blue-950/10">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Your Complete Business Pipeline</h2>
          <p className="text-muted-foreground">
            From vision to managed business with integrated AI tools and platforms
          </p>
        </div>

        <div className="space-y-12">
          {categories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="space-y-6">
              <div className="text-center">
                <div
                  className={`inline-block px-8 py-3 rounded-full bg-gradient-to-r ${category.color} text-white font-bold text-lg tracking-wide shadow-lg`}
                >
                  {category.name}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
                {category.steps.map((step, stepIndex) => {
                  const Icon = step.icon
                  return (
                    <Card
                      key={stepIndex}
                      className="p-6 text-center hover:shadow-xl transition-all duration-300 max-w-sm border-2 hover:border-purple-200"
                    >
                      <div className="relative">
                        {step.badge && (
                          <Badge variant="secondary" className="absolute -top-2 -right-2 text-xs">
                            {step.badge}
                          </Badge>
                        )}
                        <div
                          className={`w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-r ${category.color} flex items-center justify-center shadow-lg`}
                        >
                          <Icon className="w-7 h-7 text-white" />
                        </div>
                      </div>
                      <h3 className="font-bold mb-2 text-base">{step.title}</h3>
                      <p className="text-sm text-muted-foreground leading-relaxed mb-3">{step.description}</p>
                      <div className="pt-2 border-t border-gray-100">
                        <p className="text-xs font-medium text-purple-600 dark:text-purple-400">{step.tools}</p>
                      </div>
                    </Card>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
