"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"
import { useASL, signLanguages, type SignLanguage } from "./asl-context"

export function Header() {
  const { isASLActive, currentLanguage, toggleASL, setSignLanguage } = useASL()

  const handleLanguageSelect = (language: SignLanguage) => {
    setSignLanguage(language)
    if (!isASLActive) {
      toggleASL()
    }
  }

  return (
    <header className="border-b border-border/40 bg-background/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg gradient-bg flex items-center justify-center">
            <span className="text-white font-bold text-sm">360</span>
          </div>
          <span className="font-display font-bold text-xl">Business Magician</span>
        </div>
        <div className="flex items-center gap-3">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant={isASLActive ? "default" : "outline"}
                size="sm"
                className={isASLActive ? "bg-blue-600 hover:bg-blue-700" : ""}
              >
                <span className="mr-1">🤟</span>
                {currentLanguage}
                <ChevronDown className="ml-1 h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              {Object.entries(signLanguages).map(([key, lang]) => (
                <DropdownMenuItem
                  key={key}
                  onClick={() => handleLanguageSelect(key as SignLanguage)}
                  disabled={!lang.available}
                  className="flex items-center justify-between"
                >
                  <span>{lang.name}</span>
                  {lang.comingSoon && (
                    <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">Coming Soon</span>
                  )}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" size="sm">
            Join Waitlist
          </Button>
        </div>
      </div>
    </header>
  )
}
