import { ASLVideo } from "./asl-video"

export function FeaturesSection() {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold mb-4">
            What is <span className="gradient-text">Business Magician</span>?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Business Magician is a smart platform powered by AI agents, built to be your co-founder from day one. It
            guides you through 10 smart steps to transform your idea into a real startup. No coding. No chaos. No
            guesswork. Just results.
          </p>

          <ASLVideo
            title="What is Business Magician?"
            description="Discover how Business Magician serves as your AI co-founder, guiding you through 10 structured steps to build your startup from idea to launch."
          />
        </div>

        <div className="text-center mb-16">
          <h3 className="text-2xl font-display font-bold mb-8">
            Your <span className="gradient-text">Startup</span>, Step by Step
          </h3>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            With Business Magician, you'll follow a structured journey. Each step is powered by a specialized AI agent
            that works with you like the best co-founder a real team would.
          </p>

          <ASLVideo
            title="Step-by-Step Startup Process"
            description="Learn about our structured 10-step journey where specialized AI agents guide you through each phase of building your startup."
          />
        </div>
      </div>
    </section>
  )
}
