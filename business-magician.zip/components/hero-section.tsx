import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"
import { ASLVideo } from "./asl-video"

export function HeroSection() {
  return (
    <section className="py-20 px-4 text-center relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20" />
      <div className="container mx-auto max-w-4xl relative">
        <h1 className="text-5xl md:text-6xl font-display font-bold mb-6">
          Your <span className="gradient-text">AI Co-Founder</span>
          <br />
          is about to launch
        </h1>

        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
          Transform your business idea into a thriving startup with a comprehensive AI platform that creates complete
          business plans, marketing strategies, financial models, and pitch decks in minutes—not months.
        </p>

        <ASLVideo
          title="Welcome to Business Magician"
          description="Learn how our AI co-founder platform transforms your business ideas into thriving startups with comprehensive planning and strategy tools."
        />

        <div className="flex flex-wrap justify-center gap-6 mb-10 text-sm">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span>24/7 Expert AI Guidance</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span>No Technical Knowledge Required</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span>Investor-Ready Materials</span>
          </div>
        </div>

        <Button size="lg" className="gradient-bg text-white hover:opacity-90 mb-12">
          Get Early Access →
        </Button>

        <Card className="p-6 max-w-2xl mx-auto bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-purple-200 dark:border-purple-800">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-full gradient-bg flex items-center justify-center">
              <span className="text-white font-bold">AI</span>
            </div>
            <div className="text-left">
              <h3 className="font-semibold">Your AI Co-Founder</h3>
              <p className="text-sm text-muted-foreground">Business Strategy Session</p>
            </div>
          </div>
          <div className="text-left space-y-2 text-sm">
            <p>
              <strong>Business Strategy:</strong> ✓
            </p>
            <p>
              <strong>Marketing Plans:</strong> ✓
            </p>
            <p>
              <strong>Financial Models:</strong> ✓
            </p>
            <p>
              <strong>Legal Assistant:</strong> ✓
            </p>
            <p>
              <strong>Product Designer:</strong> ✓
            </p>
            <p>
              <strong>Growth Hacker:</strong> ✓
            </p>
          </div>
        </Card>
      </div>
    </section>
  )
}
