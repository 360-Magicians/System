"use client"

import { useASL } from "./asl-context"

interface ASLVideoProps {
  title: string
  description: string
  videoSrc?: string
}

export function ASLVideo({ title, description, videoSrc }: ASLVideoProps) {
  const { isASLActive } = useASL()

  if (!isASLActive) return null

  return (
    <div className="mt-6 p-4 bg-slate-50 dark:bg-slate-900 rounded-lg border-2 border-blue-200 dark:border-blue-800">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center">
          <span className="text-white text-xs font-bold">ASL</span>
        </div>
        <h3 className="font-semibold text-blue-900 dark:text-blue-100">{title}</h3>
      </div>

      <div className="aspect-video bg-slate-200 dark:bg-slate-800 rounded-lg flex items-center justify-center mb-3">
        {videoSrc ? (
          <video
            src={videoSrc}
            controls
            className="w-full h-full rounded-lg"
            poster="/placeholder.svg?height=200&width=300"
          />
        ) : (
          <div className="text-center p-4">
            <div className="w-16 h-16 mx-auto mb-2 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <span className="text-2xl">🤟</span>
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400">ASL interpretation coming soon</p>
          </div>
        )}
      </div>

      <p className="text-sm text-slate-700 dark:text-slate-300">{description}</p>
    </div>
  )
}
