"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

export type SignLanguage = "ASL" | "ISL" | "DRSL"

interface ASLContextType {
  isASLActive: boolean
  currentLanguage: SignLanguage
  toggleASL: () => void
  setSignLanguage: (language: SignLanguage) => void
}

const ASLContext = createContext<ASLContextType | undefined>(undefined)

export function ASLProvider({ children }: { children: ReactNode }) {
  const [isASLActive, setIsASLActive] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState<SignLanguage>("ASL")

  const toggleASL = () => {
    setIsASLActive(!isASLActive)
  }

  const setSignLanguage = (language: SignLanguage) => {
    setCurrentLanguage(language)
  }

  return (
    <ASLContext.Provider value={{ isASLActive, currentLanguage, toggleASL, setSignLanguage }}>
      {children}
    </ASLContext.Provider>
  )
}

export function useASL() {
  const context = useContext(ASLContext)
  if (context === undefined) {
    throw new Error("useASL must be used within an ASLProvider")
  }
  return context
}

export const signLanguages = {
  ASL: { name: "American Sign Language", available: true },
  ISL: { name: "Indian Sign Language", available: false, comingSoon: true },
  DRSL: { name: "Dominican Republic Sign Language", available: false, comingSoon: true },
}
