import { Users, Zap, Target, RefreshCw } from "lucide-react"

const features = [
  {
    icon: Target,
    title: "Locked step-by-step flow",
    description: "No shortcuts, just real progress. Build your startup properly, one step at a time.",
  },
  {
    icon: Users,
    title: "Personalized",
    description: "Your journey adapts to your idea, industry, and goals. Get guidance tailored to your specific needs.",
  },
  {
    icon: Users,
    title: "AI agents with domain expertise",
    description: "Each step is powered by specialized AI agents with deep knowledge in their domain.",
  },
  {
    icon: Zap,
    title: "All-in-one",
    description: "Everything you need in one place. No need to juggle multiple tools, platforms, or subscriptions.",
  },
  {
    icon: Target,
    title: "Real outputs",
    description: "Get tangible business plans, validation reports, marketing materials you can use right away.",
  },
  {
    icon: RefreshCw,
    title: "Continuous improvement",
    description: "Our AI gets smarter with every startup. Benefit from collective learnings and success patterns.",
  },
]

export function WhyDifferentSection() {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-display font-bold mb-4">
            Why Business Magician is <span className="gradient-text">Different</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div key={index} className="flex gap-4">
                <div className="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center flex-shrink-0">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
