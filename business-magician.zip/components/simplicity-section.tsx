import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function SimplicitySectionComponent() {
  return (
    <section className="py-20 px-4 bg-gradient-to-br from-purple-50/50 to-blue-50/50 dark:from-purple-950/10 dark:to-blue-950/10">
      <div className="container mx-auto max-w-4xl text-center">
        <h2 className="text-4xl font-display font-bold mb-4">
          <span className="gradient-text">Astounding</span> simplicity
        </h2>
        <p className="text-xl text-muted-foreground mb-16 max-w-2xl mx-auto">
          A streamlined three-step process that takes you from idea to launched startup without the complexity
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full gradient-bg flex items-center justify-center">
              <span className="text-white font-bold text-xl">1</span>
            </div>
            <h3 className="font-display font-semibold text-xl mb-4">Share Your Vision</h3>
            <p className="text-muted-foreground">
              Describe your idea in a conversational chat without AI jargon. No technical expertise required.
            </p>
          </Card>

          <Card className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full gradient-bg flex items-center justify-center">
              <span className="text-white font-bold text-xl">2</span>
            </div>
            <h3 className="font-display font-semibold text-xl mb-4">Review & Refine</h3>
            <p className="text-muted-foreground">
              Get AI-generated business plans, strategies, and materials. Review, provide feedback, and refine.
            </p>
          </Card>

          <Card className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-6 rounded-full gradient-bg flex items-center justify-center">
              <span className="text-white font-bold text-xl">3</span>
            </div>
            <h3 className="font-display font-semibold text-xl mb-4">Launch & Grow</h3>
            <p className="text-muted-foreground">
              Execute your plan with ongoing AI guidance. Launch your startup and scale with confidence.
            </p>
          </Card>
        </div>

        <Button size="lg" className="gradient-bg text-white hover:opacity-90">
          Start Your Journey →
        </Button>
      </div>
    </section>
  )
}
