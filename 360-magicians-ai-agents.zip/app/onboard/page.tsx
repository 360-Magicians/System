"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Eye,
  Hand,
  Users,
  Code,
  Rocket,
  CheckCircle,
  ArrowRight,
  Video,
  MessageSquare,
  Globe,
} from "lucide-react"

export default function DeafFirstOnboarding() {
  const [currentStep, setCurrentStep] = useState(0)
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)
  const [hasSound, setHasSound] = useState(false)
  const [preferredLanguage, setPreferredLanguage] = useState("asl")
  const [developerProfile, setDeveloperProfile] = useState({
    name: "",
    email: "",
    company: "",
    experience: "",
    accessibilityNeeds: [] as string[],
    communicationPreference: "visual",
  })
  const videoRef = useRef<HTMLVideoElement>(null)

  const onboardingSteps = [
    {
      id: "welcome",
      title: "Welcome to mbtq.dev",
      subtitle: "World's First Deaf-First Developer Platform",
      description: "Experience development tools designed by and for the deaf community",
      videoUrl: "/videos/welcome-asl.mp4",
      hasASL: true,
    },
    {
      id: "accessibility",
      title: "Your Accessibility Preferences",
      subtitle: "Customize your development experience",
      description: "Set up visual alerts, communication preferences, and assistive features",
      videoUrl: "/videos/accessibility-setup-asl.mp4",
      hasASL: true,
    },
    {
      id: "profile",
      title: "Developer Profile",
      subtitle: "Tell us about your development journey",
      description: "Help us personalize your experience and connect you with the right resources",
      videoUrl: "/videos/profile-setup-asl.mp4",
      hasASL: true,
    },
    {
      id: "api-key",
      title: "Get Your API Key",
      subtitle: "Access 12 Deaf-First AI Agents",
      description: "Generate your secure API key to start building accessible applications",
      videoUrl: "/videos/api-key-asl.mp4",
      hasASL: true,
    },
    {
      id: "first-call",
      title: "Make Your First API Call",
      subtitle: "Test the Career Matching AI",
      description: "Experience our AI agents with a live demonstration",
      videoUrl: "/videos/first-call-asl.mp4",
      hasASL: true,
    },
    {
      id: "community",
      title: "Join the Community",
      subtitle: "Connect with deaf developers worldwide",
      description: "Access forums, mentorship, and collaborative projects",
      videoUrl: "/videos/community-asl.mp4",
      hasASL: true,
    },
  ]

  const accessibilityOptions = [
    { id: "visual-alerts", label: "Visual Alerts", icon: Eye, description: "Flash notifications and visual cues" },
    { id: "haptic-feedback", label: "Haptic Feedback", icon: Hand, description: "Vibration and touch responses" },
    { id: "asl-interpreter", label: "ASL Interpretation", icon: Video, description: "Sign language video support" },
    { id: "captions", label: "Live Captions", icon: MessageSquare, description: "Real-time text captions" },
    { id: "high-contrast", label: "High Contrast", icon: Eye, description: "Enhanced visual contrast" },
  ]

  const toggleVideo = () => {
    if (videoRef.current) {
      if (isVideoPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play()
      }
      setIsVideoPlaying(!isVideoPlaying)
    }
  }

  const handleAccessibilityToggle = (optionId: string) => {
    setDeveloperProfile((prev) => ({
      ...prev,
      accessibilityNeeds: prev.accessibilityNeeds.includes(optionId)
        ? prev.accessibilityNeeds.filter((id) => id !== optionId)
        : [...prev.accessibilityNeeds, optionId],
    }))
  }

  const currentStepData = onboardingSteps[currentStep]
  const progress = ((currentStep + 1) / onboardingSteps.length) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Hand className="h-12 w-12 text-blue-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              mbtq.dev
            </h1>
            <Users className="h-8 w-8 text-green-500" />
          </div>
          <p className="text-xl text-slate-600 mb-2">Deaf-First Developer Platform</p>
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            🌟 Designed by and for the deaf community
          </Badge>
        </div>

        {/* Progress Bar */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Onboarding Progress</span>
            <span className="text-sm text-slate-600">
              {currentStep + 1} of {onboardingSteps.length}
            </span>
          </div>
          <Progress value={progress} className="h-3" />
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Video/Visual Content */}
            <Card className="relative overflow-hidden">
              <CardContent className="p-0">
                <div className="aspect-video bg-slate-900 relative">
                  <video
                    ref={videoRef}
                    className="w-full h-full object-cover"
                    poster={`/images/step-${currentStep}-poster.jpg`}
                    onPlay={() => setIsVideoPlaying(true)}
                    onPause={() => setIsVideoPlaying(false)}
                  >
                    <source src={currentStepData.videoUrl} type="video/mp4" />
                    <track
                      kind="captions"
                      src={`/captions/step-${currentStep}-en.vtt`}
                      srcLang="en"
                      label="English"
                      default
                    />
                  </video>

                  {/* Video Controls */}
                  <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={toggleVideo}
                        className="bg-black/50 text-white hover:bg-black/70"
                      >
                        {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => setHasSound(!hasSound)}
                        className="bg-black/50 text-white hover:bg-black/70"
                      >
                        {hasSound ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                      </Button>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-black/50 text-white">
                        ASL Interpretation
                      </Badge>
                      <Badge variant="secondary" className="bg-black/50 text-white">
                        Live Captions
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Step Content */}
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline">Step {currentStep + 1}</Badge>
                  {currentStepData.hasASL && (
                    <Badge variant="secondary" className="bg-blue-50 text-blue-700">
                      <Hand className="h-3 w-3 mr-1" />
                      ASL Available
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-2xl">{currentStepData.title}</CardTitle>
                <CardDescription className="text-lg">{currentStepData.subtitle}</CardDescription>
              </CardHeader>

              <CardContent className="space-y-6">
                <p className="text-slate-600">{currentStepData.description}</p>

                {/* Step-specific content */}
                {currentStep === 0 && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="text-center p-4 border rounded-lg">
                        <Code className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                        <h3 className="font-medium">12 AI Agents</h3>
                        <p className="text-sm text-slate-600">Deaf-first accessibility AI</p>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <Globe className="h-8 w-8 mx-auto mb-2 text-green-500" />
                        <h3 className="font-medium">Global Community</h3>
                        <p className="text-sm text-slate-600">70M+ deaf developers</p>
                      </div>
                    </div>
                  </div>
                )}

                {currentStep === 1 && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Select your accessibility preferences:</h4>
                    <div className="grid grid-cols-1 gap-3">
                      {accessibilityOptions.map((option) => {
                        const IconComponent = option.icon
                        const isSelected = developerProfile.accessibilityNeeds.includes(option.id)

                        return (
                          <div
                            key={option.id}
                            className={`p-4 border rounded-lg cursor-pointer transition-all ${
                              isSelected ? "border-blue-500 bg-blue-50" : "border-slate-200 hover:border-slate-300"
                            }`}
                            onClick={() => handleAccessibilityToggle(option.id)}
                          >
                            <div className="flex items-start gap-3">
                              <IconComponent
                                className={`h-5 w-5 mt-0.5 ${isSelected ? "text-blue-600" : "text-slate-500"}`}
                              />
                              <div className="flex-1">
                                <h5 className="font-medium">{option.label}</h5>
                                <p className="text-sm text-slate-600">{option.description}</p>
                              </div>
                              {isSelected && <CheckCircle className="h-5 w-5 text-blue-600" />}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}

                {currentStep === 2 && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Name</label>
                        <Input
                          value={developerProfile.name}
                          onChange={(e) => setDeveloperProfile((prev) => ({ ...prev, name: e.target.value }))}
                          placeholder="Your name"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Email</label>
                        <Input
                          type="email"
                          value={developerProfile.email}
                          onChange={(e) => setDeveloperProfile((prev) => ({ ...prev, email: e.target.value }))}
                          placeholder="your@email.com"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Company (Optional)</label>
                      <Input
                        value={developerProfile.company}
                        onChange={(e) => setDeveloperProfile((prev) => ({ ...prev, company: e.target.value }))}
                        placeholder="Your company or organization"
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Development Experience</label>
                      <select
                        className="w-full p-2 border rounded"
                        value={developerProfile.experience}
                        onChange={(e) => setDeveloperProfile((prev) => ({ ...prev, experience: e.target.value }))}
                      >
                        <option value="">Select experience level</option>
                        <option value="beginner">Beginner (0-1 years)</option>
                        <option value="intermediate">Intermediate (2-5 years)</option>
                        <option value="advanced">Advanced (5+ years)</option>
                        <option value="expert">Expert (10+ years)</option>
                      </select>
                    </div>
                  </div>
                )}

                {currentStep === 3 && (
                  <div className="space-y-4">
                    <div className="bg-slate-100 rounded-lg p-4">
                      <h4 className="font-medium mb-2">Choose your API tier:</h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {[
                          {
                            name: "Free",
                            requests: "1,000/month",
                            price: "$0",
                            features: ["Basic AI agents", "Community support"],
                          },
                          {
                            name: "Pro",
                            requests: "100,000/month",
                            price: "$29",
                            features: ["All AI agents", "Priority support", "Advanced features"],
                          },
                          {
                            name: "Enterprise",
                            requests: "Unlimited",
                            price: "Custom",
                            features: ["Custom deployment", "SLA guarantee", "Dedicated support"],
                          },
                        ].map((tier) => (
                          <div key={tier.name} className="p-3 border rounded bg-white">
                            <h5 className="font-medium">{tier.name}</h5>
                            <p className="text-sm text-slate-600">{tier.requests}</p>
                            <p className="text-lg font-bold text-blue-600">{tier.price}</p>
                            <ul className="text-xs text-slate-500 mt-2">
                              {tier.features.map((feature, i) => (
                                <li key={i}>• {feature}</li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Button className="w-full">Generate API Key</Button>
                  </div>
                )}

                {currentStep === 4 && (
                  <div className="space-y-4">
                    <div className="bg-slate-900 rounded-lg p-4">
                      <pre className="text-green-400 text-sm overflow-x-auto">
                        <code>{`// Your first API call
const response = await fetch('https://mbtq.dev/api/agents/career-matching', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer mbtq_your_api_key_here',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    skills: ['JavaScript', 'React'],
    accommodations: ['ASL interpreter'],
    preferences: ['remote work']
  })
});

const result = await response.json();
console.log('Career matches:', result.matches);`}</code>
                      </pre>
                    </div>

                    <Button className="w-full">
                      <Play className="h-4 w-4 mr-2" />
                      Run Example
                    </Button>
                  </div>
                )}

                {currentStep === 5 && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="text-center p-4 border rounded-lg">
                        <Users className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                        <h3 className="font-medium">Developer Forum</h3>
                        <p className="text-sm text-slate-600">ASL video discussions</p>
                        <Button size="sm" className="mt-2">
                          Join Forum
                        </Button>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <Hand className="h-8 w-8 mx-auto mb-2 text-green-500" />
                        <h3 className="font-medium">Mentorship</h3>
                        <p className="text-sm text-slate-600">Connect with deaf mentors</p>
                        <Button size="sm" className="mt-2">
                          Find Mentor
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Navigation */}
                <div className="flex items-center justify-between pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                    disabled={currentStep === 0}
                  >
                    Previous
                  </Button>

                  <Button
                    onClick={() => {
                      if (currentStep < onboardingSteps.length - 1) {
                        setCurrentStep(currentStep + 1)
                      } else {
                        // Complete onboarding
                        window.location.href = "https://mbtq.dev/dashboard"
                      }
                    }}
                  >
                    {currentStep === onboardingSteps.length - 1 ? (
                      <>
                        <Rocket className="h-4 w-4 mr-2" />
                        Start Building
                      </>
                    ) : (
                      <>
                        Next
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Accessibility Features Bar */}
        <div className="fixed bottom-4 left-4 right-4 max-w-4xl mx-auto">
          <Card className="bg-black/90 text-white border-0">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Badge variant="secondary" className="bg-blue-600">
                    <Eye className="h-3 w-3 mr-1" />
                    Visual Mode
                  </Badge>
                  <Badge variant="secondary" className="bg-green-600">
                    <Hand className="h-3 w-3 mr-1" />
                    ASL Active
                  </Badge>
                  <Badge variant="secondary" className="bg-purple-600">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    Captions On
                  </Badge>
                </div>

                <div className="text-sm">🌟 Deaf-First Experience Active</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
