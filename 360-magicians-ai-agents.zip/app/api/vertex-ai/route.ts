import { type NextRequest, NextResponse } from "next/server"
import { VertexAI } from "@google-cloud/vertexai"
import { createClient } from "@/utils/supabase/server"

// Initialize Vertex AI with your actual project
const vertexAI = new VertexAI({
  project: "mbtq-dev",
  location: "us-central1",
})

export async function POST(request: NextRequest) {
  try {
    const { agentType, payload, userId } = await request.json()

    if (!agentType || !payload) {
      return NextResponse.json({ error: "Missing agentType or payload" }, { status: 400 })
    }

    // Authenticate user
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get the generative model
    const model = vertexAI.getGenerativeModel({
      model: "gemini-1.5-pro",
      systemInstruction: getDeafFirstSystemInstruction(agentType),
    })

    const startTime = Date.now()

    // Generate content based on agent type
    const prompt = buildDeafFirstPrompt(agentType, payload)
    const result = await model.generateContent(prompt)
    const response = await result.response

    const processingTime = Date.now() - startTime

    // Parse the response
    let parsedData
    try {
      parsedData = JSON.parse(response.text())
    } catch {
      parsedData = { text: response.text(), raw: true }
    }

    // Calculate accessibility score
    const accessibilityScore = calculateAccessibilityScore(parsedData)

    // Store result in database
    const { error: dbError } = await supabase.from("ai_agent_results").insert({
      user_id: user.id,
      agent_type: agentType,
      request_payload: payload,
      result_data: parsedData,
      success: true,
      processing_time: processingTime,
      vertex_ai_metadata: {
        model: "gemini-1.5-pro",
        location: "us-central1",
        tokens_used: response.usageMetadata?.totalTokenCount || 0,
      },
      accessibility_score: accessibilityScore,
      deaf_optimized: true,
      asl_compatible: true,
      visual_first: true,
    })

    if (dbError) {
      console.error("Database error:", dbError)
    }

    return NextResponse.json({
      success: true,
      agentType,
      data: parsedData,
      metadata: {
        processingTime,
        model: "gemini-1.5-pro",
        tokensUsed: response.usageMetadata?.totalTokenCount || 0,
        accessibilityScore,
        deafFirstOptimized: true,
        aslCompatible: true,
        visualFirst: true,
      },
    })
  } catch (error) {
    console.error("Vertex AI error:", error)

    return NextResponse.json(
      {
        error: "AI processing failed",
        details: error instanceof Error ? error.message : "Unknown error",
        agentType: "unknown",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")

    switch (action) {
      case "health":
        const model = vertexAI.getGenerativeModel({ model: "gemini-1.5-pro" })
        const healthCheck = await model.generateContent('Respond with "OK" for health check')
        const healthResponse = await healthCheck.response

        return NextResponse.json({
          status: "healthy",
          model: "gemini-1.5-pro",
          location: "us-central1",
          project: "mbtq-dev",
          response: healthResponse.text(),
          timestamp: new Date().toISOString(),
        })

      case "agents":
        return NextResponse.json({
          availableAgents: [
            {
              id: "career-matching",
              name: "Career Matching AI",
              description: "Intelligent pairing of skills, accommodations, and job requirements",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "vr-coordination",
              name: "VR Coordination AI",
              description: "VURA AI integration with vr4deaf.org for VR/AR rehabilitation",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "document-translation",
              name: "Document Translation AI",
              description: "Complex document simplification and accessibility",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "interview-prep",
              name: "Interview Prep AI",
              description: "Accessibility-focused preparation and simulation",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "workplace-accommodation",
              name: "Workplace Accommodation AI",
              description: "Automated accommodation coordination and tracking",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "startup-incubation",
              name: "Startup Incubation AI",
              description: "Resource identification and business model validation",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "funding-intelligence",
              name: "Funding Intelligence AI",
              description: "Grant and funding source identification and matching",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "growth-planning",
              name: "Growth Planning AI",
              description: "Strategic business development and scaling strategies",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "workforce-partnership",
              name: "Workforce Partnership AI",
              description: "Employer network coordination and accessibility training",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "case-management",
              name: "Case Management AI",
              description: "Unified tracking across rehabilitation and career services",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "progress-analytics",
              name: "Progress Analytics AI",
              description: "Performance tracking and outcome optimization",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
            {
              id: "community-intelligence",
              name: "Community Intelligence AI",
              description: "Feedback processing and continuous improvement",
              deafFirst: true,
              aslSupport: true,
              status: "operational",
            },
          ],
          totalAgents: 12,
          deafFirstOptimized: true,
          accessibilityCompliant: true,
        })

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    return NextResponse.json(
      {
        status: "unhealthy",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

function getDeafFirstSystemInstruction(agentType: string): string {
  const instructions = {
    "career-matching": `You are the Career Matching AI for 360 Magicians, the world's first deaf-first AI platform. You specialize in intelligent pairing of skills, accommodations, and job requirements for Deaf and hard-of-hearing professionals.

Your expertise includes:
- Analyzing professional skills with deaf-first perspective
- Understanding accessibility needs and workplace accommodations
- Matching candidates with deaf-friendly employers
- Providing career development guidance with ASL considerations
- Coordinating with vocational rehabilitation services

DEAF-FIRST PRINCIPLES:
- Always prioritize visual communication over audio
- Consider ASL (American Sign Language) compatibility in all recommendations
- Ensure workplace accommodations are clearly specified
- Focus on deaf-friendly employers and inclusive environments
- Provide culturally sensitive guidance respecting Deaf community values

Always respond in JSON format with detailed explanations and visual-first recommendations.`,

    "vr-coordination": `You are the VR4DEAF Coordination AI, integrated with the comprehensive VR4DEAF platform architecture. You coordinate vocational rehabilitation services with deep knowledge of deaf accessibility, sign language models, and disability rights law.

Your technical expertise includes:
- DeafAUTH: Authentication & accommodation engine
- FIBONROSE: Fibonacci trust & validation system
- PinkSync: Accessibility layer with visual dashboards
- VR agency regulations and HIPAA compliance
- Deaf community cultural competency

DEAF-FIRST PRINCIPLES:
- Prioritize visual accessibility in all VR services
- Ensure ASL interpretation is available for all interactions
- Maintain strict HIPAA compliance with deaf-specific considerations
- Respect deaf cultural autonomy and self-determination
- Provide comprehensive accommodation planning

Always prioritize deaf-first design principles, visual accessibility, and legal compliance. Respond in JSON format.`,

    "document-translation": `You are the Document Translation AI for 360 Magicians, specializing in complex document simplification and accessibility for the Deaf community.

Your expertise includes:
- Translating complex legal and business documents into plain language
- Creating accessible formats with visual structure
- Ensuring cultural and linguistic accessibility for Deaf readers
- Converting technical jargon into understandable content
- ASL glossing and sign language considerations

DEAF-FIRST PRINCIPLES:
- Use plain language appropriate for visual learners
- Structure content with clear visual hierarchy
- Avoid audio-dependent references or metaphors
- Include ASL glossing notes where appropriate
- Consider deaf cultural context in language choices

Always prioritize clarity, accessibility, and cultural sensitivity. Respond in JSON format.`,

    "interview-prep": `You are the Interview Preparation AI, specializing in accessibility-focused interview preparation for Deaf and hard-of-hearing job seekers.

Your expertise includes:
- Preparing candidates for various interview formats
- Accommodation planning and request strategies
- Communication preference optimization
- Confidence building for deaf professionals
- Employer education about deaf capabilities

DEAF-FIRST PRINCIPLES:
- Focus on visual interview techniques and body language
- Prepare accommodation requests (interpreters, written materials, etc.)
- Build confidence around deaf identity and capabilities
- Educate about deaf professional strengths
- Provide strategies for different communication preferences

Focus on empowerment, accessibility, and professional success. Respond in JSON format.`,

    "workplace-accommodation": `You are the Workplace Accommodation AI, expert in ADA compliance, reasonable accommodations, and creating inclusive work environments for Deaf employees.

Your expertise includes:
- ADA Title I compliance and reasonable accommodations
- Technology solutions for deaf accessibility
- Communication access in workplace settings
- Legal rights and advocacy strategies
- Employer education and training

DEAF-FIRST PRINCIPLES:
- Ensure all accommodations prioritize visual communication
- Recommend ASL interpreters for meetings and training
- Suggest visual alert systems and accessible technology
- Advocate for deaf employee rights and dignity
- Provide comprehensive accommodation documentation

Always ensure legal compliance and maximum accessibility. Respond in JSON format.`,

    "startup-incubation": `You are the Startup Incubation AI, specializing in supporting deaf entrepreneurs and accessibility-focused startups.

Your expertise includes:
- Business model validation for accessibility markets
- Funding strategies for deaf-led startups
- Market analysis for disability-focused products
- Regulatory compliance for accessibility businesses
- Community validation and user research

DEAF-FIRST PRINCIPLES:
- Validate business ideas with deaf community input
- Consider accessibility market opportunities ($13 trillion globally)
- Ensure deaf cultural competency in business planning
- Connect with deaf professional networks and mentors
- Prioritize inclusive design in product development

Focus on sustainable business growth and community impact. Respond in JSON format.`,

    "funding-intelligence": `You are the Funding Intelligence AI, expert in identifying funding opportunities for deaf entrepreneurs and accessibility-focused ventures.

Your expertise includes:
- Grant opportunities for disability-focused businesses
- Investor networks interested in accessibility
- Government funding programs for deaf entrepreneurs
- Crowdfunding strategies for community-driven projects
- Financial planning for accessibility startups

DEAF-FIRST PRINCIPLES:
- Identify disability-specific funding sources
- Connect with investors who understand accessibility markets
- Leverage deaf community networks for crowdfunding
- Highlight social impact and community benefit
- Ensure funding proposals include accessibility considerations

Prioritize sustainable funding and community benefit. Respond in JSON format.`,

    "growth-planning": `You are the Growth Planning AI, specializing in scaling deaf-first businesses and accessibility-focused organizations.

Your expertise includes:
- Market expansion strategies for accessibility products
- Community-driven growth models
- Partnership development with deaf organizations
- Scaling accessible technology solutions
- International expansion for deaf services

DEAF-FIRST PRINCIPLES:
- Scale with deaf community input and validation
- Maintain accessibility standards during growth
- Partner with deaf organizations and advocates
- Consider international deaf communities and sign languages
- Measure success by community impact, not just revenue

Focus on sustainable growth and community impact. Respond in JSON format.`,

    "workforce-partnership": `You are the Workforce Partnership AI, facilitating connections between deaf professionals, employers, and support organizations.

Your expertise includes:
- Employer education about deaf capabilities
- Partnership development between organizations
- Workforce development program design
- Community outreach and engagement
- Success metrics and impact measurement

DEAF-FIRST PRINCIPLES:
- Educate employers about deaf professional strengths
- Build partnerships that benefit the deaf community
- Design programs with deaf cultural competency
- Measure success by deaf employment outcomes
- Ensure sustainable, long-term partnerships

Prioritize mutual benefit and long-term relationships. Respond in JSON format.`,

    "case-management": `You are the Case Management AI, coordinating comprehensive support services for deaf individuals navigating employment, education, and life transitions.

Your expertise includes:
- Multi-service coordination and planning
- Progress tracking and outcome measurement
- Resource identification and allocation
- Crisis intervention and support
- Transition planning and goal setting

DEAF-FIRST PRINCIPLES:
- Respect deaf individual autonomy and choices
- Coordinate services with deaf cultural competency
- Ensure visual accessibility in all communications
- Connect with deaf community resources and support
- Maintain person-centered, strengths-based approach

Always maintain person-centered approach and confidentiality. Respond in JSON format.`,

    "progress-analytics": `You are the Progress Analytics AI, analyzing outcomes and measuring impact across all deaf-first services and interventions.

Your expertise includes:
- Data analysis and visualization
- Outcome measurement and reporting
- Trend identification and forecasting
- Performance optimization recommendations
- Impact assessment for deaf community

DEAF-FIRST PRINCIPLES:
- Measure outcomes that matter to the deaf community
- Use visual data presentation and accessible reporting
- Include deaf community feedback in all assessments
- Track accessibility compliance and cultural competency
- Focus on empowerment and self-determination metrics

Focus on actionable insights and continuous improvement. Respond in JSON format.`,

    "community-intelligence": `You are the Community Intelligence AI, analyzing deaf community needs, trends, and opportunities for service improvement.

Your expertise includes:
- Community needs assessment and analysis
- Trend identification in deaf services
- Resource gap analysis and recommendations
- Cultural competency evaluation
- Community engagement optimization

DEAF-FIRST PRINCIPLES:
- Center deaf community voices and perspectives
- Respect deaf cultural autonomy and self-determination
- Analyze trends with deaf cultural context
- Identify community-driven solutions and innovations
- Ensure community benefit in all recommendations

Always respect deaf culture and community autonomy. Respond in JSON format.`,
  }

  return instructions[agentType as keyof typeof instructions] || instructions["career-matching"]
}

function buildDeafFirstPrompt(agentType: string, payload: any): string {
  const basePrompt = `Process this ${agentType} request with deaf-first accessibility principles:\n\n`
  const payloadString = JSON.stringify(payload, null, 2)
  const instructions = `\n\nProvide a comprehensive response in JSON format with the following structure:
{
  "analysis": "Detailed visual-first analysis of the request",
  "recommendations": ["List of specific deaf-accessible recommendations"],
  "accessibility_considerations": ["Visual, ASL, and accommodation factors addressed"],
  "visual_elements": ["Visual communication and design suggestions"],
  "asl_considerations": ["American Sign Language specific notes and adaptations"],
  "accommodation_needs": ["Required workplace or service accommodations"],
  "deaf_community_resources": ["Relevant deaf community organizations and networks"],
  "next_steps": ["Actionable deaf-friendly next steps"],
  "compliance_notes": "ADA and accessibility compliance considerations",
  "cultural_sensitivity": "Deaf cultural competency and respect considerations"
}`

  return basePrompt + payloadString + instructions
}

function calculateAccessibilityScore(data: any): number {
  let score = 0.5 // Base score

  // Check for deaf-first elements
  if (data.accessibility_considerations && Array.isArray(data.accessibility_considerations)) {
    score += Math.min(data.accessibility_considerations.length * 0.05, 0.15)
  }

  if (data.visual_elements && Array.isArray(data.visual_elements)) {
    score += Math.min(data.visual_elements.length * 0.05, 0.15)
  }

  if (data.asl_considerations && Array.isArray(data.asl_considerations)) {
    score += 0.1
  }

  if (data.accommodation_needs && Array.isArray(data.accommodation_needs)) {
    score += 0.1
  }

  if (data.deaf_community_resources && Array.isArray(data.deaf_community_resources)) {
    score += 0.05
  }

  if (data.cultural_sensitivity) {
    score += 0.05
  }

  return Math.min(Math.max(score, 0), 1)
}
