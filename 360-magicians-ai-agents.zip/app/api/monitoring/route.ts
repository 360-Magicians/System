import { type NextRequest, NextResponse } from "next/server"
import { gcpMonitoring } from "@/lib/gcp-monitoring"
import { createClient } from "@/utils/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const { action, data } = await request.json()

    // Authenticate user (admin only for monitoring operations)
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user has admin privileges
    const { data: profile } = await supabase.from("user_profiles").select("role").eq("user_id", user.id).single()

    if (profile?.role !== "admin" && profile?.role !== "developer") {
      return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
    }

    let result

    switch (action) {
      case "write_accessibility_metric":
        result = await gcpMonitoring.writeAccessibilityMetric(
          data.metricType,
          data.value,
          data.serviceName,
          data.accessibilityCategory,
          data.deafOptimized,
        )
        break

      case "write_asl_video_metric":
        result = await gcpMonitoring.writeASLVideoMetric(
          data.processingStage,
          data.successRate,
          data.processingTime,
          data.videoQuality,
        )
        break

      case "write_vertex_ai_metrics":
        result = await gcpMonitoring.writeVertexAIMetrics(
          data.agentType,
          data.responseTime,
          data.successRate,
          data.accessibilityScore,
          data.tokensUsed,
        )
        break

      case "write_deaf_satisfaction_metrics":
        result = await gcpMonitoring.writeDeafSatisfactionMetrics(
          data.featureArea,
          data.satisfactionScore,
          data.accessibilityRating,
          data.aslQualityRating,
          data.userSegment,
        )
        break

      case "create_accessibility_alert":
        result = await gcpMonitoring.createAccessibilityAlert(
          data.displayName,
          data.threshold,
          data.notificationChannels,
        )
        break

      case "initialize_platform_metrics":
        result = await gcpMonitoring.initializePlatformMetrics()
        break

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    // Log the monitoring action
    await supabase.from("admin_actions").insert({
      user_id: user.id,
      action: `monitoring_${action}`,
      details: data,
      timestamp: new Date().toISOString(),
    })

    return NextResponse.json({
      success: true,
      action,
      result,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Monitoring API error:", error)

    return NextResponse.json(
      {
        error: "Monitoring operation failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")
    const timeRange = (searchParams.get("timeRange") as "1h" | "24h" | "7d" | "30d") || "24h"

    // Authenticate user
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    let result

    switch (action) {
      case "health":
        result = await gcpMonitoring.healthCheck()
        break

      case "dashboard":
        result = await gcpMonitoring.getAccessibilityDashboard(timeRange)
        break

      case "platform_metrics":
        // Get platform-wide metrics from database
        const { data: metrics, error: metricsError } = await supabase
          .from("accessibility_compliance")
          .select("*")
          .gte("tested_at", new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString())
          .order("tested_at", { ascending: false })

        if (metricsError) {
          throw new Error(`Failed to fetch metrics: ${metricsError.message}`)
        }

        result = {
          success: true,
          metrics,
          summary: {
            totalServices: new Set(metrics?.map((m) => m.service_name)).size,
            averageCompliance: metrics?.reduce((acc, m) => acc + (m.compliance_score || 0), 0) / (metrics?.length || 1),
            deafAccessibleServices: metrics?.filter((m) => m.deaf_accessible).length,
            aslSupportedServices: metrics?.filter((m) => m.asl_supported).length,
          },
        }
        break

      case "ai_performance":
        // Get AI agent performance metrics
        const { data: aiMetrics, error: aiError } = await supabase.rpc("get_top_performing_agents", {
          p_limit: 12,
          p_days: 7,
        })

        if (aiError) {
          throw new Error(`Failed to fetch AI metrics: ${aiError.message}`)
        }

        result = {
          success: true,
          aiAgents: aiMetrics,
          timestamp: new Date().toISOString(),
        }
        break

      case "deaf_feedback":
        // Get deaf community feedback metrics
        const { data: feedback, error: feedbackError } = await supabase
          .from("deaf_community_feedback")
          .select("*")
          .gte("created_at", new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
          .order("created_at", { ascending: false })

        if (feedbackError) {
          throw new Error(`Failed to fetch feedback: ${feedbackError.message}`)
        }

        const feedbackSummary = {
          totalFeedback: feedback?.length || 0,
          averageSatisfaction:
            feedback?.reduce((acc, f) => acc + (f.satisfaction_score || 0), 0) / (feedback?.length || 1),
          averageAccessibility:
            feedback?.reduce((acc, f) => acc + (f.accessibility_rating || 0), 0) / (feedback?.length || 1),
          averageASLQuality:
            feedback?.reduce((acc, f) => acc + (f.asl_quality_rating || 0), 0) / (feedback?.length || 1),
          userSegments: feedback?.reduce(
            (acc, f) => {
              acc[f.user_segment] = (acc[f.user_segment] || 0) + 1
              return acc
            },
            {} as Record<string, number>,
          ),
        }

        result = {
          success: true,
          feedback,
          summary: feedbackSummary,
          timestamp: new Date().toISOString(),
        }
        break

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Monitoring GET error:", error)

    return NextResponse.json(
      {
        error: "Failed to fetch monitoring data",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

// PUT endpoint for updating monitoring configurations
export async function PUT(request: NextRequest) {
  try {
    const { configType, settings } = await request.json()

    // Authenticate admin user
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: profile } = await supabase.from("user_profiles").select("role").eq("user_id", user.id).single()

    if (profile?.role !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    let result

    switch (configType) {
      case "alert_thresholds":
        // Update alert thresholds in database
        const { error: updateError } = await supabase
          .from("monitoring_config")
          .upsert({
            config_type: "alert_thresholds",
            settings,
            updated_by: user.id,
            updated_at: new Date().toISOString(),
          })
          .select()

        if (updateError) {
          throw new Error(`Failed to update thresholds: ${updateError.message}`)
        }

        result = {
          success: true,
          configType,
          settings,
          updatedBy: user.id,
        }
        break

      case "accessibility_standards":
        // Update accessibility compliance standards
        const { error: standardsError } = await supabase
          .from("monitoring_config")
          .upsert({
            config_type: "accessibility_standards",
            settings,
            updated_by: user.id,
            updated_at: new Date().toISOString(),
          })
          .select()

        if (standardsError) {
          throw new Error(`Failed to update standards: ${standardsError.message}`)
        }

        result = {
          success: true,
          configType,
          settings,
          updatedBy: user.id,
        }
        break

      default:
        return NextResponse.json({ error: "Invalid config type" }, { status: 400 })
    }

    // Log the configuration change
    await supabase.from("admin_actions").insert({
      user_id: user.id,
      action: `update_monitoring_config_${configType}`,
      details: settings,
      timestamp: new Date().toISOString(),
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Monitoring PUT error:", error)

    return NextResponse.json(
      {
        error: "Failed to update monitoring configuration",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
