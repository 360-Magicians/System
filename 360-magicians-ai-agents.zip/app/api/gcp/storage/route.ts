import { type NextRequest, NextResponse } from "next/server"
import { gcpStorage } from "@/lib/gcp-storage"
import { createClient } from "@/utils/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const fileType = formData.get("type") as string
    const metadata = JSON.parse((formData.get("metadata") as string) || "{}")

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Get user authentication
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Convert file to buffer
    const fileBuffer = Buffer.from(await file.arrayBuffer())

    let uploadResult

    // Handle different file types
    if (fileType === "asl-video") {
      uploadResult = await gcpStorage.uploadASLVideo(fileBuffer, file.name, {
        userId: user.id,
        videoType: metadata.videoType || "community",
        duration: metadata.duration,
        language: metadata.language || "ASL",
        description: metadata.description,
      })
    } else {
      uploadResult = await gcpStorage.uploadStaticAsset(fileBuffer, file.name, file.type, {
        uploadedBy: user.id,
        category: metadata.category || "general",
        description: metadata.description || "",
      })
    }

    // Log the upload in database
    const { error: logError } = await supabase.from("file_uploads").insert({
      user_id: user.id,
      file_id: uploadResult.fileId,
      original_name: file.name,
      file_type: fileType,
      bucket_name: uploadResult.metadata.bucket,
      file_size: uploadResult.metadata.size,
      public_url: uploadResult.publicUrl,
      signed_url: uploadResult.signedUrl,
      metadata: uploadResult.metadata,
      created_at: new Date().toISOString(),
    })

    if (logError) {
      console.error("Failed to log upload:", logError)
    }

    return NextResponse.json({
      success: true,
      upload: uploadResult,
      deafAccessible: true,
    })
  } catch (error) {
    console.error("Upload error:", error)

    return NextResponse.json(
      {
        error: "Upload failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")
    const bucket = searchParams.get("bucket")
    const fileName = searchParams.get("fileName")

    // Get user authentication
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    switch (action) {
      case "health":
        const healthResult = await gcpStorage.healthCheck()
        return NextResponse.json(healthResult)

      case "list":
        if (!bucket) {
          return NextResponse.json({ error: "Bucket parameter required for list action" }, { status: 400 })
        }

        const listResult = await gcpStorage.listFiles(bucket, {
          prefix: searchParams.get("prefix") || undefined,
          maxResults: Number.parseInt(searchParams.get("maxResults") || "100"),
        })

        return NextResponse.json(listResult)

      case "metadata":
        if (!bucket || !fileName) {
          return NextResponse.json(
            { error: "Bucket and fileName parameters required for metadata action" },
            { status: 400 },
          )
        }

        const metadataResult = await gcpStorage.getFileMetadata(bucket, fileName)
        return NextResponse.json(metadataResult)

      default:
        return NextResponse.json({ error: "Invalid action parameter" }, { status: 400 })
    }
  } catch (error) {
    console.error("Storage API error:", error)

    return NextResponse.json(
      {
        error: "Storage operation failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const bucket = searchParams.get("bucket")
    const fileName = searchParams.get("fileName")

    if (!bucket || !fileName) {
      return NextResponse.json({ error: "Bucket and fileName parameters required" }, { status: 400 })
    }

    // Get user authentication
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Check if user owns the file
    const { data: fileRecord, error: fetchError } = await supabase
      .from("file_uploads")
      .select("*")
      .eq("user_id", user.id)
      .eq("file_name", fileName)
      .single()

    if (fetchError || !fileRecord) {
      return NextResponse.json({ error: "File not found or access denied" }, { status: 404 })
    }

    // Delete from storage
    const deleteResult = await gcpStorage.deleteFile(bucket, fileName)

    // Update database record
    const { error: updateError } = await supabase
      .from("file_uploads")
      .update({
        deleted_at: new Date().toISOString(),
        status: "deleted",
      })
      .eq("file_id", fileRecord.file_id)

    if (updateError) {
      console.error("Failed to update deletion record:", updateError)
    }

    return NextResponse.json({
      success: true,
      deleted: deleteResult,
      deafAccessible: true,
    })
  } catch (error) {
    console.error("Delete error:", error)

    return NextResponse.json(
      {
        error: "Delete failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
