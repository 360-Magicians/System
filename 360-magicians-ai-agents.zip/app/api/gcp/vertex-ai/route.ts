import { type NextRequest, NextResponse } from "next/server"
import { vertexAIClient } from "@/lib/vertex-ai-client"
import { createClient } from "@/utils/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const { agentType, payload, userId } = await request.json()

    // Validate required fields
    if (!agentType || !payload) {
      return NextResponse.json({ error: "Missing required fields: agentType, payload" }, { status: 400 })
    }

    // Get user authentication
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized - Valid authentication required" }, { status: 401 })
    }

    // Log API usage for analytics
    const { error: logError } = await supabase.from("api_usage").insert({
      user_id: user.id,
      endpoint: "vertex-ai",
      agent_type: agentType,
      request_payload: payload,
      timestamp: new Date().toISOString(),
      ip_address: request.ip || "unknown",
      user_agent: request.headers.get("user-agent") || "unknown",
    })

    if (logError) {
      console.error("Failed to log API usage:", logError)
    }

    // Process request based on agent type
    let result
    switch (agentType) {
      case "career-matching":
        result = await vertexAIClient.matchCareer(payload)
        break

      case "vr-coordination":
        result = await vertexAIClient.coordinateVR(payload)
        break

      case "document-translation":
        result = await vertexAIClient.translateDocument(payload)
        break

      case "interview-prep":
        result = await vertexAIClient.prepareInterview(payload)
        break

      case "workplace-accommodation":
        result = await vertexAIClient.recommendAccommodations(payload)
        break

      case "startup-incubation":
        result = await vertexAIClient.incubateStartup(payload)
        break

      case "funding-intelligence":
        result = await vertexAIClient.analyzeFunding(payload)
        break

      case "growth-planning":
        result = await vertexAIClient.planGrowth(payload)
        break

      case "workforce-partnership":
        result = await vertexAIClient.facilitatePartnership(payload)
        break

      case "case-management":
        result = await vertexAIClient.manageCases(payload)
        break

      case "progress-analytics":
        result = await vertexAIClient.analyzeProgress(payload)
        break

      case "community-intelligence":
        result = await vertexAIClient.analyzeCommunity(payload)
        break

      default:
        return NextResponse.json({ error: `Unknown agent type: ${agentType}` }, { status: 400 })
    }

    // Store successful result
    const { error: resultError } = await supabase.from("ai_agent_results").insert({
      user_id: user.id,
      agent_type: agentType,
      request_payload: payload,
      result_data: result.data,
      success: result.success,
      vertex_ai_metadata: result.vertexAIMetadata || result.vuraIntegration,
      created_at: new Date().toISOString(),
    })

    if (resultError) {
      console.error("Failed to store AI result:", resultError)
    }

    return NextResponse.json({
      success: true,
      agentType,
      result: result.data,
      metadata: {
        userId: user.id,
        timestamp: new Date().toISOString(),
        vertexAI: result.vertexAIMetadata || result.vuraIntegration,
        deafFirstOptimized: true,
      },
    })
  } catch (error) {
    console.error("Vertex AI API error:", error)

    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error",
        deafAccessible: true,
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    // Health check for Vertex AI
    const healthResult = await vertexAIClient.healthCheck()

    return NextResponse.json({
      status: "healthy",
      vertexAI: healthResult,
      availableAgents: [
        "career-matching",
        "vr-coordination",
        "document-translation",
        "interview-prep",
        "workplace-accommodation",
        "startup-incubation",
        "funding-intelligence",
        "growth-planning",
        "workforce-partnership",
        "case-management",
        "progress-analytics",
        "community-intelligence",
      ],
      deafFirstOptimized: true,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Vertex AI health check error:", error)

    return NextResponse.json(
      {
        status: "unhealthy",
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      },
      { status: 500 },
    )
  }
}
