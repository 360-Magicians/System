import { type NextRequest, NextResponse } from "next/server"
import { vertexAIClient } from "@/lib/vertex-ai-client"
import { createClient } from "@/utils/supabase/server"

export async function POST(request: NextRequest) {
  try {
    const { messages, agentType = "career-matching", userId } = await request.json()

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Messages array is required" }, { status: 400 })
    }

    // Authenticate user
    const supabase = await createClient()
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get the latest message
    const latestMessage = messages[messages.length - 1]
    if (!latestMessage.content) {
      return NextResponse.json({ error: "Message content is required" }, { status: 400 })
    }

    // Prepare payload for the AI agent
    const payload = {
      query: latestMessage.content,
      context: messages.slice(0, -1).map((msg: any) => ({
        role: msg.role,
        content: msg.content,
      })),
      deafFirst: true,
      aslSupport: true,
      visualFirst: true,
    }

    let result

    // Route to appropriate AI agent based on agentType
    switch (agentType) {
      case "career-matching":
        result = await vertexAIClient.matchCareer(payload, user.id)
        break
      case "vr-coordination":
        result = await vertexAIClient.coordinateVR(payload, user.id)
        break
      case "document-translation":
        result = await vertexAIClient.translateDocument(payload, user.id)
        break
      case "interview-prep":
        result = await vertexAIClient.prepareInterview(payload, user.id)
        break
      case "workplace-accommodation":
        result = await vertexAIClient.recommendAccommodations(payload, user.id)
        break
      case "startup-incubation":
        result = await vertexAIClient.incubateStartup(payload, user.id)
        break
      case "funding-intelligence":
        result = await vertexAIClient.analyzeFunding(payload, user.id)
        break
      case "growth-planning":
        result = await vertexAIClient.planGrowth(payload, user.id)
        break
      case "workforce-partnership":
        result = await vertexAIClient.facilitatePartnership(payload, user.id)
        break
      case "case-management":
        result = await vertexAIClient.manageCases(payload, user.id)
        break
      case "progress-analytics":
        result = await vertexAIClient.analyzeProgress(payload, user.id)
        break
      case "community-intelligence":
        result = await vertexAIClient.analyzeCommunity(payload, user.id)
        break
      default:
        result = await vertexAIClient.matchCareer(payload, user.id)
    }

    if (!result.success) {
      return NextResponse.json({ error: "AI agent processing failed" }, { status: 500 })
    }

    // Format response for chat interface
    const chatResponse = {
      role: "assistant",
      content: result.data.analysis || "I've processed your request with deaf-first accessibility in mind.",
      agentType,
      metadata: result.metadata,
      recommendations: result.data.recommendations || [],
      accessibilityFeatures: result.data.accessibility_features || [],
      nextSteps: result.data.next_steps || [],
      deafFirstOptimized: true,
      aslCompatible: true,
      visualFirst: true,
    }

    // Store chat interaction
    await supabase.from("chat_interactions").insert({
      user_id: user.id,
      agent_type: agentType,
      user_message: latestMessage.content,
      ai_response: chatResponse.content,
      metadata: result.metadata,
      accessibility_score: result.metadata?.accessibilityScore || 0.95,
      deaf_optimized: true,
    })

    return NextResponse.json({
      success: true,
      message: chatResponse,
      agentType,
      metadata: result.metadata,
    })
  } catch (error) {
    console.error("Chat API error:", error)

    return NextResponse.json(
      {
        error: "Chat processing failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")

    switch (action) {
      case "agents":
        return NextResponse.json({
          availableAgents: [
            {
              id: "career-matching",
              name: "Career Matching AI",
              description: "Intelligent pairing of skills with deaf-friendly employers",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "vr-coordination",
              name: "VR4DEAF Coordination AI",
              description: "Vocational rehabilitation services coordination",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "document-translation",
              name: "Document Translation AI",
              description: "Complex document simplification for accessibility",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "interview-prep",
              name: "Interview Preparation AI",
              description: "Accessibility-focused interview preparation",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "workplace-accommodation",
              name: "Workplace Accommodation AI",
              description: "ADA compliance and reasonable accommodations",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "startup-incubation",
              name: "Startup Incubation AI",
              description: "Supporting deaf entrepreneurs and accessibility startups",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "funding-intelligence",
              name: "Funding Intelligence AI",
              description: "Funding opportunities for deaf entrepreneurs",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "growth-planning",
              name: "Growth Planning AI",
              description: "Scaling deaf-first businesses and organizations",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "workforce-partnership",
              name: "Workforce Partnership AI",
              description: "Connecting deaf professionals with employers",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "case-management",
              name: "Case Management AI",
              description: "Comprehensive support services coordination",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "progress-analytics",
              name: "Progress Analytics AI",
              description: "Analyzing outcomes and measuring impact",
              deafFirst: true,
              aslSupport: true,
            },
            {
              id: "community-intelligence",
              name: "Community Intelligence AI",
              description: "Analyzing deaf community needs and trends",
              deafFirst: true,
              aslSupport: true,
            },
          ],
          totalAgents: 12,
          deafFirstOptimized: true,
        })

      case "health":
        const healthCheck = await vertexAIClient.healthCheck()
        return NextResponse.json({
          status: "healthy",
          chatAPI: "operational",
          vertexAI: healthCheck.status,
          deafFirstFeatures: "enabled",
          aslSupport: "active",
          timestamp: new Date().toISOString(),
        })

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Chat GET error:", error)

    return NextResponse.json(
      {
        error: "Failed to process request",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
