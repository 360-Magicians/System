import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"
import { nanoid } from "nanoid"
import bcrypt from "bcryptjs"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Generate new API key
export async function POST(request: NextRequest) {
  try {
    const { userId, name, tier = "free" } = await request.json()

    if (!userId || !name) {
      return NextResponse.json({ error: "Missing required fields: userId, name" }, { status: 400 })
    }

    // Generate API key
    const keyId = nanoid(12)
    const keySecret = nanoid(32)
    const apiKey = `mbtq_${keyId}_${keySecret}`

    // Hash the key for storage
    const hashedKey = await bcrypt.hash(apiKey, 12)

    // Determine rate limits based on tier
    const rateLimits = {
      free: { requests: 1000, period: "month" },
      pro: { requests: 100000, period: "month" },
      enterprise: { requests: -1, period: "unlimited" },
    }

    // Store API key in database
    const { data: apiKeyRecord, error } = await supabase
      .from("api_keys")
      .insert({
        id: keyId,
        user_id: userId,
        name: name,
        key_hash: hashedKey,
        tier: tier,
        rate_limit: rateLimits[tier as keyof typeof rateLimits],
        is_active: true,
        created_at: new Date().toISOString(),
      })
      .select()
      .single()

    if (error) {
      console.error("API key creation error:", error)
      return NextResponse.json({ error: "Failed to create API key" }, { status: 500 })
    }

    // Log API key creation for deaf-first accessibility
    await supabase.from("accessibility_logs").insert({
      user_id: userId,
      action: "api_key_created",
      details: {
        keyName: name,
        tier: tier,
        accessibilityFeatures: ["visual_confirmation", "screen_reader_compatible"],
      },
    })

    return NextResponse.json({
      success: true,
      apiKey: apiKey, // Only return once, never store plain text
      keyId: keyId,
      name: name,
      tier: tier,
      rateLimits: rateLimits[tier as keyof typeof rateLimits],
      message: "API key created successfully! Save this key securely - it won't be shown again.",
      accessibilityNote: "This key enables deaf-first AI features across all endpoints",
    })
  } catch (error) {
    console.error("API key generation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// List user's API keys
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "Missing userId parameter" }, { status: 400 })
    }

    const { data: apiKeys, error } = await supabase
      .from("api_keys")
      .select("id, name, tier, rate_limit, is_active, created_at, last_used_at")
      .eq("user_id", userId)
      .eq("is_active", true)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("API keys fetch error:", error)
      return NextResponse.json({ error: "Failed to fetch API keys" }, { status: 500 })
    }

    return NextResponse.json({
      apiKeys: apiKeys || [],
      deafFirstFeatures: {
        visualKeyManagement: true,
        aslInstructions: true,
        screenReaderCompatible: true,
      },
    })
  } catch (error) {
    console.error("API keys list error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Revoke API key
export async function DELETE(request: NextRequest) {
  try {
    const { keyId, userId } = await request.json()

    if (!keyId || !userId) {
      return NextResponse.json({ error: "Missing required fields: keyId, userId" }, { status: 400 })
    }

    const { error } = await supabase
      .from("api_keys")
      .update({
        is_active: false,
        revoked_at: new Date().toISOString(),
      })
      .eq("id", keyId)
      .eq("user_id", userId)

    if (error) {
      console.error("API key revocation error:", error)
      return NextResponse.json({ error: "Failed to revoke API key" }, { status: 500 })
    }

    // Log revocation for accessibility tracking
    await supabase.from("accessibility_logs").insert({
      user_id: userId,
      action: "api_key_revoked",
      details: {
        keyId: keyId,
        accessibilityConfirmation: "visual_and_haptic_feedback_provided",
      },
    })

    return NextResponse.json({
      success: true,
      message: "API key revoked successfully",
      accessibilityConfirmation: "Key revocation confirmed with visual and haptic feedback",
    })
  } catch (error) {
    console.error("API key revocation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
