"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Video, Users, Hand, Pause, Share, Bookmark, Eye, ThumbsUp, Reply, Globe, Code } from "lucide-react"

export default function DeafFirstCommunity() {
  const [activeTab, setActiveTab] = useState("forum")
  const [isRecording, setIsRecording] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)

  const forumPosts = [
    {
      id: 1,
      author: {
        name: "Sarah Chen",
        avatar: "/avatars/sarah.jpg",
        badge: "Deaf Developer",
        aslLevel: "Native",
        location: "San Francisco, CA",
      },
      title: "Building accessible React components with 360 Magicians API",
      content:
        "Just integrated the Career Matching AI into our job board. The deaf-first design makes such a difference!",
      videoUrl: "/videos/sarah-react-demo.mp4",
      hasASL: true,
      likes: 24,
      replies: 8,
      views: 156,
      tags: ["React", "Accessibility", "API Integration"],
      timestamp: "2 hours ago",
    },
    {
      id: 2,
      author: {
        name: "Marcus Rodriguez",
        avatar: "/avatars/marcus.jpg",
        badge: "Community Mentor",
        aslLevel: "Fluent",
        location: "Austin, TX",
      },
      title: "VR Coordination AI success story - helped 50+ deaf job seekers",
      content: "Our VR agency integrated the VURA AI system. Results have been incredible for our deaf clients.",
      videoUrl: "/videos/marcus-vr-story.mp4",
      hasASL: true,
      likes: 67,
      replies: 23,
      views: 445,
      tags: ["VR Services", "Success Story", "Job Placement"],
      timestamp: "5 hours ago",
    },
    {
      id: 3,
      author: {
        name: "Alex Kim",
        avatar: "/avatars/alex.jpg",
        badge: "API Expert",
        aslLevel: "Intermediate",
        location: "Seattle, WA",
      },
      title: "Python SDK tutorial - Document Translation AI",
      content: "Step-by-step guide to implementing document accessibility with our Python SDK.",
      videoUrl: "/videos/alex-python-tutorial.mp4",
      hasASL: true,
      likes: 41,
      replies: 15,
      views: 289,
      tags: ["Python", "Tutorial", "Document AI"],
      timestamp: "1 day ago",
    },
  ]

  const mentors = [
    {
      name: "Dr. Jennifer Walsh",
      title: "Senior Accessibility Engineer",
      company: "Google",
      expertise: ["Web Accessibility", "WCAG Standards", "Screen Readers"],
      aslLevel: "Native",
      availability: "Available",
      rating: 4.9,
      sessions: 127,
    },
    {
      name: "David Park",
      title: "Deaf Entrepreneur",
      company: "AccessTech Startup",
      expertise: ["Startup Strategy", "Funding", "Product Development"],
      aslLevel: "Native",
      availability: "Busy",
      rating: 4.8,
      sessions: 89,
    },
    {
      name: "Maria Santos",
      title: "UX Designer",
      company: "Microsoft",
      expertise: ["Inclusive Design", "User Research", "Prototyping"],
      aslLevel: "Fluent",
      availability: "Available",
      rating: 4.9,
      sessions: 156,
    },
  ]

  const projects = [
    {
      id: 1,
      title: "Deaf-First E-commerce Platform",
      description: "Building an online shopping experience designed specifically for deaf users",
      tech: ["React", "Node.js", "360 Magicians API"],
      contributors: 8,
      seeking: ["Frontend Developer", "UX Designer"],
      progress: 65,
      lead: "Sarah Chen",
    },
    {
      id: 2,
      title: "ASL Learning Game",
      description: "Interactive game to teach ASL using VR and AI recognition",
      tech: ["Unity", "VURA AI", "Machine Learning"],
      contributors: 12,
      seeking: ["Game Developer", "3D Artist"],
      progress: 40,
      lead: "Marcus Rodriguez",
    },
    {
      id: 3,
      title: "Accessible Code Editor",
      description: "VS Code extension with deaf-first development features",
      tech: ["TypeScript", "VS Code API", "Accessibility"],
      contributors: 6,
      seeking: ["Extension Developer", "Tester"],
      progress: 80,
      lead: "Alex Kim",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Users className="h-12 w-12 text-blue-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Deaf Developer Community
            </h1>
            <Hand className="h-8 w-8 text-green-500" />
          </div>
          <p className="text-xl text-slate-600 mb-2">Connect, Learn, and Build Together</p>
          <div className="flex items-center justify-center gap-2 mb-4">
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              🌟 5,847 Deaf Developers
            </Badge>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              📹 ASL-First Discussions
            </Badge>
            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
              🤝 Mentorship Available
            </Badge>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="forum">Video Forum</TabsTrigger>
            <TabsTrigger value="mentorship">Mentorship</TabsTrigger>
            <TabsTrigger value="projects">Collaborative Projects</TabsTrigger>
            <TabsTrigger value="events">Events & Workshops</TabsTrigger>
          </TabsList>

          <TabsContent value="forum" className="space-y-6">
            {/* Create Post */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Video className="h-5 w-5" />
                  Share with the Community
                </CardTitle>
                <CardDescription>Record an ASL video or write a post</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input placeholder="What's on your mind? (ASL video or text)" />
                  </div>
                  <Button
                    variant={isRecording ? "destructive" : "default"}
                    onClick={() => setIsRecording(!isRecording)}
                  >
                    {isRecording ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Stop Recording
                      </>
                    ) : (
                      <>
                        <Video className="h-4 w-4 mr-2" />
                        Record ASL
                      </>
                    )}
                  </Button>
                </div>

                {isRecording && (
                  <div className="aspect-video bg-slate-900 rounded-lg flex items-center justify-center">
                    <div className="text-white text-center">
                      <Video className="h-12 w-12 mx-auto mb-2" />
                      <p>Recording ASL video...</p>
                      <Badge variant="destructive" className="mt-2">
                        ● REC
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Forum Posts */}
            <div className="space-y-6">
              {forumPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden">
                  <CardHeader>
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={post.author.avatar || "/placeholder.svg"} />
                        <AvatarFallback>
                          {post.author.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">{post.author.name}</h4>
                          <Badge variant="secondary">{post.author.badge}</Badge>
                          <Badge variant="outline" className="text-xs">
                            <Hand className="h-3 w-3 mr-1" />
                            {post.author.aslLevel} ASL
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600">
                          {post.author.location} • {post.timestamp}
                        </p>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div>
                      <h3 className="text-lg font-medium mb-2">{post.title}</h3>
                      <p className="text-slate-600">{post.content}</p>
                    </div>

                    {/* Video Content */}
                    <div className="aspect-video bg-slate-900 rounded-lg relative overflow-hidden">
                      <video
                        className="w-full h-full object-cover"
                        poster={`/images/post-${post.id}-poster.jpg`}
                        controls
                      >
                        <source src={post.videoUrl} type="video/mp4" />
                        <track
                          kind="captions"
                          src={`/captions/post-${post.id}-en.vtt`}
                          srcLang="en"
                          label="English"
                          default
                        />
                      </video>

                      {post.hasASL && (
                        <Badge className="absolute top-2 right-2 bg-blue-600">
                          <Hand className="h-3 w-3 mr-1" />
                          ASL
                        </Badge>
                      )}
                    </div>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-2">
                      {post.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    {/* Actions */}
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="flex items-center gap-4">
                        <Button variant="ghost" size="sm">
                          <ThumbsUp className="h-4 w-4 mr-1" />
                          {post.likes}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Reply className="h-4 w-4 mr-1" />
                          {post.replies}
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          {post.views}
                        </Button>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm">
                          <Share className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Bookmark className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="mentorship" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Find a Mentor
                </CardTitle>
                <CardDescription>Connect with experienced deaf developers and entrepreneurs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {mentors.map((mentor, index) => (
                    <Card key={index} className="border-l-4 border-l-blue-500">
                      <CardContent className="p-4">
                        <div className="text-center mb-4">
                          <Avatar className="h-16 w-16 mx-auto mb-2">
                            <AvatarImage src={`/avatars/mentor-${index + 1}.jpg`} />
                            <AvatarFallback>
                              {mentor.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <h4 className="font-medium">{mentor.name}</h4>
                          <p className="text-sm text-slate-600">{mentor.title}</p>
                          <p className="text-sm text-slate-500">{mentor.company}</p>
                        </div>

                        <div className="space-y-3">
                          <div>
                            <span className="text-sm font-medium">ASL Level:</span>
                            <Badge variant="outline" className="ml-2 text-xs">
                              <Hand className="h-3 w-3 mr-1" />
                              {mentor.aslLevel}
                            </Badge>
                          </div>

                          <div>
                            <span className="text-sm font-medium">Expertise:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {mentor.expertise.map((skill) => (
                                <Badge key={skill} variant="secondary" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="flex justify-between text-sm">
                            <span>Rating: ⭐ {mentor.rating}</span>
                            <span>{mentor.sessions} sessions</span>
                          </div>

                          <Button
                            className="w-full"
                            variant={mentor.availability === "Available" ? "default" : "outline"}
                            disabled={mentor.availability !== "Available"}
                          >
                            {mentor.availability === "Available" ? "Book Session" : "Currently Busy"}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projects" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Collaborative Projects
                </CardTitle>
                <CardDescription>Join open-source projects building accessible technology</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {projects.map((project) => (
                    <Card key={project.id} className="border-l-4 border-l-green-500">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-medium mb-2">{project.title}</h4>
                            <p className="text-slate-600 mb-3">{project.description}</p>
                            <div className="flex items-center gap-2 text-sm text-slate-500">
                              <span>Led by {project.lead}</span>
                              <span>•</span>
                              <span>{project.contributors} contributors</span>
                            </div>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {project.progress}% Complete
                          </Badge>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <span className="text-sm font-medium">Tech Stack:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {project.tech.map((tech) => (
                                <Badge key={tech} variant="secondary" className="text-xs">
                                  {tech}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div>
                            <span className="text-sm font-medium">Seeking:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {project.seeking.map((role) => (
                                <Badge
                                  key={role}
                                  variant="outline"
                                  className="text-xs border-orange-300 text-orange-700"
                                >
                                  {role}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div className="bg-green-600 h-2 rounded-full" style={{ width: `${project.progress}%` }} />
                          </div>

                          <div className="flex gap-2">
                            <Button size="sm">
                              <Code className="h-4 w-4 mr-1" />
                              View Code
                            </Button>
                            <Button size="sm" variant="outline">
                              Join Project
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="events" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Upcoming Events & Workshops
                </CardTitle>
                <CardDescription>Join ASL-accessible tech events and learning sessions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[
                    {
                      title: "Deaf-First API Design Workshop",
                      date: "March 15, 2025",
                      time: "2:00 PM PST",
                      type: "Workshop",
                      presenter: "Sarah Chen",
                      attendees: 47,
                      hasASL: true,
                    },
                    {
                      title: "Building Accessible React Apps",
                      date: "March 18, 2025",
                      time: "10:00 AM EST",
                      type: "Tutorial",
                      presenter: "Alex Kim",
                      attendees: 89,
                      hasASL: true,
                    },
                    {
                      title: "Deaf Entrepreneur Showcase",
                      date: "March 22, 2025",
                      time: "6:00 PM PST",
                      type: "Networking",
                      presenter: "Marcus Rodriguez",
                      attendees: 156,
                      hasASL: true,
                    },
                    {
                      title: "VR Accessibility Deep Dive",
                      date: "March 25, 2025",
                      time: "1:00 PM CST",
                      type: "Technical",
                      presenter: "Dr. Jennifer Walsh",
                      attendees: 203,
                      hasASL: true,
                    },
                  ].map((event, index) => (
                    <Card key={index} className="border-l-4 border-l-purple-500">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-medium">{event.title}</h4>
                            <p className="text-sm text-slate-600">
                              {event.date} • {event.time}
                            </p>
                            <p className="text-sm text-slate-500">Presented by {event.presenter}</p>
                          </div>
                          <Badge variant="outline">{event.type}</Badge>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-slate-500" />
                            <span className="text-sm">{event.attendees} attending</span>
                            {event.hasASL && (
                              <Badge variant="secondary" className="text-xs bg-blue-50 text-blue-700">
                                <Hand className="h-3 w-3 mr-1" />
                                ASL
                              </Badge>
                            )}
                          </div>
                          <Button size="sm">Join Event</Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Community Stats */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4">🌟 Growing Deaf Developer Community</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <div className="text-3xl font-bold text-blue-600">5,847</div>
                  <div className="text-sm text-slate-600">Active Developers</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600">1,234</div>
                  <div className="text-sm text-slate-600">ASL Videos Posted</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-600">89</div>
                  <div className="text-sm text-slate-600">Active Projects</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-orange-600">156</div>
                  <div className="text-sm text-slate-600">Mentorship Sessions</div>
                </div>
              </div>
              <div className="mt-6">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                  <Users className="h-5 w-5 mr-2" />
                  Join Community
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
