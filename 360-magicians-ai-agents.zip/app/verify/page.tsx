"use client"

import AgentVerificationDashboard from "@/components/agent-verification-dashboard"

export default function VerifyPage() {
  return <AgentVerificationDashboard />
}
