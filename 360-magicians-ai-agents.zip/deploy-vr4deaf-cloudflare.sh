#!/bin/bash

echo "🚀 Deploying VR4Deaf.org with VURI AI to Cloudflare"
echo "Created by 360 Magicians"

# Check if wrangler is installed
if ! command -v wrangler &> /dev/null; then
    echo "Installing Wrangler CLI..."
    npm install -g wrangler
fi

# Login to Cloudflare (if not already logged in)
echo "🔐 Checking Cloudflare authentication..."
wrangler whoami || wrangler login

# Build the Next.js application
echo "🏗️ Building VR4Deaf platform..."
npm run build

# Deploy to Cloudflare Pages
echo "☁️ Deploying to Cloudflare Pages..."
wrangler pages publish .next/static --project-name=vr4deaf --compatibility-date=2024-01-15

# Set up custom domain
echo "🌐 Configuring custom domain: vr4deaf.org"
wrangler pages domain add vr4deaf.org --project-name=vr4deaf

# Set environment variables
echo "⚙️ Setting environment variables..."
wrangler pages secret put NEXT_PUBLIC_SUPABASE_URL --project-name=vr4deaf
wrangler pages secret put SUPABASE_SERVICE_ROLE_KEY --project-name=vr4deaf
wrangler pages secret put NEXT_PUBLIC_APP_URL --project-name=vr4deaf

# Deploy database schema
echo "🗄️ Setting up VURI AI database..."
if command -v psql &> /dev/null; then
    psql $DATABASE_URL -f scripts/create-vuri-tables.sql
    echo "✅ Database schema deployed"
else
    echo "⚠️ PostgreSQL client not found. Please run scripts/create-vuri-tables.sql manually"
fi

# Verify deployment
echo "🔍 Verifying deployment..."
sleep 10
curl -f https://vr4deaf.org/api/vuri-ai?action=agents || echo "⚠️ API verification failed"

# Test VURI AI agents
echo "🤖 Testing VURI AI agents..."
curl -X POST https://vr4deaf.org/api/vuri-ai \
  -H "Content-Type: application/json" \
  -d '{
    "agent": "vr-accessibility",
    "message": "Test VR accessibility optimization",
    "userId": "test-user",
    "sessionId": "test-session"
  }' || echo "⚠️ VURI AI test failed"

echo ""
echo "🎉 VR4Deaf.org DEPLOYMENT COMPLETE!"
echo ""
echo "🌟 Platform Details:"
echo "   • Website: https://vr4deaf.org"
echo "   • AI System: VURI (VR4Deaf Universal Reality Intelligence)"
echo "   • Hosting: Cloudflare Pages"
echo "   • Creator: 360 Magicians"
echo "   • Focus: Deaf-First VR Experiences"
echo ""
echo "🤖 VURI AI Agents Active:"
echo "   • VR Accessibility Specialist"
echo "   • ASL Avatar Creator"
echo "   • Spatial Audio-Visual Converter"
echo "   • Deaf Social VR Facilitator"
echo "   • VR Training Specialist for Deaf Users"
echo "   • Haptic Feedback Designer"
echo ""
echo "♿ Accessibility Features:"
echo "   • 100% Deaf-Optimized"
echo "   • Visual-First Design"
echo "   • ASL Integration"
echo "   • Haptic Feedback Systems"
echo "   • No Audio Dependencies"
echo "   • WCAG AA Compliant"
echo ""
echo "🚀 Ready to serve the global deaf community in VR!"
