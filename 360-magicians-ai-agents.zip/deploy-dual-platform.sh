#!/bin/bash

# Deploy VR4Deaf.org + 360Magicians.com Dual Platform to Cloudflare
# Vocational Rehabilitation Vendor Network + Deaf-Aware AI Platform

set -e

echo "🚀 Starting dual platform deployment to Cloudflare..."
echo "📋 Platform 1: VR4Deaf.org - Vocational Rehabilitation Vendor Network"
echo "📋 Platform 2: 360Magicians.com - Deaf-Aware AI Platform with Sign Language Models"

# Check prerequisites
echo "🔍 Checking prerequisites..."

if ! command -v wrangler &> /dev/null; then
    echo "❌ Wrangler CLI not found. Installing..."
    npm install -g wrangler
fi

if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js first."
    exit 1
fi

# Authenticate with Cloudflare
echo "🔐 Authenticating with Cloudflare..."
wrangler auth

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build VR4Deaf platform
echo "🏗️ Building VR4Deaf.org platform..."
export PLATFORM_TARGET="vr4deaf"
export NEXT_PUBLIC_APP_URL="https://vr4deaf.org"
export PLATFORM_NAME="VR4Deaf"
export PLATFORM_TYPE="vendor_network"
npm run build

# Deploy VR4Deaf to Cloudflare Pages
echo "🚀 Deploying VR4Deaf.org to Cloudflare Pages..."
wrangler pages deploy .next/static --project-name=vr4deaf-production --compatibility-date=2024-01-15

# Build 360Magicians platform
echo "🏗️ Building 360Magicians.com platform..."
export PLATFORM_TARGET="magicians"
export NEXT_PUBLIC_APP_URL="https://360magicians.com"
export PLATFORM_NAME="360Magicians"
export PLATFORM_TYPE="ai_platform"
npm run build

# Deploy 360Magicians to Cloudflare Pages
echo "🚀 Deploying 360Magicians.com to Cloudflare Pages..."
wrangler pages deploy .next/static --project-name=360magicians-production --compatibility-date=2024-01-15

# Set up KV namespaces
echo "🗄️ Setting up Cloudflare KV namespaces..."

# VR4Deaf KV namespaces
wrangler kv:namespace create "VR4DEAF_CACHE" --preview=false
wrangler kv:namespace create "VENDOR_DATA" --preview=false
wrangler kv:namespace create "CLIENT_PROGRESS" --preview=false

# 360Magicians KV namespaces
wrangler kv:namespace create "AI_MODEL_CACHE" --preview=false
wrangler kv:namespace create "SIGN_LANGUAGE_CACHE" --preview=false
wrangler kv:namespace create "ACCESSIBILITY_CACHE" --preview=false

# Set up R2 buckets
echo "🪣 Setting up Cloudflare R2 buckets..."

# VR4Deaf R2 buckets
wrangler r2 bucket create vr4deaf-assets
wrangler r2 bucket create vr4deaf-documents
wrangler r2 bucket create vr4deaf-reports

# 360Magicians R2 buckets
wrangler r2 bucket create 360magicians-ai-assets
wrangler r2 bucket create 360magicians-avatars
wrangler r2 bucket create 360magicians-models

# Configure custom domains
echo "🌐 Configuring custom domains..."

# VR4Deaf domains
wrangler pages domain add vr4deaf-production vr4deaf.org
wrangler pages domain add vr4deaf-production www.vr4deaf.org

# 360Magicians domains
wrangler pages domain add 360magicians-production 360magicians.com
wrangler pages domain add 360magicians-production www.360magicians.com
wrangler pages domain add 360magicians-production api.360magicians.com

# Set up environment variables
echo "⚙️ Setting up environment variables..."

# VR4Deaf environment variables
wrangler pages secret put SUPABASE_URL --project-name=vr4deaf-production
wrangler pages secret put SUPABASE_SERVICE_ROLE_KEY --project-name=vr4deaf-production
wrangler pages secret put VR4DEAF_API_KEY --project-name=vr4deaf-production

# 360Magicians environment variables
wrangler pages secret put VERTEX_AI_PROJECT_ID --project-name=360magicians-production
wrangler pages secret put VERTEX_AI_LOCATION --project-name=360magicians-production
wrangler pages secret put OPENAI_API_KEY --project-name=360magicians-production
wrangler pages secret put MAGICIANS_AI_KEY --project-name=360magicians-production

# Deploy database schemas
echo "🗃️ Deploying database schemas..."
echo "📊 Creating VR4Deaf vendor and client tables..."
psql $DATABASE_URL -f scripts/create-vr4deaf-tables.sql

echo "🧠 Creating 360Magicians AI model tables..."
psql $DATABASE_URL -f scripts/create-360magicians-tables.sql

# Set up monitoring and analytics
echo "📊 Setting up monitoring and analytics..."

# Create Cloudflare Analytics
wrangler analytics create --name="vr4deaf-analytics"
wrangler analytics create --name="360magicians-analytics"

# Set up health checks
echo "🏥 Setting up health checks..."
curl -X POST "https://api.cloudflare.com/client/v4/zones/$CLOUDFLARE_ZONE_ID/healthchecks" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "type": "HTTPS",
    "name": "VR4Deaf Health Check",
    "description": "Monitor VR4Deaf.org availability",
    "address": "vr4deaf.org",
    "path": "/api/health",
    "interval": 60
  }'

curl -X POST "https://api.cloudflare.com/client/v4/zones/$CLOUDFLARE_ZONE_ID/healthchecks" \
  -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{
    "type": "HTTPS",
    "name": "360Magicians Health Check", 
    "description": "Monitor 360Magicians.com AI platform",
    "address": "360magicians.com",
    "path": "/api/health",
    "interval": 60
  }'

# Verify deployments
echo "✅ Verifying deployments..."

echo "🔍 Testing VR4Deaf.org..."
if curl -f -s "https://vr4deaf.org/api/health" > /dev/null; then
    echo "✅ VR4Deaf.org is live and healthy!"
else
    echo "❌ VR4Deaf.org health check failed"
fi

echo "🔍 Testing 360Magicians.com..."
if curl -f -s "https://360magicians.com/api/health" > /dev/null; then
    echo "✅ 360Magicians.com is live and healthy!"
else
    echo "❌ 360Magicians.com health check failed"
fi

# Final status report
echo ""
echo "🎉 DUAL PLATFORM DEPLOYMENT COMPLETE!"
echo ""
echo "📊 DEPLOYMENT SUMMARY:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
