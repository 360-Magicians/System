#!/bin/bash

echo "📦 PUBLISHING 360 MAGICIANS SDKs TO ALL PACKAGE MANAGERS"
echo "🌟 Making Deaf-First AI Accessible to Every Developer"

# JavaScript/Node.js SDK to npm
echo "📦 Publishing JavaScript SDK to npm..."
cd sdk/javascript
npm run build
npm publish --access public
echo "✅ @360magicians/api-client published to npm"

# Python SDK to PyPI
echo "🐍 Publishing Python SDK to PyPI..."
cd ../python
python setup.py sdist bdist_wheel
twine upload dist/*
echo "✅ magicians-api published to PyPI"

# PHP SDK to Packagist
echo "🐘 Publishing PHP SDK to Packagist..."
cd ../php
composer validate
git tag v1.0.0
git push origin v1.0.0
echo "✅ 360magicians/php-client published to Packagist"

# Ruby Gem to RubyGems
echo "💎 Publishing Ruby SDK to RubyGems..."
cd ../ruby
gem build magicians_api.gemspec
gem push magicians_api-1.0.0.gem
echo "✅ magicians_api published to RubyGems"

# Go Module to GitHub
echo "🐹 Publishing Go SDK to GitHub..."
cd ../go
git tag v1.0.0
git push origin v1.0.0
go list -m github.com/360magicians/go-client@v1.0.0
echo "✅ Go module published to GitHub"

# React Components to npm
echo "⚛️ Publishing React Components to npm..."
cd ../react
npm run build
npm publish --access public
echo "✅ @360magicians/react published to npm"

# Update documentation
echo "📚 Updating package documentation..."
curl -X POST https://mbtq.dev/api/docs/update-packages \
  -H "Authorization: Bearer $MBTQ_API_KEY" \
  -d '{
    "packages": [
      {"name": "@360magicians/api-client", "platform": "npm", "version": "1.0.0"},
      {"name": "magicians-api", "platform": "pypi", "version": "1.0.0"},
      {"name": "360magicians/php-client", "platform": "packagist", "version": "1.0.0"},
      {"name": "magicians_api", "platform": "rubygems", "version": "1.0.0"},
      {"name": "github.com/360magicians/go-client", "platform": "go", "version": "1.0.0"},
      {"name": "@360magicians/react", "platform": "npm", "version": "1.0.0"}
    ]
  }'

echo ""
echo "🎉 ALL SDKs PUBLISHED SUCCESSFULLY!"
echo "📦 npm: @360magicians/api-client"
echo "🐍 PyPI: magicians-api"
echo "🐘 Packagist: 360magicians/php-client"
echo "💎 RubyGems: magicians_api"
echo "🐹 Go: github.com/360magicians/go-client"
echo "⚛️ React: @360magicians/react"
echo ""
echo "🌟 DEAF-FIRST AI NOW AVAILABLE IN EVERY MAJOR LANGUAGE!"
echo "📚 Documentation: https://docs.mbtq.dev/sdks"
