"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Eye, Zap, Users, Headphones, Hand, Vibrate } from "lucide-react"

interface VURIAgent {
  id: string
  name: string
  description: string
  capabilities: string[]
  deaf_optimized: boolean
  vr_ready: boolean
}

export default function VURIAIDashboard() {
  const [agents, setAgents] = useState<VURIAgent[]>([])
  const [selectedAgent, setSelectedAgent] = useState<string>("")
  const [message, setMessage] = useState("")
  const [response, setResponse] = useState("")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchVURIAgents()
  }, [])

  const fetchVURIAgents = async () => {
    try {
      const res = await fetch("/api/vuri-ai?action=agents")
      const data = await res.json()
      setAgents(data.agents || [])
    } catch (error) {
      console.error("Failed to fetch VURI agents:", error)
    }
  }

  const sendMessage = async () => {
    if (!selectedAgent || !message.trim()) return

    setLoading(true)
    try {
      const res = await fetch("/api/vuri-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          agent: selectedAgent,
          message: message,
          userId: "demo-user",
          sessionId: Date.now().toString(),
        }),
      })

      const data = await res.json()
      setResponse(data.response || "No response received")
    } catch (error) {
      setResponse("Error communicating with VURI AI")
    } finally {
      setLoading(false)
    }
  }

  const getAgentIcon = (capabilities: string[]) => {
    if (capabilities.includes("asl-animation")) return <Hand className="h-5 w-5" />
    if (capabilities.includes("haptic-patterns")) return <Vibrate className="h-5 w-5" />
    if (capabilities.includes("social-optimization")) return <Users className="h-5 w-5" />
    if (capabilities.includes("audio-visual-mapping")) return <Headphones className="h-5 w-5" />
    if (capabilities.includes("vr-optimization")) return <Eye className="h-5 w-5" />
    return <Zap className="h-5 w-5" />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-5xl font-bold text-white">VURI AI Dashboard</h1>
          <p className="text-xl text-blue-200">VR4Deaf Universal Reality Intelligence - Deaf-First VR AI System</p>
          <div className="flex justify-center gap-4">
            <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-500/30">
              ♿ 100% Deaf-Optimized
            </Badge>
            <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-500/30">
              🥽 VR-Ready
            </Badge>
            <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-500/30">
              ☁️ Cloudflare Hosted
            </Badge>
          </div>
        </div>

        {/* VURI Agents Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => (
            <Card
              key={agent.id}
              className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-all"
            >
              <CardHeader>
                <div className="flex items-center gap-3">
                  {getAgentIcon(agent.capabilities)}
                  <div>
                    <CardTitle className="text-white text-lg">{agent.name}</CardTitle>
                    <CardDescription className="text-blue-200">{agent.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-1">
                    {agent.capabilities.map((capability) => (
                      <Badge key={capability} variant="outline" className="text-xs border-blue-300/30 text-blue-200">
                        {capability}
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    {agent.deaf_optimized && (
                      <Badge className="bg-green-500/20 text-green-300 border-green-500/30">♿ Deaf-First</Badge>
                    )}
                    {agent.vr_ready && (
                      <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">🥽 VR-Ready</Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* VURI AI Chat Interface */}
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardHeader>
            <CardTitle className="text-white text-2xl">Chat with VURI AI</CardTitle>
            <CardDescription className="text-blue-200">
              Interact with VR4Deaf's Universal Reality Intelligence system
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-white font-medium">Select VURI Agent:</label>
                <Select value={selectedAgent} onValueChange={setSelectedAgent}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue placeholder="Choose a VURI specialist..." />
                  </SelectTrigger>
                  <SelectContent>
                    {agents.map((agent) => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-white font-medium">Your Message:</label>
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your VR accessibility needs..."
                  className="bg-white/10 border-white/20 text-white placeholder:text-blue-200"
                  rows={3}
                />
              </div>
            </div>

            <Button
              onClick={sendMessage}
              disabled={loading || !selectedAgent || !message.trim()}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {loading ? "VURI is thinking..." : "Send to VURI AI"}
            </Button>

            {response && (
              <div className="space-y-2">
                <label className="text-white font-medium">VURI Response:</label>
                <ScrollArea className="h-32 w-full rounded-md border border-white/20 bg-white/5 p-4">
                  <p className="text-blue-100">{response}</p>
                </ScrollArea>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Platform Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-white">{agents.length}</div>
              <div className="text-blue-200">VURI Agents</div>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-green-300">98%</div>
              <div className="text-blue-200">Accessibility Score</div>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-purple-300">100%</div>
              <div className="text-blue-200">VR-Ready</div>
            </CardContent>
          </Card>
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-blue-300">24/7</div>
              <div className="text-blue-200">Available</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
