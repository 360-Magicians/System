"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Hand, Users, Globe, Zap, Award, TrendingUp } from 'lucide-react'

const signLanguageModels = [
  {
    id: "asl",
    name: "American Sign Language (ASL)",
    region: "United States & Canada",
    speakers: "500,000+",
    accuracy: 96.8,
    features: ["Real-time translation", "Cultural context", "Regional dialects", "Facial expressions"],
    icon: "🇺🇸",
    color: "bg-blue-500",
  },
  {
    id: "bsl",
    name: "British Sign Language (BSL)",
    region: "United Kingdom",
    speakers: "125,000+",
    accuracy: 94.2,
    features: ["Two-handed fingerspelling", "UK dialects", "Cultural context"],
    icon: "🇬🇧",
    color: "bg-red-500",
  },
  {
    id: "auslan",
    name: "Australian Sign Language (Auslan)",
    region: "Australia",
    speakers: "16,000+",
    accuracy: 91.5,
    features: ["One-handed fingerspelling", "Indigenous signs", "Regional variations"],
    icon: "🇦🇺",
    color: "bg-green-500",
  },
  {
    id: "lsf",
    name: "French Sign Language (LSF)",
    region: "France",
    speakers: "100,000+",
    accuracy: 89.3,
    features: ["French grammar structure", "Cultural expressions", "Historical context"],
    icon: "🇫🇷",
    color: "bg-purple-500",
  },
]

const globalStats = {
  totalLanguages: 4,
  totalSpeakers: "741,000+",
  averageAccuracy: 92.95,
  culturalContexts: 12,
}

export default function SignLanguageModels() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-gray-900">Sign Language AI Models</h2>
        <p className="text-xl text-gray-600">Culturally-aware, deaf-first sign language interpretation</p>
      </div>

      {/* Global Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Globe className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{globalStats.totalLanguages}</div>
            <div className="text-gray-600">Sign Languages</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Users className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{globalStats.totalSpeakers}</div>
            <div className="text-gray-600">Native Speakers</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{globalStats.averageAccuracy}%</div>
            <div className="text-gray-600">Avg Accuracy</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Award className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{globalStats.culturalContexts}</div>
            <div className="text-gray-600">Cultural Contexts</div>
          </CardContent>
        </Card>
      </div>

      {/* Sign Language Models Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {signLanguageModels.map((model) => (
          <Card key={model.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${model.color}`}>
                    <Hand className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl flex items-center gap-2">
                      {model.name}
                      <span className="text-2xl">{model.icon}</span>
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-1">
                      <Globe className="h-4 w-4" />
                      {model.region}
                    </CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <Zap className="h-3 w-3 mr-1" />
                  Active
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Accuracy Score */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-medium">AI Model Accuracy</span>
                  <span className="font-bold text-green-600">{model.accuracy}%</span>
                </div>
                <Progress value={model.accuracy} className="h-3" />
              </div>

              {/* Statistics */}
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{model.speakers}</div>
                  <div className="text-sm text-gray-600">Native Speakers</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">&lt; 100ms</div>
                  <div className="text-sm text-gray-600">Response Time</div>
                </div>
              </div>

              {/* Features */}
              <div>
                <h4 className="font-medium text-sm mb-3">AI Model Features</h4>
                <div className="flex flex-wrap gap-2">
                  {model.features.map((feature) => (
                    <Badge key={feature} variant="outline" className="text-xs">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Cultural Competency */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-2">
                  <Award className="h-4 w-4 text-blue-600" />
                  <span className="font-medium text-blue-800">Cultural Competency</span>
                </div>
                <p className="text-sm text-blue-700">
                  This model is trained with deaf cultural context, ensuring authentic and respectful sign language interpretation.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button className="flex-1">
                  <Hand className="h-4 w-4 mr-2" />
                  Try Model
                </Button>
                <Button variant="outline" className="flex-1">
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Additional Information */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <h3 className="text-2xl font-bold text-gray-900">Deaf-First AI Development</h3>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Our sign language models are developed in partnership with deaf communities worldwide, ensuring cultural authenticity, 
              linguistic accuracy, and respectful representation of deaf culture and identity.
            </p>
            <div className="flex justify-center gap-4 mt-6">
              <Badge variant="secondary" className="bg-purple-100 text-purple-800 border-purple-200">
                🤟 Deaf Community Validated
              </Badge>
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
                🌍 Culturally Authentic
              </Badge>
              <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
                ⚡ Real-Time Processing
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
