"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Building2, GraduationCap, Heart, Scale, Briefcase, ShoppingCart, Users, TrendingUp, CheckCircle, Zap } from 'lucide-react'

const industries = [
  {
    id: "healthcare",
    name: "Healthcare",
    icon: Heart,
    color: "bg-red-500",
    description: "Medical accessibility, patient communication, and healthcare provider training",
    marketSize: "$2.8B",
    adoptionRate: 78,
    solutions: [
      "ASL medical interpreters",
      "Patient communication systems", 
      "Medical terminology translation",
      "Emergency communication protocols"
    ],
    clients: ["Mayo Clinic", "Johns Hopkins", "Kaiser Permanente"],
    impact: "Improved patient outcomes by 45%"
  },
  {
    id: "education",
    name: "Education",
    icon: GraduationCap,
    color: "bg-blue-500",
    description: "Educational accessibility, classroom integration, and student support systems",
    marketSize: "$1.9B",
    adoptionRate: 85,
    solutions: [
      "Classroom ASL interpretation",
      "Educational content translation",
      "Student assessment tools",
      "Teacher training programs"
    ],
    clients: ["Gallaudet University", "RIT/NTID", "California Schools for the Deaf"],
    impact: "Enhanced learning outcomes by 52%"
  },
  {
    id: "legal",
    name: "Legal Services",
    icon: Scale,
    color: "bg-purple-500",
    description: "Legal accessibility, court proceedings, and legal document translation",
    marketSize: "$1.2B",
    adoptionRate: 65,
    solutions: [
      "Court interpretation services",
      "Legal document translation",
      "Attorney-client communication",
      "Jury accessibility support"
    ],
    clients: ["Federal Courts", "State Bar Associations", "Legal Aid Societies"],
    impact: "Increased legal access by 67%"
  },
  {
    id: "corporate",
    name: "Corporate",
    icon: Building2,
    color: "bg-green-500",
    description: "Workplace accessibility, employee training, and corporate communications",
    marketSize: "$3.5B",
    adoptionRate: 72,
    solutions: [
      "Workplace accommodations",
      "Employee training programs",
      "Meeting accessibility",
      "HR communication systems"
    ],
    clients: ["Microsoft", "Google", "Amazon", "Apple"],
    impact: "Improved workplace inclusion by 58%"
  },
  {
    id: "employment",
    name: "Employment Services",
    icon: Briefcase,
    color: "bg-orange-500",
    description: "Job placement, career development, and vocational rehabilitation",
    marketSize: "$2.1B",
    adoptionRate: 89,
    solutions: [
      "Job matching algorithms",
      "Interview preparation",
      "Skills assessment tools",
      "Career counseling services"
    ],
    clients: ["State VR Agencies", "Workforce Development Boards", "Career Centers"],
    impact: "Increased employment rates by 73%"
  },
  {
    id: "retail",
    name: "Retail & Commerce",
    icon: ShoppingCart,
    color: "bg-pink-500",
    description: "Customer service, retail accessibility, and e-commerce solutions",
    marketSize: "$1.6B",
    adoptionRate: 56,
    solutions: [
      "Customer service accessibility",
      "Product information translation",
      "Shopping assistance tools",
      "Payment system accessibility"
    ],
    clients: ["Target", "Walmart", "Best Buy", "Starbucks"],
    impact: "Enhanced customer satisfaction by 41%"
  }
]

const overallStats = {
  totalMarketSize: "$13.1B",
  averageAdoption: 74,
  totalClients: "2,500+",
  averageImpact: 56
}

export default function IndustrySolutions() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h2 className="text-3xl font-bold text-gray-900">Industry Solutions</h2>
        <p className="text-xl text-gray-600">Deaf-first accessibility solutions across every major industry</p>
      </div>

      {/* Overall Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{overallStats.totalMarketSize}</div>
            <div className="text-gray-600">Total Market Size</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <CheckCircle className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{overallStats.averageAdoption}%</div>
            <div className="text-gray-600">Avg Adoption Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{overallStats.totalClients}</div>
            <div className="text-gray-600">Enterprise Clients</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Zap className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{overallStats.averageImpact}%</div>
            <div className="text-gray-600">Avg Impact Improvement</div>
          </CardContent>
        </Card>
      </div>

      {/* Industry Solutions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {industries.map((industry) => (
          <Card key={industry.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${industry.color}`}>
                    <industry.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{industry.name}</CardTitle>
                    <CardDescription className="mt-1">
                      {industry.description}
                    </CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Growing
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              {/* Market Metrics */}
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{industry.marketSize}</div>
                  <div className="text-sm text-gray-600">Market Size</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{industry.adoptionRate}%</div>
                  <div className="text-sm text-gray-600">Adoption Rate</div>
                </div>
              </div>

              {/* Adoption Progress */}
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="font-medium">Industry Adoption</span>
                  <span className="font-bold text-blue-600">{industry.adoptionRate}%</span>
                </div>
                <Progress value={industry.adoptionRate} className="h-3" />
              </div>

              {/* Solutions */}
              <div>
                <h4 className="font-medium text-sm mb-3">Key Solutions</h4>
                <div className="space-y-2">
                  {industry.solutions.map((solution, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>{solution}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Notable Clients */}
              <div>
                <h4 className="font-medium text-sm mb-3">Notable Clients</h4>
                <div className="flex flex-wrap gap-2">
                  {industry.clients.map((client) => (
                    <Badge key={client} variant="outline" className="text-xs">
                      {client}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Impact */}
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="font-medium text-green-800">Measurable Impact</span>
                </div>
                <p className="text-sm text-green-700">{industry.impact}</p>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3">
                <Button className="flex-1">
                  <industry.icon className="h-4 w-4 mr-2" />
                  Explore Solutions
                </Button>
                <Button variant="outline" className="flex-1">
                  Case Studies
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <h3 className="text-2xl font-bold text-gray-900">Transform Your Industry with Deaf-First Solutions</h3>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Join 2,500+ organizations already using our accessibility solutions to create inclusive experiences 
              for the 70+ million deaf people worldwide.
            </p>
            <div className="flex justify-center gap-4 mt-6">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                <Building2 className="h-5 w-5 mr-2" />
                Get Enterprise Demo
              </Button>
              <Button size="lg" variant="outline">
                <Users className="h-5 w-5 mr-2" />
                View All Industries
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
