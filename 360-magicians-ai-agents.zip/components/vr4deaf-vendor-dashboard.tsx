"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Building2, Users, TrendingUp, MapPin, Award, HandHeart } from "lucide-react"

interface Vendor {
  id: string
  name: string
  specializations: string[]
  aslCapability: boolean
  accessibilityRating: number
  location: string
  activeClients: number
  successRate: number
}

interface Client {
  id: string
  name: string
  rehabilitationNeeds: string[]
  requiresASL: boolean
  progress: number
  vendor: string
  startDate: string
}

export default function VR4DeafVendorDashboard() {
  const [vendors, setVendors] = useState<Vendor[]>([])
  const [clients, setClients] = useState<Client[]>([])
  const [stats, setStats] = useState<any>({})
  const [newVendor, setNewVendor] = useState({
    name: "",
    specializations: [],
    aslCapability: false,
    location: "",
    contactInfo: "",
  })

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      const statsRes = await fetch("/api/vr4deaf/vendors?action=vendor_stats")
      const statsData = await statsRes.json()
      setStats(statsData)

      // Mock data for demonstration
      setVendors([
        {
          id: "1",
          name: "Deaf Vocational Services Inc.",
          specializations: ["Job Training", "ASL Interpretation", "Workplace Accommodation"],
          aslCapability: true,
          accessibilityRating: 4.9,
          location: "California",
          activeClients: 45,
          successRate: 96,
        },
        {
          id: "2",
          name: "Accessible Career Solutions",
          specializations: ["Career Counseling", "Skills Assessment", "Technology Training"],
          aslCapability: true,
          accessibilityRating: 4.7,
          location: "New York",
          activeClients: 32,
          successRate: 94,
        },
        {
          id: "3",
          name: "Inclusive Workforce Partners",
          specializations: ["Employer Relations", "Job Placement", "Follow-up Support"],
          aslCapability: true,
          accessibilityRating: 4.8,
          location: "Texas",
          activeClients: 28,
          successRate: 92,
        },
      ])

      setClients([
        {
          id: "1",
          name: "Sarah M.",
          rehabilitationNeeds: ["Job Training", "ASL Support"],
          requiresASL: true,
          progress: 75,
          vendor: "Deaf Vocational Services Inc.",
          startDate: "2024-01-15",
        },
        {
          id: "2",
          name: "Michael R.",
          rehabilitationNeeds: ["Career Counseling", "Technology Training"],
          requiresASL: true,
          progress: 60,
          vendor: "Accessible Career Solutions",
          startDate: "2024-02-01",
        },
        {
          id: "3",
          name: "Jennifer L.",
          rehabilitationNeeds: ["Job Placement", "Workplace Accommodation"],
          requiresASL: false,
          progress: 90,
          vendor: "Inclusive Workforce Partners",
          startDate: "2023-11-20",
        },
      ])
    } catch (error) {
      console.error("Failed to fetch dashboard data:", error)
    }
  }

  const registerVendor = async () => {
    try {
      const response = await fetch("/api/vr4deaf/vendors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "register_vendor",
          vendorData: newVendor,
        }),
      })

      const result = await response.json()
      if (result.success) {
        alert("Vendor registered successfully!")
        setNewVendor({ name: "", specializations: [], aslCapability: false, location: "", contactInfo: "" })
        fetchDashboardData()
      }
    } catch (error) {
      console.error("Failed to register vendor:", error)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-gray-900">VR4Deaf Vendor Partnership Dashboard</h1>
          <p className="text-xl text-gray-600">Vocational Rehabilitation Services for the Deaf Community</p>
          <div className="flex justify-center gap-4">
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
              ♿ 100% Accessible
            </Badge>
            <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
              🤟 ASL-First
            </Badge>
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 border-purple-200">
              🏢 Vendor Network
            </Badge>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6 text-center">
              <Building2 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.total_vendors || 0}</div>
              <div className="text-gray-600">Certified Vendors</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.active_clients || 0}</div>
              <div className="text-gray-600">Active Clients</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.success_rate || "0%"}</div>
              <div className="text-gray-600">Success Rate</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <HandHeart className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.asl_certified_vendors || 0}</div>
              <div className="text-gray-600">ASL Certified</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="vendors" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="vendors">Vendor Network</TabsTrigger>
            <TabsTrigger value="clients">Client Progress</TabsTrigger>
            <TabsTrigger value="register">Register Vendor</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="vendors" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {vendors.map((vendor) => (
                <Card key={vendor.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{vendor.name}</CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <MapPin className="h-4 w-4" />
                          {vendor.location}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-1">
                        <Award className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm font-medium">{vendor.accessibilityRating}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm mb-2">Specializations</h4>
                      <div className="flex flex-wrap gap-1">
                        {vendor.specializations.map((spec) => (
                          <Badge key={spec} variant="outline" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Active Clients:</span>
                        <div className="text-blue-600">{vendor.activeClients}</div>
                      </div>
                      <div>
                        <span className="font-medium">Success Rate:</span>
                        <div className="text-green-600">{vendor.successRate}%</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      {vendor.aslCapability && (
                        <Badge className="bg-green-100 text-green-800 border-green-200">🤟 ASL Certified</Badge>
                      )}
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="clients" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {clients.map((client) => (
                <Card key={client.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{client.name}</CardTitle>
                        <CardDescription>Started: {client.startDate}</CardDescription>
                      </div>
                      <Badge variant={client.progress >= 80 ? "default" : "secondary"}>
                        {client.progress >= 80 ? "Near Completion" : "In Progress"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span>{client.progress}%</span>
                      </div>
                      <Progress value={client.progress} className="h-2" />
                    </div>

                    <div>
                      <h4 className="font-medium text-sm mb-2">Rehabilitation Needs</h4>
                      <div className="flex flex-wrap gap-1">
                        {client.rehabilitationNeeds.map((need) => (
                          <Badge key={need} variant="outline" className="text-xs">
                            {need}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Vendor:</span>
                        <div className="text-blue-600">{client.vendor}</div>
                      </div>
                      <div>
                        <span className="font-medium">ASL Required:</span>
                        <div className={client.requiresASL ? "text-green-600" : "text-gray-600"}>
                          {client.requiresASL ? "Yes" : "No"}
                        </div>
                      </div>
                    </div>

                    <Button size="sm" className="w-full">
                      View Full Progress
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="register" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Register New Vendor</CardTitle>
                <CardDescription>Add a new vocational rehabilitation vendor to the network</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Vendor Name</label>
                    <Input
                      value={newVendor.name}
                      onChange={(e) => setNewVendor({ ...newVendor, name: e.target.value })}
                      placeholder="Enter vendor name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Location</label>
                    <Select
                      value={newVendor.location}
                      onValueChange={(value) => setNewVendor({ ...newVendor, location: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="california">California</SelectItem>
                        <SelectItem value="new-york">New York</SelectItem>
                        <SelectItem value="texas">Texas</SelectItem>
                        <SelectItem value="florida">Florida</SelectItem>
                        <SelectItem value="illinois">Illinois</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Contact Information</label>
                  <Textarea
                    value={newVendor.contactInfo}
                    onChange={(e) => setNewVendor({ ...newVendor, contactInfo: e.target.value })}
                    placeholder="Enter contact details (phone, email, address)"
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="asl-capability"
                    checked={newVendor.aslCapability}
                    onChange={(e) => setNewVendor({ ...newVendor, aslCapability: e.target.checked })}
                    className="rounded border-gray-300"
                  />
                  <label htmlFor="asl-capability" className="text-sm font-medium">
                    ASL Interpretation Capability
                  </label>
                </div>

                <Button onClick={registerVendor} className="w-full">
                  Register Vendor
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Vendor Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Average Success Rate</span>
                      <span className="font-bold text-green-600">94%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Average Accessibility Rating</span>
                      <span className="font-bold text-blue-600">4.8/5.0</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>ASL Certified Vendors</span>
                      <span className="font-bold text-purple-600">100%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Client Satisfaction</span>
                      <span className="font-bold text-orange-600">96%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Platform Metrics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Total Placements</span>
                      <span className="font-bold text-green-600">1,247</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Active Partnerships</span>
                      <span className="font-bold text-blue-600">156</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Accessibility Compliance</span>
                      <span className="font-bold text-purple-600">100%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Platform Uptime</span>
                      <span className="font-bold text-orange-600">99.9%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
