"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BrainCircuit, Zap, CheckCircle, Clock, TrendingUp } from "lucide-react"

interface Agent {
  id: string
  name: string
  description: string
  icon: any
}

interface AgentCategory {
  title: string
  icon: any
  color: string
  agents: Agent[]
}

interface AgentDashboardProps {
  agentCategories: Record<string, AgentCategory>
  selectedAgent: string
  onAgentSelect: (agentId: string) => void
}

export default function AgentDashboard({ agentCategories, selectedAgent, onAgentSelect }: AgentDashboardProps) {
  const allAgents = Object.values(agentCategories).flatMap(category => category.agents)
  
  const agentStats = {
    total: allAgents.length,
    active: allAgents.length,
    success_rate: 96.2,
    uptime: 99.9
  }

  const getAgentStatus = (agentId: string) => {
    // Simulate different statuses for demo
    const statuses = ['active', 'processing', 'idle']
    return statuses[agentId.length % 3]
  }

  const getAgentPerformance = (agentId: string) => {
    // Simulate performance metrics
    return {
      accuracy: 90 + (agentId.length % 10),
      requests: 1000 + (agentId.length * 100),
      response_time: 50 + (agentId.length % 50)
    }
  }

  return (
    <div className="space-y-8">
      {/* Agent Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6 text-center">
            <BrainCircuit className="h-8 w-8 text-purple-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{agentStats.total}</div>
            <div className="text-gray-600">Total Agents</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{agentStats.active}</div>
            <div className="text-gray-600">Active Agents</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <TrendingUp className="h-8 w-8 text-blue-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{agentStats.success_rate}%</div>
            <div className="text-gray-600">Success Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <Zap className="h-8 w-8 text-orange-600 mx-auto mb-2" />
            <div className="text-3xl font-bold text-gray-900">{agentStats.uptime}%</div>
            <div className="text-gray-600">Uptime</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Agent Overview</TabsTrigger>
          <TabsTrigger value="categories">By Category</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allAgents.map((agent) => {
              const status = getAgentStatus(agent.id)
              const performance = getAgentPerformance(agent.id)
              
              return (
                <Card 
                  key={agent.id} 
                  className={`hover:shadow-lg transition-shadow cursor-pointer ${
                    selectedAgent === agent.id ? 'ring-2 ring-purple-500' : ''
                  }`}
                  onClick={() => onAgentSelect(agent.id)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-purple-100">
                          <agent.icon className="h-5 w-5 text-purple-600" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{agent.name}</CardTitle>
                          <CardDescription className="text-sm">{agent.description}</CardDescription>
                        </div>
                      </div>
                      <Badge 
                        variant={status === 'active' ? 'default' : 'secondary'}
                        className={
                          status === 'active' ? 'bg-green-100 text-green-800 border-green-200' :
                          status === 'processing' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                          'bg-gray-100 text-gray-800 border-gray-200'
                        }
                      >
                        {status === 'active' && <CheckCircle className="h-3 w-3 mr-1" />}
                        {status === 'processing' && <Clock className="h-3 w-3 mr-1" />}
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Accuracy</span>
                        <span>{performance.accuracy}%</span>
                      </div>
                      <Progress value={performance.accuracy} className="h-2" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Requests:</span>
                        <div className="text-blue-600">{performance.requests.toLocaleString()}</div>
                      </div>
                      <div>
                        <span className="font-medium">Response:</span>
                        <div className="text-green-600">{performance.response_time}ms</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        🤟 Deaf-First
                      </Badge>
                      <Button 
                        size="sm" 
                        variant={selectedAgent === agent.id ? "default" : "outline"}
                        onClick={(e) => {
                          e.stopPropagation()
                          onAgentSelect(agent.id)
                        }}
                      >
                        {selectedAgent === agent.id ? 'Selected' : 'Select'}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          {Object.entries(agentCategories).map(([categoryKey, category]) => (
            <Card key={categoryKey}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${category.color}`}>
                    <category.icon className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{category.title}</CardTitle>
                    <CardDescription>{category.agents.length} specialized AI agents</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {category.agents.map((agent) => {
                    const status = getAgentStatus(agent.id)
                    const performance = getAgentPerformance(agent.id)
                    
                    return (
                      <div 
                        key={agent.id}
                        className={`p-4 rounded-lg border hover:shadow-md transition-shadow cursor-pointer ${
                          selectedAgent === agent.id ? 'bg-purple-50 border-purple-200' : 'bg-white'
                        }`}
                        onClick={() => onAgentSelect(agent.id)}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <agent.icon className="h-4 w-4 text-gray-600" />
                            <h4 className="font-medium text-sm">{agent.name}</h4>
                          </div>
                          <Badge 
                            variant="outline" 
                            className={
                              status === 'active' ? \'text-green-
