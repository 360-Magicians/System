"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { ScrollArea } from "@/components/ui/scroll-area"
import { BrainCircuit, Zap, Hand, MessageSquare, Shield, TrendingUp, Globe, Users, Award } from "lucide-react"

interface AIModel {
  id: string
  name: string
  description: string
  accuracy: number
  latency: string
  features: string[]
  deaf_optimized: boolean
  accessibility_score: number
}

export default function MagiciansAIPlatform() {
  const [models, setModels] = useState<AIModel[]>([])
  const [selectedModel, setSelectedModel] = useState<string>("")
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [loading, setLoading] = useState(false)
  const [stats, setStats] = useState<any>({})

  useEffect(() => {
    fetchAIModels()
    fetchPlatformStats()
  }, [])

  const fetchAIModels = async () => {
    try {
      const response = await fetch("/api/360magicians/ai-models?action=models")
      const data = await response.json()
      setModels(data.models || [])
    } catch (error) {
      console.error("Failed to fetch AI models:", error)
    }
  }

  const fetchPlatformStats = async () => {
    try {
      const response = await fetch("/api/360magicians/ai-models?action=stats")
      const data = await response.json()
      setStats(data)
    } catch (error) {
      console.error("Failed to fetch platform stats:", error)
    }
  }

  const processWithAI = async () => {
    if (!selectedModel || !input.trim()) return

    setLoading(true)
    try {
      const response = await fetch("/api/360magicians/ai-models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: selectedModel,
          input: input,
          options: {
            accessibilityFeatures: ["visual-indicators", "haptic-feedback", "captions"],
            deafOptimized: true,
          },
        }),
      })

      const result = await response.json()
      setOutput(JSON.stringify(result, null, 2))
    } catch (error) {
      setOutput("Error processing with AI model")
    } finally {
      setLoading(false)
    }
  }

  const getModelIcon = (modelName: string) => {
    if (modelName.includes("ASL") || modelName.includes("BSL") || modelName.includes("Auslan")) {
      return <Hand className="h-5 w-5" />
    }
    if (modelName.includes("Avatar")) return <Users className="h-5 w-5" />
    if (modelName.includes("Accessibility")) return <Shield className="h-5 w-5" />
    if (modelName.includes("NLP")) return <MessageSquare className="h-5 w-5" />
    return <BrainCircuit className="h-5 w-5" />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BrainCircuit className="h-12 w-12 text-purple-600" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              360 MAGICIANS AI PLATFORM
            </h1>
            <Zap className="h-8 w-8 text-orange-500" />
          </div>
          <p className="text-xl text-gray-600">Deaf-Aware, Accessibility-Rooted Sign Language Models</p>
          <div className="flex justify-center gap-4">
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 border-purple-200">
              🧠 AI-Powered
            </Badge>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 border-blue-200">
              ♿ Accessibility-First
            </Badge>
            <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
              🤟 Sign Language Ready
            </Badge>
          </div>
        </div>

        {/* Platform Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <BrainCircuit className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{models.length}</div>
              <div className="text-gray-600">AI Models</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.average_accuracy || 0}%</div>
              <div className="text-gray-600">Avg Accuracy</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Globe className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.sign_languages_supported || 0}</div>
              <div className="text-gray-600">Sign Languages</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Shield className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.accessibility_compliance || "N/A"}</div>
              <div className="text-gray-600">WCAG Level</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Award className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-gray-900">{stats.uptime || "0%"}</div>
              <div className="text-gray-600">Uptime</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="models" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="models">AI Models</TabsTrigger>
            <TabsTrigger value="playground">AI Playground</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="models" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {models.map((model) => (
                <Card key={model.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {getModelIcon(model.name)}
                        <div>
                          <CardTitle className="text-lg">{model.name}</CardTitle>
                          <CardDescription>{model.description}</CardDescription>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Accuracy:</span>
                        <div className="text-green-600">{model.accuracy}%</div>
                      </div>
                      <div>
                        <span className="font-medium">Latency:</span>
                        <div className="text-blue-600">{model.latency}</div>
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Accessibility Score</span>
                        <span>{model.accessibility_score}%</span>
                      </div>
                      <Progress value={model.accessibility_score} className="h-2" />
                    </div>

                    <div>
                      <h4 className="font-medium text-sm mb-2">Features</h4>
                      <div className="flex flex-wrap gap-1">
                        {model.features.slice(0, 3).map((feature) => (
                          <Badge key={feature} variant="outline" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                        {model.features.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{model.features.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      {model.deaf_optimized && (
                        <Badge className="bg-green-100 text-green-800 border-green-200">♿ Deaf-Optimized</Badge>
                      )}
                      <Button size="sm" variant="outline">
                        Try Model
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="playground" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>AI Model Playground</CardTitle>
                <CardDescription>Test and interact with our deaf-aware AI models</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Select AI Model:</label>
                    <Select value={selectedModel} onValueChange={setSelectedModel}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose an AI model..." />
                      </SelectTrigger>
                      <SelectContent>
                        {models.map((model) => (
                          <SelectItem key={model.id} value={model.id}>
                            {model.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Input:</label>
                    <Textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Enter your text, sign language description, or accessibility request..."
                      rows={3}
                    />
                  </div>
                </div>

                <Button
                  onClick={processWithAI}
                  disabled={loading || !selectedModel || !input.trim()}
                  className="w-full"
                >
                  {loading ? "Processing with AI..." : "Process with AI Model"}
                </Button>

                {output && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">AI Response:</label>
                    <ScrollArea className="h-64 w-full rounded-md border bg-gray-50 p-4">
                      <pre className="text-sm">{output}</pre>
                    </ScrollArea>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Model Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>ASL Interpreter Accuracy</span>
                      <span className="font-bold text-green-600">96.8%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Avatar Generation Quality</span>
                      <span className="font-bold text-blue-600">97.3%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Accessibility Compliance</span>
                      <span className="font-bold text-purple-600">99.1%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Deaf Community Satisfaction</span>
                      <span className="font-bold text-orange-600">98.5%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Usage Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Total API Requests</span>
                      <span className="font-bold text-green-600">{stats.total_requests || 0}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Deaf-Optimized Requests</span>
                      <span className="font-bold text-blue-600">{stats.deaf_optimization || "0%"}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Sign Languages Processed</span>
                      <span className="font-bold text-purple-600">4</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Average Response Time</span>
                      <span className="font-bold text-orange-600">&lt; 100ms</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Accessibility Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600 mb-2">70M+</div>
                    <div className="text-gray-600">Deaf People Served</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600 mb-2">100%</div>
                    <div className="text-gray-600">WCAG AA Compliance</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600 mb-2">24/7</div>
                    <div className="text-gray-600">AI Availability</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
