"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CheckCircle, XCircle, Clock, Eye, Hand, Shield, Zap, Activity, AlertTriangle, RefreshCw } from "lucide-react"

interface AgentStatus {
  agentType: string
  status: "operational" | "error"
  responseTime: number
  accessibilityScore: number
  deafFirstOptimized: boolean
  aslCompatible: boolean
  visualFirst: boolean
  error?: string
  timestamp: string
}

interface VerificationSummary {
  totalAgents: number
  operationalAgents: number
  healthPercentage: number
  averageResponseTime: number
  averageAccessibilityScore: number
  deafFirstCompliance: number
  aslCompatibility: number
  visualFirstDesign: number
  timestamp: string
}

export default function AgentVerificationDashboard() {
  const [summary, setSummary] = useState<VerificationSummary | null>(null)
  const [agents, setAgents] = useState<AgentStatus[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<string>("")

  const runVerification = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/verify-agents")
      const data = await response.json()

      if (data.success) {
        setSummary(data.summary)
        setAgents(data.agents)
        setLastUpdate(new Date().toLocaleString())
      }
    } catch (error) {
      console.error("Verification failed:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    runVerification()
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "operational":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "error":
        return <XCircle className="h-5 w-5 text-red-500" />
      default:
        return <Clock className="h-5 w-5 text-yellow-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operational":
        return "bg-green-50 border-green-200"
      case "error":
        return "bg-red-50 border-red-200"
      default:
        return "bg-yellow-50 border-yellow-200"
    }
  }

  const getAccessibilityBadge = (score: number) => {
    if (score >= 0.9) return <Badge className="bg-green-500">Excellent</Badge>
    if (score >= 0.8) return <Badge className="bg-blue-500">Good</Badge>
    if (score >= 0.7) return <Badge className="bg-yellow-500">Fair</Badge>
    return <Badge variant="destructive">Needs Improvement</Badge>
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 flex items-center gap-3">
              <Shield className="h-10 w-10 text-blue-600" />
              Agent Verification Dashboard
            </h1>
            <p className="text-lg text-gray-600 mt-2">Real-time monitoring of all 12 deaf-first AI agents</p>
            {lastUpdate && <p className="text-sm text-gray-500 mt-1">Last updated: {lastUpdate}</p>}
          </div>

          <Button onClick={runVerification} disabled={isLoading} size="lg" className="flex items-center gap-2">
            <RefreshCw className={`h-5 w-5 ${isLoading ? "animate-spin" : ""}`} />
            {isLoading ? "Verifying..." : "Run Verification"}
          </Button>
        </div>

        {/* Summary Cards */}
        {summary && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">System Health</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{summary.healthPercentage.toFixed(1)}%</div>
                <p className="text-xs text-muted-foreground">
                  {summary.operationalAgents}/{summary.totalAgents} agents operational
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Response Time</CardTitle>
                <Zap className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{summary.averageResponseTime}ms</div>
                <p className="text-xs text-muted-foreground">Average across all agents</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Accessibility Score</CardTitle>
                <Eye className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{(summary.averageAccessibilityScore * 100).toFixed(0)}%</div>
                <p className="text-xs text-muted-foreground">WCAG AA compliance</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">ASL Compatibility</CardTitle>
                <Hand className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{summary.aslCompatibility}%</div>
                <p className="text-xs text-muted-foreground">Sign language support</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Deaf-First Compliance Overview */}
        {summary && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Deaf-First Platform Compliance
              </CardTitle>
              <CardDescription>Accessibility and cultural competency verification</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Visual Accessibility</h4>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Visual-first design enabled</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">High contrast mode available</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">No audio dependencies</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">ASL Integration</h4>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">ASL considerations in all responses</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Sign language compatibility verified</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Cultural competency integrated</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-sm">Legal Compliance</h4>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">ADA Title I compliant</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">WCAG 2.1 AA standards met</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Screen reader optimized</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Individual Agent Status */}
        <Card>
          <CardHeader>
            <CardTitle>Individual Agent Status</CardTitle>
            <CardDescription>Detailed status for each of the 12 deaf-first AI agents</CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[600px]">
              <div className="space-y-4">
                {agents.map((agent) => (
                  <Card key={agent.agentType} className={`${getStatusColor(agent.status)}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(agent.status)}
                          <div>
                            <h4 className="font-semibold capitalize">{agent.agentType.replace("-", " ")} AI</h4>
                            <p className="text-sm text-gray-600">Response: {agent.responseTime}ms</p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {getAccessibilityBadge(agent.accessibilityScore)}
                          {agent.deafFirstOptimized && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Eye className="h-3 w-3" />
                              Deaf-First
                            </Badge>
                          )}
                          {agent.aslCompatible && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Hand className="h-3 w-3" />
                              ASL
                            </Badge>
                          )}
                          {agent.visualFirst && (
                            <Badge variant="outline" className="flex items-center gap-1">
                              <Shield className="h-3 w-3" />
                              Visual
                            </Badge>
                          )}
                        </div>
                      </div>

                      {agent.error && (
                        <div className="mt-3 p-2 bg-red-100 border border-red-200 rounded flex items-center gap-2">
                          <AlertTriangle className="h-4 w-4 text-red-500" />
                          <span className="text-sm text-red-700">{agent.error}</span>
                        </div>
                      )}

                      <div className="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                        <div>
                          <span className="font-medium">Accessibility:</span>
                          <span className="ml-1">{(agent.accessibilityScore * 100).toFixed(0)}%</span>
                        </div>
                        <div>
                          <span className="font-medium">Status:</span>
                          <span className="ml-1 capitalize">{agent.status}</span>
                        </div>
                        <div>
                          <span className="font-medium">Visual-First:</span>
                          <span className="ml-1">{agent.visualFirst ? "✅" : "❌"}</span>
                        </div>
                        <div>
                          <span className="font-medium">ASL Ready:</span>
                          <span className="ml-1">{agent.aslCompatible ? "✅" : "❌"}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
