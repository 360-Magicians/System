"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Send, Bot, User, Loader2 } from 'lucide-react'

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  agentType?: string
}

interface ChatInterfaceProps {
  selectedAgent: string
}

export default function ChatInterface({ selectedAgent }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Add welcome message when agent changes
    if (selectedAgent) {
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: `Hello! I'm the ${selectedAgent.replace("-", " ")} AI agent. I'm here to help with deaf-first solutions and accessibility. How can I assist you today?`,
        timestamp: new Date(),
        agentType: selectedAgent,
      }
      setMessages([welcomeMessage])
    }
  }, [selectedAgent])

  useEffect(() => {
    // Scroll to bottom when new messages are added
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const sendMessage = async () => {
    if (!input.trim() || loading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setLoading(true)

    try {
      // Simulate AI response (integrate with actual AI service)
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: generateAIResponse(selectedAgent, input),
        timestamp: new Date(),
        agentType: selectedAgent,
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Failed to get AI response:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "I apologize, but I'm having trouble processing your request right now. Please try again.",
        timestamp: new Date(),
        agentType: selectedAgent,
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setLoading(false)
    }
  }

  const generateAIResponse = (agent: string, userInput: string): string => {
    const responses = {
      "career-matching": `Based on your request about "${userInput}", I can help match you with accessible career opportunities. I'll consider your skills, accommodation needs, and ASL requirements to find the best job matches. Would you like me to start by assessing your current skills and accessibility needs?`,
      "vr-coordination": `For your VR4Deaf coordination request about "${userInput}", I can connect you with certified vocational rehabilitation vendors who specialize in deaf services. I'll ensure they have ASL capabilities and high accessibility ratings. Let me find the best vendor matches in your area.`,
      "interview-prep": `I'll help you prepare for interviews with a focus on accessibility accommodations. For "${userInput}", I can provide practice questions, accommodation request templates, and tips for communicating your needs effectively. Would you like to start with mock interview scenarios?`,
      "workplace-accommodation": `Regarding workplace accommodations for "${userInput}", I can help you identify necessary accommodations, draft formal requests, and track implementation. I'll ensure all solutions are ADA-compliant and culturally appropriate for the deaf community.`,
      "startup-incubation": `For your startup idea about "${userInput}", I can help validate the business model with a focus on accessibility markets. I'll identify funding sources that prioritize inclusive businesses and connect you with deaf entrepreneur networks. Let's start with market analysis.`,
      "document-translation": `I can help make "${userInput}" more accessible by simplifying complex language, adding visual elements, and ensuring deaf-friendly formatting. I'll also provide ASL glossing if needed and ensure the content meets WCAG accessibility standards.`,
      "funding-intelligence": `Based on your funding needs for "${userInput}", I can identify grants and funding sources that prioritize accessibility and deaf community initiatives. I'll help you craft compelling applications that highlight your impact on the deaf community.`,
      "growth-planning": `For scaling your business around "${userInput}", I'll develop strategies that prioritize accessibility and deaf community engagement. This includes market expansion plans, partnership opportunities, and sustainable growth models that maintain your deaf-first values.`,
      "workforce-partnership": `I can help establish employer partnerships for "${userInput}" by identifying companies committed to deaf inclusion, providing accessibility training resources, and facilitating successful job placements with ongoing support.`,
      "case-management": `For case management of "${userInput}", I'll create a unified tracking system that monitors progress across all rehabilitation and career services, ensuring seamless coordination between vendors and optimal outcomes for deaf clients.`,
      "progress-analytics": `Analyzing the progress data for "${userInput}", I can provide insights on performance metrics, identify areas for improvement, and recommend optimization strategies to enhance outcomes for deaf individuals in vocational rehabilitation programs.`,
      "community-intelligence": `Based on community feedback about "${userInput}", I'll process insights to improve our services, identify emerging needs in the deaf community, and recommend enhancements to better serve deaf individuals in their career and business development journeys.`,
    }

    return (
      responses[agent as keyof typeof responses] ||
      `I understand you're asking about "${userInput}". As a deaf-first AI agent, I'm here to provide accessible solutions that prioritize visual communication, cultural competency, and inclusive design. How can I help you further?`
    )
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="h-5 w-5" />
          AI Chat Interface
        </CardTitle>
        <CardDescription>
          Chatting with: <Badge variant="secondary">{selectedAgent.replace("-", " ")}</Badge>
        </CardDescription>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col space-y-4">
        <ScrollArea className="flex-1 pr-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`flex gap-3 max-w-[80%] ${message.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === "user" ? "bg-blue-500" : "bg-purple-500"
                    }`}
                  >
                    {message.role === "user" ? (
                      <User className="h-4 w-4 text-white" />
                    ) : (
                      <Bot className="h-4 w-4 text-white" />
                    )}
                  </div>
                  <div
                    className={`rounded-lg p-3 ${
                      message.role === "user" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-900 border"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p className={`text-xs mt-1 ${message.role === "user" ? "text-blue-100" : "text-gray-500"}`}>
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center flex-shrink-0">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-gray-100 text-gray-900 border rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">AI is thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message... (Press Enter to send)"
            disabled={loading}
            className="flex-1"
          />
          <Button onClick={sendMessage} disabled={loading || !input.trim()} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>

        <div className="text-xs text-gray-500 text-center">
          💡 This AI agent is optimized for deaf-first solutions and accessibility
        </div>
      </CardContent>
    </Card>
  )
}
