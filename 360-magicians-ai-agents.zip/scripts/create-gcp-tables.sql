-- Google Cloud Platform Integration Tables
-- 360 Magicians Deaf-First Platform Database Schema

-- API Usage Tracking
CREATE TABLE IF NOT EXISTS api_usage (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    endpoint VARCHAR(255) NOT NULL,
    agent_type VARCHAR(100),
    request_payload JSONB,
    response_payload JSONB,
    request_duration INTEGER, -- milliseconds
    status_code INTEGER,
    ip_address INET,
    user_agent TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AI Agent Results Storage
CREATE TABLE IF NOT EXISTS ai_agent_results (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    agent_type VARCHAR(100) NOT NULL,
    request_payload JSONB NOT NULL,
    result_data JSONB,
    success BOOLEAN DEFAULT FALSE,
    error_message TEXT,
    processing_time INTEGER, -- milliseconds
    vertex_ai_metadata JSONB,
    vura_integration JSONB,
    accessibility_score DECIMAL(3,2),
    deaf_optimized BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- File Upload Tracking
CREATE TABLE IF NOT EXISTS file_uploads (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    file_id VARCHAR(255) UNIQUE NOT NULL,
    original_name VARCHAR(500) NOT NULL,
    file_name VARCHAR(500) NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    bucket_name VARCHAR(255) NOT NULL,
    file_size BIGINT NOT NULL,
    content_type VARCHAR(255),
    public_url TEXT,
    signed_url TEXT,
    thumbnail_url TEXT,
    metadata JSONB,
    processing_status VARCHAR(50) DEFAULT 'uploaded',
    accessibility_compliant BOOLEAN DEFAULT NULL,
    asl_processed BOOLEAN DEFAULT FALSE,
    captions_generated BOOLEAN DEFAULT FALSE,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    deleted_at TIMESTAMPTZ
);

-- ASL Video Processing Pipeline
CREATE TABLE IF NOT EXISTS asl_video_processing (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    file_upload_id UUID REFERENCES file_uploads(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    original_video_url TEXT NOT NULL,
    processed_video_url TEXT,
    thumbnail_url TEXT,
    captions_url TEXT,
    video_duration INTEGER, -- seconds
    video_quality VARCHAR(50),
    asl_language VARCHAR(10) DEFAULT 'ASL',
    processing_stages JSONB DEFAULT '{}',
    accessibility_features JSONB DEFAULT '{}',
    processing_status VARCHAR(50) DEFAULT 'pending',
    processing_error TEXT,
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vertex AI Model Performance Tracking
CREATE TABLE IF NOT EXISTS vertex_ai_performance (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    model_name VARCHAR(255) NOT NULL,
    endpoint_name VARCHAR(255),
    agent_type VARCHAR(100) NOT NULL,
    request_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    error_count INTEGER DEFAULT 0,
    avg_response_time DECIMAL(8,2), -- milliseconds
    total_tokens_processed BIGINT DEFAULT 0,
    accessibility_score DECIMAL(3,2),
    deaf_satisfaction_rating DECIMAL(3,2),
    date DATE NOT NULL,
    hour INTEGER NOT NULL CHECK (hour >= 0 AND hour <= 23),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(model_name, agent_type, date, hour)
);

-- Cloud Storage Analytics
CREATE TABLE IF NOT EXISTS storage_analytics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    bucket_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    total_files BIGINT DEFAULT 0,
    total_size_bytes BIGINT DEFAULT 0,
    upload_count INTEGER DEFAULT 0,
    download_count INTEGER DEFAULT 0,
    delete_count INTEGER DEFAULT 0,
    bandwidth_usage_bytes BIGINT DEFAULT 0,
    cost_usd DECIMAL(10,4) DEFAULT 0.00,
    date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(bucket_name, file_type, date)
);

-- Accessibility Compliance Tracking
CREATE TABLE IF NOT EXISTS accessibility_compliance (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    service_name VARCHAR(255) NOT NULL,
    compliance_category VARCHAR(100) NOT NULL,
    compliance_score DECIMAL(3,2) NOT NULL,
    ada_compliant BOOLEAN DEFAULT FALSE,
    wcag_level VARCHAR(10),
    section_508_compliant BOOLEAN DEFAULT FALSE,
    deaf_accessible BOOLEAN DEFAULT TRUE,
    asl_supported BOOLEAN DEFAULT FALSE,
    visual_indicators BOOLEAN DEFAULT FALSE,
    screen_reader_compatible BOOLEAN DEFAULT FALSE,
    keyboard_navigable BOOLEAN DEFAULT FALSE,
    compliance_details JSONB,
    tested_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Deaf Community Feedback
CREATE TABLE IF NOT EXISTS deaf_community_feedback (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    feature_area VARCHAR(255) NOT NULL,
    satisfaction_score INTEGER CHECK (satisfaction_score >= 1 AND satisfaction_score <= 5),
    accessibility_rating INTEGER CHECK (accessibility_rating >= 1 AND accessibility_rating <= 5),
    asl_quality_rating INTEGER CHECK (asl_quality_rating >= 1 AND asl_quality_rating <= 5),
    visual_clarity_rating INTEGER CHECK (visual_clarity_rating >= 1 AND visual_clarity_rating <= 5),
    feedback_text TEXT,
    suggestions TEXT,
    user_segment VARCHAR(100), -- 'deaf', 'hard-of-hearing', 'deafblind', 'coda'
    asl_proficiency VARCHAR(50), -- 'native', 'fluent', 'intermediate', 'beginner'
    communication_preference VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- GCP Resource Usage Tracking
CREATE TABLE IF NOT EXISTS gcp_resource_usage (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    project_id VARCHAR(255) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    resource_type VARCHAR(255) NOT NULL,
    region VARCHAR(100),
    usage_amount DECIMAL(15,6) NOT NULL,
    usage_unit VARCHAR(50) NOT NULL,
    cost_usd DECIMAL(10,4) NOT NULL,
    billing_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(project_id, service_name, resource_type, region, billing_date)
);

-- Indexes for Performance Optimization
CREATE INDEX IF NOT EXISTS idx_api_usage_user_id ON api_usage(user_id);
CREATE INDEX IF NOT EXISTS idx_api_usage_timestamp ON api_usage(timestamp);
CREATE INDEX IF NOT EXISTS idx_api_usage_endpoint ON api_usage(endpoint);
CREATE INDEX IF NOT EXISTS idx_api_usage_agent_type ON api_usage(agent_type);

CREATE INDEX IF NOT EXISTS idx_ai_agent_results_user_id ON ai_agent_results(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_agent_results_agent_type ON ai_agent_results(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_agent_results_created_at ON ai_agent_results(created_at);
CREATE INDEX IF NOT EXISTS idx_ai_agent_results_success ON ai_agent_results(success);

CREATE INDEX IF NOT EXISTS idx_file_uploads_user_id ON file_uploads(user_id);
CREATE INDEX IF NOT EXISTS idx_file_uploads_file_type ON file_uploads(file_type);
CREATE INDEX IF NOT EXISTS idx_file_uploads_processing_status ON file_uploads(processing_status);
CREATE INDEX IF NOT EXISTS idx_file_uploads_created_at ON file_uploads(created_at);

CREATE INDEX IF NOT EXISTS idx_asl_video_processing_user_id ON asl_video_processing(user_id);
CREATE INDEX IF NOT EXISTS idx_asl_video_processing_status ON asl_video_processing(processing_status);
CREATE INDEX IF NOT EXISTS idx_asl_video_processing_created_at ON asl_video_processing(created_at);

CREATE INDEX IF NOT EXISTS idx_vertex_ai_performance_date_hour ON vertex_ai_performance(date, hour);
CREATE INDEX IF NOT EXISTS idx_vertex_ai_performance_agent_type ON vertex_ai_performance(agent_type);

CREATE INDEX IF NOT EXISTS idx_accessibility_compliance_user_id ON accessibility_compliance(user_id);
CREATE INDEX IF NOT EXISTS idx_accessibility_compliance_service ON accessibility_compliance(service_name);
CREATE INDEX IF NOT EXISTS idx_accessibility_compliance_tested_at ON accessibility_compliance(tested_at);

CREATE INDEX IF NOT EXISTS idx_deaf_feedback_user_id ON deaf_community_feedback(user_id);
CREATE INDEX IF NOT EXISTS idx_deaf_feedback_feature_area ON deaf_community_feedback(feature_area);
CREATE INDEX IF NOT EXISTS idx_deaf_feedback_created_at ON deaf_community_feedback(created_at);

-- Row Level Security (RLS) Policies
ALTER TABLE api_usage ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_agent_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE file_uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE asl_video_processing ENABLE ROW LEVEL SECURITY;
ALTER TABLE accessibility_compliance ENABLE ROW LEVEL SECURITY;
ALTER TABLE deaf_community_feedback ENABLE ROW LEVEL SECURITY;

-- RLS Policies for User Data Protection
CREATE POLICY "Users can view their own API usage" ON api_usage
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own API usage" ON api_usage
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own AI results" ON ai_agent_results
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own AI results" ON ai_agent_results
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own files" ON file_uploads
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can upload their own files" ON file_uploads
    FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own files" ON file_uploads
    FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own files" ON file_uploads
    FOR DELETE USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own ASL processing" ON asl_video_processing
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own compliance data" ON accessibility_compliance
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can provide their own feedback" ON deaf_community_feedback
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Functions for Analytics
CREATE OR REPLACE FUNCTION calculate_accessibility_score(
    compliance_data JSONB
) RETURNS DECIMAL(3,2) AS $$
BEGIN
    -- Calculate accessibility score based on compliance data
    -- This is a simplified example - real implementation would be more complex
    RETURN LEAST(
        GREATEST(
            (
                COALESCE((compliance_data->>'ada_compliant')::BOOLEAN::INTEGER, 0) * 0.3 +
                COALESCE((compliance_data->>'deaf_accessible')::BOOLEAN::INTEGER, 0) * 0.3 +
                COALESCE((compliance_data->>'asl_supported')::BOOLEAN::INTEGER, 0) * 0.2 +
                COALESCE((compliance_data->>'visual_indicators')::BOOLEAN::INTEGER, 0) * 0.1 +
                COALESCE((compliance_data->>'screen_reader_compatible')::BOOLEAN::INTEGER, 0) * 0.1
            ),
            0.0
        ),
        1.0
    );
END;
$$ LANGUAGE plpgsql;

-- Function to Update AI Performance Metrics
CREATE OR REPLACE FUNCTION update_vertex_ai_metrics(
    p_model_name VARCHAR(255),
    p_agent_type VARCHAR(100),
    p_success BOOLEAN,
    p_response_time INTEGER,
    p_tokens_processed INTEGER DEFAULT 0
) RETURNS VOID AS $$
DECLARE
    current_date DATE := CURRENT_DATE;
    current_hour INTEGER := EXTRACT(HOUR FROM NOW());
BEGIN
    INSERT INTO vertex_ai_performance (
        model_name,
        agent_type,
        date,
        hour,
        request_count,
        success_count,
        error_count,
        avg_response_time,
        total_tokens_processed
    ) VALUES (
        p_model_name,
        p_agent_type,
        current_date,
        current_hour,
        1,
        CASE WHEN p_success THEN 1 ELSE 0 END,
        CASE WHEN p_success THEN 0 ELSE 1 END,
        p_response_time,
        p_tokens_processed
    )
    ON CONFLICT (model_name, agent_type, date, hour) DO UPDATE SET
        request_count = vertex_ai_performance.request_count + 1,
        success_count = vertex_ai_performance.success_count + 
            CASE WHEN p_success THEN 1 ELSE 0 END,
        error_count = vertex_ai_performance.error_count + 
            CASE WHEN p_success THEN 0 ELSE 1 END,
        avg_response_time = (
            (vertex_ai_performance.avg_response_time * vertex_ai_performance.request_count + p_response_time) /
            (vertex_ai_performance.request_count + 1)
        ),
        total_tokens_processed = vertex_ai_performance.total_tokens_processed + p_tokens_processed;
END;
$$ LANGUAGE plpgsql;

-- Automated Data Cleanup (delete old records)
CREATE OR REPLACE FUNCTION cleanup_old_data() RETURNS VOID AS $$
BEGIN
    -- Clean up API usage older than 90 days
    DELETE FROM api_usage WHERE created_at < NOW() - INTERVAL '90 days';
    
    -- Clean up old AI results (keep successful ones longer)
    DELETE FROM ai_agent_results 
    WHERE created_at < NOW() - INTERVAL '180 days' AND success = false;
    
    DELETE FROM ai_agent_results 
    WHERE created_at < NOW() - INTERVAL '365 days';
    
    -- Clean up old performance metrics (older than 1 year)
    DELETE FROM vertex_ai_performance WHERE date < CURRENT_DATE - INTERVAL '365 days';
    
    -- Clean up deleted files older than 30 days
    DELETE FROM file_uploads 
    WHERE deleted_at IS NOT NULL AND deleted_at < NOW() - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;

-- Schedule automated cleanup (requires pg_cron extension)
-- SELECT cron.schedule('cleanup-old-data', '0 2 * * *', 'SELECT cleanup_old_data();');

COMMENT ON TABLE api_usage IS 'Tracks all API calls for analytics and billing';
COMMENT ON TABLE ai_agent_results IS 'Stores results from all AI agent interactions';
COMMENT ON TABLE file_uploads IS 'Tracks all file uploads to Google Cloud Storage';
COMMENT ON TABLE asl_video_processing IS 'Tracks ASL video processing pipeline status';
COMMENT ON TABLE vertex_ai_performance IS 'Aggregated performance metrics for Vertex AI models';
COMMENT ON TABLE storage_analytics IS 'Cloud Storage usage and cost analytics';
COMMENT ON TABLE accessibility_compliance IS 'Accessibility compliance test results';
COMMENT ON TABLE deaf_community_feedback IS 'Feedback from deaf community users';
COMMENT ON TABLE gcp_resource_usage IS 'Google Cloud Platform resource usage and costs';
