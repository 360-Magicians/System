-- 360 Magicians AI Platform Database Schema
-- Deaf-Aware, Accessibility-Rooted Sign Language Models

-- AI Models registry
CREATE TABLE IF NOT EXISTS ai_models (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_name VARCHAR(255) NOT NULL UNIQUE,
    model_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    accuracy_percentage DECIMAL(5,2) NOT NULL,
    latency_ms INTEGER NOT NULL,
    features TEXT[] NOT NULL,
    deaf_optimized BOOLEAN NOT NULL DEFAULT true,
    accessibility_score INTEGER NOT NULL,
    sign_languages_supported TEXT[] DEFAULT ARRAY['ASL'],
    cultural_competency_score INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AI Model usage tracking
CREATE TABLE IF NOT EXISTS ai_model_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_name VARCHAR(255) NOT NULL,
    user_id VARCHAR(255),
    session_id VARCHAR(255),
    input_type VARCHAR(50) NOT NULL,
    input_size_bytes INTEGER,
    processing_time_ms INTEGER,
    accuracy_achieved DECIMAL(5,2),
    accessibility_features_used TEXT[],
    deaf_optimizations_applied TEXT[],
    user_agent TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Sign language processing results
CREATE TABLE IF NOT EXISTS sign_language_processing (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_id UUID REFERENCES ai_models(id),
    input_text TEXT,
    output_asl_gloss TEXT,
    output_avatar_url TEXT,
    cultural_notes TEXT[],
    confidence_score DECIMAL(5,2),
    accessibility_enhancements JSONB DEFAULT '{}',
    processing_metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Accessibility audit results
CREATE TABLE IF NOT EXISTS accessibility_audits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    audit_target_url TEXT,
    audit_target_type VARCHAR(50),
    wcag_compliance_level VARCHAR(10),
    deaf_accessibility_score INTEGER,
    issues_found JSONB DEFAULT '[]',
    recommendations JSONB DEFAULT '[]',
    accessibility_enhancements JSONB DEFAULT '{}',
    audit_performed_by VARCHAR(255) DEFAULT 'accessibility-audit-ai',
    audit_date TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Avatar generation tracking
CREATE TABLE IF NOT EXISTS avatar_generations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    model_id UUID REFERENCES ai_models(id),
    avatar_type VARCHAR(100) NOT NULL,
    input_parameters JSONB NOT NULL,
    output_avatar_url TEXT,
    animation_data JSONB,
    cultural_accuracy_score INTEGER,
    accessibility_features JSONB DEFAULT '{}',
    generation_time_ms INTEGER,
    user_feedback_score INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Platform analytics and metrics
CREATE TABLE IF NOT EXISTS platform_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(10,2) NOT NULL,
    metric_unit VARCHAR(50),
    category VARCHAR(50) NOT NULL,
    deaf_community_impact JSONB DEFAULT '{}',
    accessibility_impact JSONB DEFAULT '{}',
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User feedback and community input
CREATE TABLE IF NOT EXISTS community_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id VARCHAR(255),
    feedback_type VARCHAR(50) NOT NULL,
    model_name VARCHAR(255),
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    feedback_text TEXT,
    deaf_community_member BOOLEAN DEFAULT false,
    asl_proficiency_level VARCHAR(50),
    accessibility_suggestions TEXT[],
    cultural_accuracy_feedback TEXT,
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_ai_models_type ON ai_models(model_type);
CREATE INDEX IF NOT EXISTS idx_ai_models_deaf_optimized ON ai_models(deaf_optimized);
CREATE INDEX IF NOT EXISTS idx_ai_model_usage_model_name ON ai_model_usage(model_name);
CREATE INDEX IF NOT EXISTS idx_ai_model_usage_timestamp ON ai_model_usage(timestamp);
CREATE INDEX IF NOT EXISTS idx_accessibility_audits_date ON accessibility_audits(audit_date);
CREATE INDEX IF NOT EXISTS idx_avatar_generations_model_id ON avatar_generations(model_id);
CREATE INDEX IF NOT EXISTS idx_platform_metrics_category ON platform_metrics(category);
CREATE INDEX IF NOT EXISTS idx_community_feedback_model_name ON community_feedback(model_name);

-- Insert AI models data
INSERT INTO ai_models (model_name, model_type, description, accuracy_percentage, latency_ms, features, deaf_optimized, accessibility_score, sign_languages_supported, cultural_competency_score) VALUES
('asl-interpreter', 'Sign Language Translation', 'Advanced American Sign Language interpretation with cultural context', 96.8, 100, ARRAY['real-time-translation', 'cultural-context', 'regional-dialects', 'facial-expressions'], true, 98, ARRAY['ASL'], 95),
('bsl-interpreter', 'Sign Language Translation', 'British Sign Language interpretation with UK cultural nuances', 94.2, 120, ARRAY['two-handed-fingerspelling', 'uk-dialects', 'cultural-context'], true, 96, ARRAY['BSL'], 92),
('auslan-interpreter', 'Sign Language Translation', 'Australian Sign Language with indigenous cultural integration', 91.5, 150, ARRAY['one-handed-fingerspelling', 'indigenous-signs', 'regional-variations'], true, 94, ARRAY['Auslan'], 89),
('universal-avatar', 'Avatar Generation', 'Multi-language signing avatar with cultural authenticity', 97.3, 80, ARRAY['multi-language', 'avatar-generation', 'emotion-mapping', 'cultural-accuracy'], true, 99, ARRAY['ASL', 'BSL', 'Auslan', 'LSF'], 97),
('deaf-nlp', 'Natural Language Processing', 'NLP optimized for deaf communication patterns and visual language', 95.7, 50, ARRAY['visual-language-processing', 'deaf-syntax', 'cultural-context', 'plain-language'], true, 97, ARRAY['ASL', 'BSL'], 94),
('accessibility-audit', 'Accessibility Analysis', 'Automated accessibility compliance checking with deaf-first principles', 99.1, 200, ARRAY['wcag-compliance', 'deaf-first-audit', 'sign-language-detection', 'visual-optimization'], true, 100, ARRAY['ASL', 'BSL', 'Auslan'], 98);

-- Insert sample platform metrics
INSERT INTO platform_metrics (metric_name, metric_value, metric_unit, category, deaf_community_impact, accessibility_impact) VALUES
('total_api_requests', 125000, 'requests', 'usage', '{"deaf_users_served": 15000, "asl_translations": 45000}', '{"wcag_audits": 2500, "accessibility_improvements": 8900}'),
('average_accuracy', 96.2, 'percentage', 'performance', '{"deaf_satisfaction": 98.5, "cultural_accuracy": 95.8}', '{"compliance_rate": 99.1, "accessibility_score": 97.3}'),
('sign_languages_supported', 4, 'languages', 'coverage', '{"asl_users": 8500, "bsl_users": 3200, "auslan_users": 1800}', '{"global_reach": "70M+ deaf people", "cultural_coverage": "85%"}'),
('uptime_percentage', 99.9, 'percentage', 'reliability', '{"service_availability": "24/7", "emergency_access": true}', '{"accessibility_always_on": true, "deaf_first_priority": true}');
