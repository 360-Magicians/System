-- Vertex AI Integration Tables for 360 Magicians Platform
-- Comprehensive schema for AI agent management and analytics

-- AI Agent Configurations
CREATE TABLE IF NOT EXISTS ai_agent_configs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    agent_type VARCHAR(100) UNIQUE NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    description TEXT,
    system_instruction TEXT NOT NULL,
    model_name VARCHAR(255) DEFAULT 'gemini-1.5-pro',
    temperature DECIMAL(3,2) DEFAULT 0.7,
    max_tokens INTEGER DEFAULT 8192,
    top_p DECIMAL(3,2) DEFAULT 0.95,
    top_k INTEGER DEFAULT 40,
    is_active BOOLEAN DEFAULT TRUE,
    deaf_optimized BOOLEAN DEFAULT TRUE,
    accessibility_features JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default agent configurations
INSERT INTO ai_agent_configs (agent_type, display_name, description, system_instruction, accessibility_features) VALUES
('career-matching', 'Career Matching AI', 'Intelligent pairing of skills, accommodations, and job requirements', 
 'You are the Career Matching AI for 360 Magicians, specializing in deaf-first career guidance...', 
 '{"visual_job_descriptions": true, "accommodation_compatibility": true, "asl_workplace_support": true}'),

('vr-coordination', 'VR Coordination AI', 'VURA AI integration for VR/AR rehabilitation services', 
 'You are the VR4DEAF Coordination AI, integrated with comprehensive VR4DEAF platform...', 
 '{"sign_language_modeling": true, "haptic_feedback": true, "visual_accessibility": true}'),

('document-translation', 'Document Translation AI', 'Complex document simplification and accessibility', 
 'You are the Document Translation AI, specializing in accessibility for the Deaf community...', 
 '{"plain_language": true, "visual_structure": true, "asl_glossing": true}'),

('interview-prep', 'Interview Preparation AI', 'Accessibility-focused interview preparation', 
 'You are the Interview Preparation AI, specializing in deaf-first interview coaching...', 
 '{"visual_cues": true, "accommodation_planning": true, "confidence_building": true}'),

('workplace-accommodation', 'Workplace Accommodation AI', 'ADA compliance and reasonable accommodations', 
 'You are the Workplace Accommodation AI, expert in ADA compliance and inclusive workplaces...', 
 '{"ada_compliance": true, "technology_solutions": true, "legal_advocacy": true}'),

('startup-incubation', 'Startup Incubation AI', 'Resource identification and business model validation', 
 'You are the Startup Incubation AI, supporting deaf entrepreneurs and accessibility startups...', 
 '{"accessibility_market_analysis": true, "deaf_community_validation": true, "inclusive_business_modeling": true}'),

('funding-intelligence', 'Funding Intelligence AI', 'Grant and investment opportunity identification', 
 'You are the Funding Intelligence AI, expert in funding for deaf entrepreneurs...', 
 '{"grant_matching": true, "investor_networks": true, "community_funding": true}'),

('growth-planning', 'Growth Planning AI', 'Strategic planning and market expansion', 
 'You are the Growth Planning AI, specializing in scaling deaf-first businesses...', 
 '{"market_expansion": true, "community_growth": true, "partnership_development": true}'),

('workforce-partnership', 'Workforce Partnership AI', 'Employer-employee relationship facilitation', 
 'You are the Workforce Partnership AI, facilitating deaf professional connections...', 
 '{"employer_education": true, "partnership_development": true, "community_outreach": true}'),

('case-management', 'Case Management AI', 'Comprehensive support service coordination', 
 'You are the Case Management AI, coordinating support services for deaf individuals...', 
 '{"multi_service_coordination": true, "progress_tracking": true, "crisis_intervention": true}'),

('progress-analytics', 'Progress Analytics AI', 'Outcome measurement and impact analysis', 
 'You are the Progress Analytics AI, analyzing outcomes across deaf-first services...', 
 '{"data_visualization": true, "outcome_measurement": true, "trend_analysis": true}'),

('community-intelligence', 'Community Intelligence AI', 'Deaf community needs and trend analysis', 
 'You are the Community Intelligence AI, analyzing deaf community needs and opportunities...', 
 '{"needs_assessment": true, "trend_identification": true, "cultural_competency": true}');

-- AI Model Performance Tracking (Enhanced)
CREATE TABLE IF NOT EXISTS ai_model_performance (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    agent_type VARCHAR(100) REFERENCES ai_agent_configs(agent_type),
    model_name VARCHAR(255) NOT NULL,
    endpoint_name VARCHAR(255),
    request_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    error_count INTEGER DEFAULT 0,
    timeout_count INTEGER DEFAULT 0,
    avg_response_time DECIMAL(8,2), -- milliseconds
    min_response_time DECIMAL(8,2),
    max_response_time DECIMAL(8,2),
    total_tokens_processed BIGINT DEFAULT 0,
    avg_tokens_per_request DECIMAL(8,2),
    cost_usd DECIMAL(10,4) DEFAULT 0.00,
    accessibility_score DECIMAL(3,2),
    deaf_satisfaction_rating DECIMAL(3,2),
    error_types JSONB DEFAULT '{}',
    performance_metrics JSONB DEFAULT '{}',
    date DATE NOT NULL,
    hour INTEGER NOT NULL CHECK (hour >= 0 AND hour <= 23),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(agent_type, model_name, date, hour)
);

-- AI Request Logs (Detailed)
CREATE TABLE IF NOT EXISTS ai_request_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    agent_type VARCHAR(100) REFERENCES ai_agent_configs(agent_type),
    model_name VARCHAR(255) NOT NULL,
    request_payload JSONB NOT NULL,
    response_payload JSONB,
    system_instruction TEXT,
    prompt_text TEXT,
    response_text TEXT,
    success BOOLEAN DEFAULT FALSE,
    error_message TEXT,
    error_code VARCHAR(50),
    processing_time INTEGER, -- milliseconds
    tokens_used INTEGER DEFAULT 0,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    cost_usd DECIMAL(8,4) DEFAULT 0.00,
    accessibility_score DECIMAL(3,2),
    deaf_optimized BOOLEAN DEFAULT TRUE,
    user_satisfaction INTEGER CHECK (user_satisfaction >= 1 AND user_satisfaction <= 5),
    feedback_text TEXT,
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    request_id VARCHAR(255) UNIQUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AI Agent Usage Analytics
CREATE TABLE IF NOT EXISTS ai_agent_analytics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    agent_type VARCHAR(100) REFERENCES ai_agent_configs(agent_type),
    user_segment VARCHAR(100), -- 'deaf', 'hard-of-hearing', 'deafblind', 'coda', 'hearing'
    usage_count INTEGER DEFAULT 0,
    success_rate DECIMAL(5,4),
    avg_satisfaction DECIMAL(3,2),
    avg_accessibility_score DECIMAL(3,2),
    common_use_cases JSONB DEFAULT '[]',
    improvement_suggestions JSONB DEFAULT '[]',
    date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(agent_type, user_segment, date)
);

-- Vertex AI Model Registry
CREATE TABLE IF NOT EXISTS vertex_ai_models (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    model_name VARCHAR(255) UNIQUE NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    description TEXT,
    model_version VARCHAR(100),
    endpoint_id VARCHAR(255),
    endpoint_url TEXT,
    region VARCHAR(100) DEFAULT 'us-central1',
    model_type VARCHAR(100), -- 'text-generation', 'embedding', 'classification'
    capabilities JSONB DEFAULT '[]',
    pricing_info JSONB DEFAULT '{}',
    performance_benchmarks JSONB DEFAULT '{}',
    accessibility_features JSONB DEFAULT '{}',
    deaf_optimization_level VARCHAR(50) DEFAULT 'high',
    is_active BOOLEAN DEFAULT TRUE,
    deployment_date TIMESTAMPTZ,
    last_updated TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert Vertex AI model configurations
INSERT INTO vertex_ai_models (model_name, display_name, description, model_type, capabilities, accessibility_features) VALUES
('gemini-1.5-pro', 'Gemini 1.5 Pro', 'Advanced multimodal AI model for complex reasoning', 'text-generation', 
 '["text_generation", "code_generation", "reasoning", "multimodal"]',
 '{"visual_description": true, "plain_language": true, "structured_output": true}'),

('gemini-1.5-flash', 'Gemini 1.5 Flash', 'Fast and efficient model for quick responses', 'text-generation',
 '["text_generation", "fast_response", "lightweight"]',
 '{"quick_response": true, "simple_language": true}'),

('text-embedding-004', 'Text Embedding 004', 'High-quality text embeddings for semantic search', 'embedding',
 '["text_embedding", "semantic_search", "similarity"]',
 '{"semantic_accessibility": true, "context_understanding": true}');

-- AI Training Data and Fine-tuning
CREATE TABLE IF NOT EXISTS ai_training_data (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    agent_type VARCHAR(100) REFERENCES ai_agent_configs(agent_type),
    data_type VARCHAR(100), -- 'conversation', 'feedback', 'correction', 'example'
    input_text TEXT NOT NULL,
    expected_output TEXT,
    actual_output TEXT,
    quality_score DECIMAL(3,2),
    accessibility_rating DECIMAL(3,2),
    deaf_community_approved BOOLEAN DEFAULT FALSE,
    reviewer_id UUID REFERENCES auth.users(id),
    review_notes TEXT,
    tags JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- AI Safety and Compliance Monitoring
CREATE TABLE IF NOT EXISTS ai_safety_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    request_id VARCHAR(255) REFERENCES ai_request_logs(request_id),
    agent_type VARCHAR(100) REFERENCES ai_agent_configs(agent_type),
    safety_check_type VARCHAR(100), -- 'content_filter', 'bias_detection', 'accessibility_check'
    check_result VARCHAR(50), -- 'pass', 'warning', 'fail'
    confidence_score DECIMAL(3,2),
    details JSONB DEFAULT '{}',
    flagged_content TEXT,
    mitigation_action VARCHAR(255),
    reviewer_id UUID REFERENCES auth.users(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for Performance
CREATE INDEX IF NOT EXISTS idx_ai_agent_configs_agent_type ON ai_agent_configs(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_agent_configs_is_active ON ai_agent_configs(is_active);

CREATE INDEX IF NOT EXISTS idx_ai_model_performance_agent_type ON ai_model_performance(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_model_performance_date_hour ON ai_model_performance(date, hour);
CREATE INDEX IF NOT EXISTS idx_ai_model_performance_model_name ON ai_model_performance(model_name);

CREATE INDEX IF NOT EXISTS idx_ai_request_logs_user_id ON ai_request_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_request_logs_agent_type ON ai_request_logs(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_request_logs_created_at ON ai_request_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_ai_request_logs_success ON ai_request_logs(success);
CREATE INDEX IF NOT EXISTS idx_ai_request_logs_request_id ON ai_request_logs(request_id);

CREATE INDEX IF NOT EXISTS idx_ai_agent_analytics_agent_type ON ai_agent_analytics(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_agent_analytics_date ON ai_agent_analytics(date);
CREATE INDEX IF NOT EXISTS idx_ai_agent_analytics_user_segment ON ai_agent_analytics(user_segment);

CREATE INDEX IF NOT EXISTS idx_vertex_ai_models_model_name ON vertex_ai_models(model_name);
CREATE INDEX IF NOT EXISTS idx_vertex_ai_models_is_active ON vertex_ai_models(is_active);
CREATE INDEX IF NOT EXISTS idx_vertex_ai_models_model_type ON vertex_ai_models(model_type);

CREATE INDEX IF NOT EXISTS idx_ai_training_data_agent_type ON ai_training_data(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_training_data_data_type ON ai_training_data(data_type);
CREATE INDEX IF NOT EXISTS idx_ai_training_data_is_active ON ai_training_data(is_active);

CREATE INDEX IF NOT EXISTS idx_ai_safety_logs_request_id ON ai_safety_logs(request_id);
CREATE INDEX IF NOT EXISTS idx_ai_safety_logs_agent_type ON ai_safety_logs(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_safety_logs_check_result ON ai_safety_logs(check_result);

-- Row Level Security
ALTER TABLE ai_request_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_training_data ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own AI requests" ON ai_request_logs
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own AI requests" ON ai_request_logs
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Functions for AI Analytics
CREATE OR REPLACE FUNCTION calculate_agent_performance(
    p_agent_type VARCHAR(100),
    p_start_date DATE DEFAULT CURRENT_DATE - INTERVAL '7 days',
    p_end_date DATE DEFAULT CURRENT_DATE
) RETURNS TABLE (
    agent_type VARCHAR(100),
    total_requests BIGINT,
    success_rate DECIMAL(5,4),
    avg_response_time DECIMAL(8,2),
    avg_accessibility_score DECIMAL(3,2),
    avg_satisfaction DECIMAL(3,2),
    total_cost DECIMAL(10,4)
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        arl.agent_type,
        COUNT(*)::BIGINT as total_requests,
        (COUNT(*) FILTER (WHERE arl.success = true)::DECIMAL / COUNT(*))::DECIMAL(5,4) as success_rate,
        AVG(arl.processing_time)::DECIMAL(8,2) as avg_response_time,
        AVG(arl.accessibility_score)::DECIMAL(3,2) as avg_accessibility_score,
        AVG(arl.user_satisfaction)::DECIMAL(3,2) as avg_satisfaction,
        SUM(arl.cost_usd)::DECIMAL(10,4) as total_cost
    FROM ai_request_logs arl
    WHERE arl.agent_type = p_agent_type
    AND DATE(arl.created_at) BETWEEN p_start_date AND p_end_date
    GROUP BY arl.agent_type;
END;
$$ LANGUAGE plpgsql;

-- Function to get top performing agents
CREATE OR REPLACE FUNCTION get_top_performing_agents(
    p_limit INTEGER DEFAULT 10,
    p_days INTEGER DEFAULT 7
) RETURNS TABLE (
    agent_type VARCHAR(100),
    display_name VARCHAR(255),
    total_requests BIGINT,
    success_rate DECIMAL(5,4),
    avg_accessibility_score DECIMAL(3,2),
    deaf_satisfaction DECIMAL(3,2)
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        arl.agent_type,
        ac.display_name,
        COUNT(*)::BIGINT as total_requests,
        (COUNT(*) FILTER (WHERE arl.success = true)::DECIMAL / COUNT(*))::DECIMAL(5,4) as success_rate,
        AVG(arl.accessibility_score)::DECIMAL(3,2) as avg_accessibility_score,
        AVG(arl.user_satisfaction)::DECIMAL(3,2) as deaf_satisfaction
    FROM ai_request_logs arl
    JOIN ai_agent_configs ac ON arl.agent_type = ac.agent_type
    WHERE arl.created_at >= NOW() - INTERVAL '1 day' * p_days
    GROUP BY arl.agent_type, ac.display_name
    ORDER BY success_rate DESC, avg_accessibility_score DESC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- Function to update AI performance metrics (enhanced)
CREATE OR REPLACE FUNCTION update_vertex_ai_metrics(
    p_model_name VARCHAR(255),
    p_agent_type VARCHAR(100),
    p_success BOOLEAN,
    p_response_time INTEGER,
    p_tokens_processed INTEGER DEFAULT 0
) RETURNS VOID AS $$
DECLARE
    current_date DATE := CURRENT_DATE;
    current_hour INTEGER := EXTRACT(HOUR FROM NOW());
    estimated_cost DECIMAL(8,4);
BEGIN
    -- Calculate estimated cost (simplified pricing model)
    estimated_cost := (p_tokens_processed::DECIMAL / 1000) * 0.002; -- $0.002 per 1K tokens
    
    INSERT INTO ai_model_performance (
        agent_type,
        model_name,
        date,
        hour,
        request_count,
        success_count,
        error_count,
        avg_response_time,
        min_response_time,
        max_response_time,
        total_tokens_processed,
        cost_usd
    ) VALUES (
        p_agent_type,
        p_model_name,
        current_date,
        current_hour,
        1,
        CASE WHEN p_success THEN 1 ELSE 0 END,
        CASE WHEN p_success THEN 0 ELSE 1 END,
        p_response_time,
        p_response_time,
        p_response_time,
        p_tokens_processed,
        estimated_cost
    )
    ON CONFLICT (agent_type, model_name, date, hour) DO UPDATE SET
        request_count = ai_model_performance.request_count + 1,
        success_count = ai_model_performance.success_count + 
            CASE WHEN p_success THEN 1 ELSE 0 END,
        error_count = ai_model_performance.error_count + 
            CASE WHEN p_success THEN 0 ELSE 1 END,
        avg_response_time = (
            (ai_model_performance.avg_response_time * ai_model_performance.request_count + p_response_time) /
            (ai_model_performance.request_count + 1)
        ),
        min_response_time = LEAST(ai_model_performance.min_response_time, p_response_time),
        max_response_time = GREATEST(ai_model_performance.max_response_time, p_response_time),
        total_tokens_processed = ai_model_performance.total_tokens_processed + p_tokens_processed,
        cost_usd = ai_model_performance.cost_usd + estimated_cost,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- Automated cleanup for AI logs
CREATE OR REPLACE FUNCTION cleanup_ai_logs() RETURNS VOID AS $$
BEGIN
    -- Clean up old request logs (keep successful ones longer)
    DELETE FROM ai_request_logs 
    WHERE created_at < NOW() - INTERVAL '90 days' AND success = false;
    
    DELETE FROM ai_request_logs 
    WHERE created_at < NOW() - INTERVAL '365 days';
    
    -- Clean up old performance metrics
    DELETE FROM ai_model_performance 
    WHERE date < CURRENT_DATE - INTERVAL '365 days';
    
    -- Clean up old safety logs
    DELETE FROM ai_safety_logs 
    WHERE created_at < NOW() - INTERVAL '180 days';
END;
$$ LANGUAGE plpgsql;

-- Comments for documentation
COMMENT ON TABLE ai_agent_configs IS 'Configuration for all AI agents with deaf-first optimization';
COMMENT ON TABLE ai_model_performance IS 'Performance metrics for Vertex AI models by agent type';
COMMENT ON TABLE ai_request_logs IS 'Detailed logs of all AI requests and responses';
COMMENT ON TABLE ai_agent_analytics IS 'Analytics data for AI agent usage patterns';
COMMENT ON TABLE vertex_ai_models IS 'Registry of available Vertex AI models';
COMMENT ON TABLE ai_training_data IS 'Training data for fine-tuning AI models';
COMMENT ON TABLE ai_safety_logs IS 'Safety and compliance monitoring for AI responses';
