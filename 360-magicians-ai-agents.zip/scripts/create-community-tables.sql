-- Community Forum Tables for Deaf-First Developer Platform
-- Supporting ASL video posts, mentorship, and collaborative projects

-- Users table with deaf-first accessibility preferences
CREATE TABLE community_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  clerk_user_id VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(50) UNIQUE NOT NULL,
  display_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL,
  avatar_url TEXT,
  bio TEXT,
  location VARCHAR(100),
  
  -- Deaf-first profile fields
  is_deaf BOOLEAN DEFAULT false,
  asl_proficiency VARCHAR(20) CHECK (asl_proficiency IN ('beginner', 'intermediate', 'advanced', 'native', 'none')),
  preferred_communication VARCHAR(20) DEFAULT 'visual' CHECK (preferred_communication IN ('visual', 'tactile', 'mixed', 'audio')),
  accessibility_needs JSONB DEFAULT '[]',
  
  -- Developer profile
  github_username VARCHAR(100),
  linkedin_url TEXT,
  website_url TEXT,
  skills JSONB DEFAULT '[]',
  experience_level VARCHAR(20) CHECK (experience_level IN ('beginner', 'intermediate', 'advanced', 'expert')),
  
  -- Community status
  community_role VARCHAR(20) DEFAULT 'member' CHECK (community_role IN ('member', 'mentor', 'moderator', 'admin')),
  reputation_score INTEGER DEFAULT 0,
  is_verified BOOLEAN DEFAULT false,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Forum posts with ASL video support
CREATE TABLE forum_posts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  content TEXT,
  
  -- ASL video support
  has_asl_video BOOLEAN DEFAULT false,
  video_url TEXT,
  video_duration INTEGER, -- in seconds
  video_thumbnail_url TEXT,
  captions_url TEXT,
  asl_description TEXT,
  
  -- Post metadata
  category VARCHAR(50) DEFAULT 'general',
  tags JSONB DEFAULT '[]',
  is_pinned BOOLEAN DEFAULT false,
  is_locked BOOLEAN DEFAULT false,
  
  -- Engagement metrics
  view_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  reply_count INTEGER DEFAULT 0,
  
  -- Accessibility features
  has_captions BOOLEAN DEFAULT false,
  has_transcript BOOLEAN DEFAULT false,
  accessibility_score INTEGER DEFAULT 0,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Post replies with ASL video support
CREATE TABLE forum_replies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
  author_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  parent_reply_id UUID REFERENCES forum_replies(id) ON DELETE CASCADE,
  
  content TEXT,
  
  -- ASL video support
  has_asl_video BOOLEAN DEFAULT false,
  video_url TEXT,
  video_duration INTEGER,
  captions_url TEXT,
  
  -- Engagement
  like_count INTEGER DEFAULT 0,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Mentorship system
CREATE TABLE mentorship_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  -- Mentor details
  is_mentor BOOLEAN DEFAULT false,
  is_seeking_mentor BOOLEAN DEFAULT false,
  expertise_areas JSONB DEFAULT '[]',
  availability_status VARCHAR(20) DEFAULT 'available' CHECK (availability_status IN ('available', 'busy', 'unavailable')),
  
  -- Session details
  session_rate DECIMAL(10,2), -- per hour
  max_sessions_per_week INTEGER DEFAULT 5,
  preferred_session_length INTEGER DEFAULT 60, -- minutes
  
  -- Ratings and reviews
  average_rating DECIMAL(3,2) DEFAULT 0.0,
  total_sessions INTEGER DEFAULT 0,
  total_reviews INTEGER DEFAULT 0,
  
  -- ASL mentorship specific
  provides_asl_mentorship BOOLEAN DEFAULT false,
  asl_teaching_experience INTEGER DEFAULT 0, -- years
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Mentorship sessions
CREATE TABLE mentorship_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mentor_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  mentee_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  session_date TIMESTAMP WITH TIME ZONE NOT NULL,
  duration_minutes INTEGER NOT NULL,
  status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'no_show')),
  
  -- Session details
  topic VARCHAR(255),
  notes TEXT,
  
  -- ASL session support
  requires_asl_interpretation BOOLEAN DEFAULT false,
  interpreter_assigned BOOLEAN DEFAULT false,
  session_recording_url TEXT,
  
  -- Feedback
  mentor_rating INTEGER CHECK (mentor_rating >= 1 AND mentor_rating <= 5),
  mentee_rating INTEGER CHECK (mentee_rating >= 1 AND mentee_rating <= 5),
  mentor_feedback TEXT,
  mentee_feedback TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Collaborative projects
CREATE TABLE collaborative_projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  long_description TEXT,
  
  -- Project details
  tech_stack JSONB DEFAULT '[]',
  project_type VARCHAR(50) DEFAULT 'open_source',
  difficulty_level VARCHAR(20) CHECK (difficulty_level IN ('beginner', 'intermediate', 'advanced')),
  estimated_duration VARCHAR(50),
  
  -- Repository and links
  github_url TEXT,
  demo_url TEXT,
  documentation_url TEXT,
  
  -- Project status
  status VARCHAR(20) DEFAULT 'planning' CHECK (status IN ('planning', 'active', 'completed', 'paused', 'cancelled')),
  progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
  
  -- Team and recruitment
  max_contributors INTEGER DEFAULT 10,
  current_contributors INTEGER DEFAULT 1,
  seeking_roles JSONB DEFAULT '[]',
  
  -- Accessibility focus
  is_accessibility_focused BOOLEAN DEFAULT true,
  deaf_community_impact TEXT,
  accessibility_features JSONB DEFAULT '[]',
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Project contributors
CREATE TABLE project_contributors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES collaborative_projects(id) ON DELETE CASCADE,
  user_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  role VARCHAR(100) NOT NULL,
  contribution_type VARCHAR(50) DEFAULT 'developer',
  is_lead BOOLEAN DEFAULT false,
  
  -- Contribution tracking
  commits_count INTEGER DEFAULT 0,
  issues_resolved INTEGER DEFAULT 0,
  reviews_completed INTEGER DEFAULT 0,
  
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(project_id, user_id)
);

-- Community events with ASL support
CREATE TABLE community_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  event_type VARCHAR(50) DEFAULT 'workshop' CHECK (event_type IN ('workshop', 'tutorial', 'networking', 'technical', 'social')),
  
  -- Event scheduling
  start_time TIMESTAMP WITH TIME ZONE NOT NULL,
  end_time TIMESTAMP WITH TIME ZONE NOT NULL,
  timezone VARCHAR(50) DEFAULT 'UTC',
  
  -- Event details
  max_attendees INTEGER,
  current_attendees INTEGER DEFAULT 0,
  is_free BOOLEAN DEFAULT true,
  price DECIMAL(10,2) DEFAULT 0.00,
  
  -- Accessibility features
  has_asl_interpretation BOOLEAN DEFAULT true,
  has_live_captions BOOLEAN DEFAULT true,
  has_recording BOOLEAN DEFAULT true,
  accessibility_notes TEXT,
  
  -- Event links
  meeting_url TEXT,
  recording_url TEXT,
  materials_url TEXT,
  
  -- Event status
  status VARCHAR(20) DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'live', 'completed', 'cancelled')),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Event attendees
CREATE TABLE event_attendees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_id UUID REFERENCES community_events(id) ON DELETE CASCADE,
  user_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  registration_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  attendance_status VARCHAR(20) DEFAULT 'registered' CHECK (attendance_status IN ('registered', 'attended', 'no_show', 'cancelled')),
  
  -- Accessibility requests
  needs_asl_interpretation BOOLEAN DEFAULT false,
  needs_captions BOOLEAN DEFAULT false,
  accessibility_requests TEXT,
  
  -- Feedback
  event_rating INTEGER CHECK (event_rating >= 1 AND event_rating <= 5),
  feedback TEXT,
  
  UNIQUE(event_id, user_id)
);

-- Post likes/reactions
CREATE TABLE post_reactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  post_id UUID REFERENCES forum_posts(id) ON DELETE CASCADE,
  reaction_type VARCHAR(20) DEFAULT 'like' CHECK (reaction_type IN ('like', 'love', 'helpful', 'insightful')),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, post_id, reaction_type)
);

-- Reply likes/reactions
CREATE TABLE reply_reactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  reply_id UUID REFERENCES forum_replies(id) ON DELETE CASCADE,
  reaction_type VARCHAR(20) DEFAULT 'like' CHECK (reaction_type IN ('like', 'love', 'helpful', 'insightful')),
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  UNIQUE(user_id, reply_id, reaction_type)
);

-- Accessibility logs for community interactions
CREATE TABLE community_accessibility_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES community_users(id) ON DELETE CASCADE,
  
  action VARCHAR(100) NOT NULL,
  resource_type VARCHAR(50) NOT NULL, -- 'post', 'reply', 'event', 'session'
  resource_id UUID NOT NULL,
  
  accessibility_features_used JSONB DEFAULT '[]',
  interaction_method VARCHAR(50), -- 'asl_video', 'text', 'captions', 'screen_reader'
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_forum_posts_author_id ON forum_posts(author_id);
CREATE INDEX idx_forum_posts_created_at ON forum_posts(created_at DESC);
CREATE INDEX idx_forum_posts_category ON forum_posts(category);
CREATE INDEX idx_forum_posts_tags ON forum_posts USING GIN(tags);

CREATE INDEX idx_forum_replies_post_id ON forum_replies(post_id);
CREATE INDEX idx_forum_replies_author_id ON forum_replies(author_id);

CREATE INDEX idx_mentorship_profiles_is_mentor ON mentorship_profiles(is_mentor);
CREATE INDEX idx_mentorship_profiles_availability ON mentorship_profiles(availability_status);

CREATE INDEX idx_collaborative_projects_status ON collaborative_projects(status);
CREATE INDEX idx_collaborative_projects_tech_stack ON collaborative_projects USING GIN(tech_stack);

CREATE INDEX idx_community_events_start_time ON community_events(start_time);
CREATE INDEX idx_community_events_event_type ON community_events(event_type);

-- Functions for updating counters
CREATE OR REPLACE FUNCTION update_post_reply_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum_posts 
    SET reply_count = reply_count + 1 
    WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum_posts 
    SET reply_count = reply_count - 1 
    WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_post_reply_count
  AFTER INSERT OR DELETE ON forum_replies
  FOR EACH ROW EXECUTE FUNCTION update_post_reply_count();

-- Function for updating like counts
CREATE OR REPLACE FUNCTION update_post_like_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE forum_posts 
    SET like_count = like_count + 1 
    WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE forum_posts 
    SET like_count = like_count - 1 
    WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_post_like_count
  AFTER INSERT OR DELETE ON post_reactions
  FOR EACH ROW EXECUTE FUNCTION update_post_like_count();
