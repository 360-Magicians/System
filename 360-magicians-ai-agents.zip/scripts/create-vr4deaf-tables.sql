-- VR4Deaf Vendor Partnership Database Schema
-- Vocational Rehabilitation Services for Deaf Community

-- Vendors table
CREATE TABLE IF NOT EXISTS vr_vendors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_name VARCHAR(255) NOT NULL,
    specializations TEXT[] NOT NULL,
    deaf_services JSONB NOT NULL DEFAULT '{}',
    asl_capability BOOLEAN NOT NULL DEFAULT false,
    location VARCHAR(100) NOT NULL,
    certification_level VARCHAR(50) NOT NULL,
    contact_info JSONB NOT NULL DEFAULT '{}',
    accessibility_rating DECIMAL(3,2) NOT NULL DEFAULT 0.0,
    active_clients INTEGER DEFAULT 0,
    success_rate DECIMAL(5,2) DEFAULT 0.0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Clients table
CREATE TABLE IF NOT EXISTS vr_clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_name VARCHAR(255) NOT NULL,
    rehabilitation_needs TEXT[] NOT NULL,
    requires_asl BOOLEAN NOT NULL DEFAULT false,
    location_preference VARCHAR(100),
    accommodation_requirements JSONB DEFAULT '{}',
    communication_preferences JSONB DEFAULT '{}',
    assigned_vendor_id UUID REFERENCES vr_vendors(id),
    status VARCHAR(50) DEFAULT 'active',
    start_date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Rehabilitation progress tracking
CREATE TABLE IF NOT EXISTS rehab_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES vr_clients(id),
    vendor_id UUID NOT NULL REFERENCES vr_vendors(id),
    progress_metrics JSONB NOT NULL DEFAULT '{}',
    accessibility_accommodations JSONB DEFAULT '{}',
    asl_interpreter_hours INTEGER DEFAULT 0,
    milestone_achieved VARCHAR(255),
    next_goals TEXT[],
    completion_percentage INTEGER DEFAULT 0,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    next_review_date DATE
);

-- Vendor certifications and qualifications
CREATE TABLE IF NOT EXISTS vendor_certifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id UUID NOT NULL REFERENCES vr_vendors(id),
    certification_type VARCHAR(100) NOT NULL,
    certification_body VARCHAR(255) NOT NULL,
    issue_date DATE NOT NULL,
    expiry_date DATE,
    asl_proficiency_level VARCHAR(50),
    deaf_cultural_competency_score INTEGER,
    accessibility_audit_score DECIMAL(3,2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Client-vendor matching history
CREATE TABLE IF NOT EXISTS client_vendor_matches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES vr_clients(id),
    vendor_id UUID NOT NULL REFERENCES vr_vendors(id),
    match_score INTEGER NOT NULL,
    matching_criteria JSONB NOT NULL DEFAULT '{}',
    match_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    outcome VARCHAR(50),
    feedback JSONB DEFAULT '{}'
);

-- Outcome reports and success metrics
CREATE TABLE IF NOT EXISTS outcome_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES vr_clients(id),
    vendor_id UUID NOT NULL REFERENCES vr_vendors(id),
    program_duration_months INTEGER,
    employment_placement BOOLEAN DEFAULT false,
    job_title VARCHAR(255),
    employer_name VARCHAR(255),
    salary_range VARCHAR(50),
    accommodation_success_rate DECIMAL(5,2),
    client_satisfaction_score INTEGER,
    employer_satisfaction_score INTEGER,
    follow_up_support_needed BOOLEAN DEFAULT false,
    report_generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_vr_vendors_location ON vr_vendors(location);
CREATE INDEX IF NOT EXISTS idx_vr_vendors_asl_capability ON vr_vendors(asl_capability);
CREATE INDEX IF NOT EXISTS idx_vr_vendors_accessibility_rating ON vr_vendors(accessibility_rating);
CREATE INDEX IF NOT EXISTS idx_vr_clients_requires_asl ON vr_clients(requires_asl);
CREATE INDEX IF NOT EXISTS idx_vr_clients_status ON vr_clients(status);
CREATE INDEX IF NOT EXISTS idx_rehab_progress_client_id ON rehab_progress(client_id);
CREATE INDEX IF NOT EXISTS idx_rehab_progress_vendor_id ON rehab_progress(vendor_id);

-- Insert sample data
INSERT INTO vr_vendors (vendor_name, specializations, deaf_services, asl_capability, location, certification_level, contact_info, accessibility_rating) VALUES
('Deaf Vocational Services Inc.', ARRAY['Job Training', 'ASL Interpretation', 'Workplace Accommodation'], '{"asl_interpreters": true, "deaf_counselors": true, "visual_communication": true}', true, 'California', 'Premium', '{"phone": "555-0101", "email": "info@deafvocational.com", "address": "123 Accessibility Ave, San Francisco, CA"}', 4.9),
('Accessible Career Solutions', ARRAY['Career Counseling', 'Skills Assessment', 'Technology Training'], '{"assistive_technology": true, "visual_learning": true, "deaf_mentors": true}', true, 'New York', 'Standard', '{"phone": "555-0102", "email": "contact@accessiblecareers.com", "address": "456 Inclusion St, New York, NY"}', 4.7),
('Inclusive Workforce Partners', ARRAY['Employer Relations', 'Job Placement', 'Follow-up Support'], '{"employer_training": true, "accommodation_consulting": true, "deaf_advocacy": true}', true, 'Texas', 'Premium', '{"phone": "555-0103", "email": "hello@inclusiveworkforce.com", "address": "789 Opportunity Blvd, Austin, TX"}', 4.8);

INSERT INTO vr_clients (client_name, rehabilitation_needs, requires_asl, location_preference, accommodation_requirements, start_date) VALUES
('Sarah M.', ARRAY['Job Training', 'ASL Support'], true, 'California', '{"interpreter": true, "visual_alerts": true, "flexible_schedule": true}', '2024-01-15'),
('Michael R.', ARRAY['Career Counseling', 'Technology Training'], true, 'New York', '{"assistive_technology": true, "written_communication": true}', '2024-02-01'),
('Jennifer L.', ARRAY['Job Placement', 'Workplace Accommodation'], false, 'Texas', '{"hearing_aids": true, "quiet_workspace": true}', '2023-11-20');
