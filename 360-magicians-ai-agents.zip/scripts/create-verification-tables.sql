-- Create agent health check tracking table
CREATE TABLE IF NOT EXISTS agent_health_checks (
    id SERIAL PRIMARY KEY,
    check_timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    total_agents INTEGER NOT NULL,
    operational_agents INTEGER NOT NULL,
    health_percentage DECIMAL(5,2) NOT NULL,
    average_response_time INTEGER NOT NULL,
    average_accessibility_score DECIMAL(3,2) NOT NULL,
    deaf_first_compliance INTEGER NOT NULL,
    asl_compatibility INTEGER NOT NULL,
    detailed_results JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create accessibility compliance tracking table
CREATE TABLE IF NOT EXISTS accessibility_compliance (
    id SERIAL PRIMARY KEY,
    service_name VARCHAR(100) NOT NULL,
    compliance_score DECIMAL(3,2) NOT NULL,
    wcag_aa_compliant BOOLEAN NOT NULL DEFAULT FALSE,
    deaf_accessible BOOLEAN NOT NULL DEFAULT FALSE,
    asl_supported BOOLEAN NOT NULL DEFAULT FALSE,
    visual_first_design BOOLEAN NOT NULL DEFAULT FALSE,
    screen_reader_optimized BOOLEAN NOT NULL DEFAULT FALSE,
    high_contrast_available BOOLEAN NOT NULL DEFAULT FALSE,
    no_audio_dependencies BOOLEAN NOT NULL DEFAULT FALSE,
    cultural_competency_score DECIMAL(3,2),
    tested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create deaf community feedback table
CREATE TABLE IF NOT EXISTS deaf_community_feedback (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id),
    agent_type VARCHAR(50) NOT NULL,
    satisfaction_score INTEGER CHECK (satisfaction_score >= 1 AND satisfaction_score <= 5),
    accessibility_rating INTEGER CHECK (accessibility_rating >= 1 AND accessibility_rating <= 5),
    asl_quality_rating INTEGER CHECK (asl_quality_rating >= 1 AND asl_quality_rating <= 5),
    visual_design_rating INTEGER CHECK (visual_design_rating >= 1 AND visual_design_rating <= 5),
    cultural_sensitivity_rating INTEGER CHECK (cultural_sensitivity_rating >= 1 AND cultural_sensitivity_rating <= 5),
    user_segment VARCHAR(50), -- 'deaf', 'hard_of_hearing', 'hearing', 'interpreter', etc.
    feedback_text TEXT,
    improvement_suggestions TEXT,
    would_recommend BOOLEAN,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create AI agent performance metrics table
CREATE TABLE IF NOT EXISTS ai_agent_metrics (
    id SERIAL PRIMARY KEY,
    agent_type VARCHAR(50) NOT NULL,
    model_name VARCHAR(100) NOT NULL,
    request_count INTEGER NOT NULL DEFAULT 0,
    success_count INTEGER NOT NULL DEFAULT 0,
    error_count INTEGER NOT NULL DEFAULT 0,
    total_response_time BIGINT NOT NULL DEFAULT 0,
    total_tokens_processed BIGINT NOT NULL DEFAULT 0,
    accessibility_score_sum DECIMAL(10,2) NOT NULL DEFAULT 0,
    deaf_first_requests INTEGER NOT NULL DEFAULT 0,
    asl_compatible_responses INTEGER NOT NULL DEFAULT 0,
    visual_first_responses INTEGER NOT NULL DEFAULT 0,
    date_recorded DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(agent_type, model_name, date_recorded)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_agent_health_checks_timestamp ON agent_health_checks(check_timestamp);
CREATE INDEX IF NOT EXISTS idx_accessibility_compliance_service ON accessibility_compliance(service_name);
CREATE INDEX IF NOT EXISTS idx_accessibility_compliance_tested_at ON accessibility_compliance(tested_at);
CREATE INDEX IF NOT EXISTS idx_deaf_feedback_agent_type ON deaf_community_feedback(agent_type);
CREATE INDEX IF NOT EXISTS idx_deaf_feedback_user_segment ON deaf_community_feedback(user_segment);
CREATE INDEX IF NOT EXISTS idx_deaf_feedback_created_at ON deaf_community_feedback(created_at);
CREATE INDEX IF NOT EXISTS idx_ai_metrics_agent_type ON ai_agent_metrics(agent_type);
CREATE INDEX IF NOT EXISTS idx_ai_metrics_date ON ai_agent_metrics(date_recorded);

-- Create function to update AI agent metrics
CREATE OR REPLACE FUNCTION update_vertex_ai_metrics(
    p_model_name TEXT,
    p_agent_type TEXT,
    p_success BOOLEAN,
    p_response_time INTEGER,
    p_tokens_processed INTEGER,
    p_accessibility_score DECIMAL DEFAULT 0.0,
    p_deaf_first BOOLEAN DEFAULT FALSE,
    p_asl_compatible BOOLEAN DEFAULT FALSE,
    p_visual_first BOOLEAN DEFAULT FALSE
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO ai_agent_metrics (
        agent_type,
        model_name,
        request_count,
        success_count,
        error_count,
        total_response_time,
        total_tokens_processed,
        accessibility_score_sum,
        deaf_first_requests,
        asl_compatible_responses,
        visual_first_responses,
        date_recorded
    )
    VALUES (
        p_agent_type,
        p_model_name,
        1,
        CASE WHEN p_success THEN 1 ELSE 0 END,
        CASE WHEN p_success THEN 0 ELSE 1 END,
        p_response_time,
        p_tokens_processed,
        p_accessibility_score,
        CASE WHEN p_deaf_first THEN 1 ELSE 0 END,
        CASE WHEN p_asl_compatible THEN 1 ELSE 0 END,
        CASE WHEN p_visual_first THEN 1 ELSE 0 END,
        CURRENT_DATE
    )
    ON CONFLICT (agent_type, model_name, date_recorded)
    DO UPDATE SET
        request_count = ai_agent_metrics.request_count + 1,
        success_count = ai_agent_metrics.success_count + CASE WHEN p_success THEN 1 ELSE 0 END,
        error_count = ai_agent_metrics.error_count + CASE WHEN p_success THEN 0 ELSE 1 END,
        total_response_time = ai_agent_metrics.total_response_time + p_response_time,
        total_tokens_processed = ai_agent_metrics.total_tokens_processed + p_tokens_processed,
        accessibility_score_sum = ai_agent_metrics.accessibility_score_sum + p_accessibility_score,
        deaf_first_requests = ai_agent_metrics.deaf_first_requests + CASE WHEN p_deaf_first THEN 1 ELSE 0 END,
        asl_compatible_responses = ai_agent_metrics.asl_compatible_responses + CASE WHEN p_asl_compatible THEN 1 ELSE 0 END,
        visual_first_responses = ai_agent_metrics.visual_first_responses + CASE WHEN p_visual_first THEN 1 ELSE 0 END,
        updated_at = NOW();
END;
$$ LANGUAGE plpgsql;

-- Create function to get top performing agents
CREATE OR REPLACE FUNCTION get_top_performing_agents(p_limit INTEGER DEFAULT 12, p_days INTEGER DEFAULT 7)
RETURNS TABLE (
    agent_type TEXT,
    success_rate DECIMAL,
    avg_response_time DECIMAL,
    avg_accessibility_score DECIMAL,
    total_requests INTEGER,
    deaf_first_percentage DECIMAL,
    asl_compatibility_percentage DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.agent_type,
        CASE 
            WHEN m.request_count > 0 THEN ROUND((m.success_count::DECIMAL / m.request_count::DECIMAL) * 100, 2)
            ELSE 0.0
        END as success_rate,
        CASE 
            WHEN m.success_count > 0 THEN ROUND(m.total_response_time::DECIMAL / m.success_count::DECIMAL, 0)
            ELSE 0.0
        END as avg_response_time,
        CASE 
            WHEN m.request_count > 0 THEN ROUND(m.accessibility_score_sum / m.request_count, 2)
            ELSE 0.0
        END as avg_accessibility_score,
        m.request_count as total_requests,
        CASE 
            WHEN m.request_count > 0 THEN ROUND((m.deaf_first_requests::DECIMAL / m.request_count::DECIMAL) * 100, 2)
            ELSE 0.0
        END as deaf_first_percentage,
        CASE 
            WHEN m.request_count > 0 THEN ROUND((m.asl_compatible_responses::DECIMAL / m.request_count::DECIMAL) * 100, 2)
            ELSE 0.0
        END as asl_compatibility_percentage
    FROM (
        SELECT 
            agent_type,
            SUM(request_count) as request_count,
            SUM(success_count) as success_count,
            SUM(error_count) as error_count,
            SUM(total_response_time) as total_response_time,
            SUM(total_tokens_processed) as total_tokens_processed,
            SUM(accessibility_score_sum) as accessibility_score_sum,
            SUM(deaf_first_requests) as deaf_first_requests,
            SUM(asl_compatible_responses) as asl_compatible_responses,
            SUM(visual_first_responses) as visual_first_responses
        FROM ai_agent_metrics 
        WHERE date_recorded >= CURRENT_DATE - INTERVAL '%s days'
        GROUP BY agent_type
    ) m
    ORDER BY success_rate DESC, avg_accessibility_score DESC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- Insert initial accessibility compliance records for all services
INSERT INTO accessibility_compliance (
    service_name,
    compliance_score,
    wcag_aa_compliant,
    deaf_accessible,
    asl_supported,
    visual_first_design,
    screen_reader_optimized,
    high_contrast_available,
    no_audio_dependencies,
    cultural_competency_score,
    notes
) VALUES 
('career-matching-ai', 0.95, true, true, true, true, true, true, true, 0.92, 'Deaf-first career matching with ASL considerations'),
('vr-coordination-ai', 0.94, true, true, true, true, true, true, true, 0.95, 'VR4DEAF integration with cultural competency'),
('document-translation-ai', 0.93, true, true, true, true, true, true, true, 0.90, 'Plain language translation for deaf accessibility'),
('interview-prep-ai', 0.96, true, true, true, true, true, true, true, 0.94, 'Accommodation-focused interview preparation'),
('workplace-accommodation-ai', 0.97, true, true, true, true, true, true, true, 0.96, 'ADA compliance and reasonable accommodations'),
('startup-incubation-ai', 0.91, true, true, true, true, true, true, true, 0.88, 'Deaf entrepreneur support and validation'),
('funding-intelligence-ai', 0.92, true, true, true, true, true, true, true, 0.89, 'Accessibility-focused funding opportunities'),
('growth-planning-ai', 0.90, true, true, true, true, true, true, true, 0.87, 'Scaling deaf-first businesses'),
('workforce-partnership-ai', 0.94, true, true, true, true, true, true, true, 0.93, 'Employer-professional connections'),
('case-management-ai', 0.95, true, true, true, true, true, true, true, 0.94, 'Comprehensive service coordination'),
('progress-analytics-ai', 0.93, true, true, true, true, true, true, true, 0.91, 'Impact measurement and reporting'),
('community-intelligence-ai', 0.96, true, true, true, true, true, true, true, 0.97, 'Deaf community needs analysis')
ON CONFLICT DO NOTHING;
