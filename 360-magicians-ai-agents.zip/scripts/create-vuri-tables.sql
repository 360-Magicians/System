-- VR4Deaf VURI AI Database Schema
-- Created by 360 Magicians for VR4Deaf.org

-- VURI AI Interactions Table
CREATE TABLE IF NOT EXISTS vuri_interactions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    agent_type TEXT NOT NULL,
    message TEXT NOT NULL,
    response TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    platform TEXT DEFAULT 'vr4deaf',
    accessibility_score INTEGER DEFAULT 0,
    vr_optimized BOOLEAN DEFAULT true,
    deaf_first BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- VR Accessibility Audits Table
CREATE TABLE IF NOT EXISTS vr_accessibility_audits (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vr_experience_id TEXT NOT NULL,
    audit_type TEXT NOT NULL, -- 'visual-cues', 'haptic-feedback', 'asl-integration'
    score INTEGER NOT NULL CHECK (score >= 0 AND score <= 100),
    recommendations JSONB,
    deaf_optimized BOOLEAN DEFAULT false,
    wcag_compliant BOOLEAN DEFAULT false,
    audited_by TEXT,
    audit_date TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ASL Avatar Configurations Table
CREATE TABLE IF NOT EXISTS asl_avatar_configs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    avatar_name TEXT NOT NULL,
    asl_dialect TEXT DEFAULT 'ASL', -- ASL, BSL, etc.
    hand_tracking_enabled BOOLEAN DEFAULT true,
    facial_expression_enabled BOOLEAN DEFAULT true,
    cultural_accuracy_score INTEGER DEFAULT 0,
    animation_quality TEXT DEFAULT 'high', -- low, medium, high, ultra
    created_by TEXT,
    vr_platform TEXT, -- oculus, vive, etc.
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Haptic Feedback Patterns Table
CREATE TABLE IF NOT EXISTS haptic_patterns (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    pattern_name TEXT NOT NULL,
    pattern_type TEXT NOT NULL, -- 'spatial', 'emotional', 'environmental'
    vibration_data JSONB NOT NULL,
    intensity_level INTEGER DEFAULT 5 CHECK (intensity_level >= 1 AND intensity_level <= 10),
    duration_ms INTEGER DEFAULT 1000,
    deaf_optimized BOOLEAN DEFAULT true,
    vr_compatible BOOLEAN DEFAULT true,
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- VR Social Spaces Table
CREATE TABLE IF NOT EXISTS vr_social_spaces (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    space_name TEXT NOT NULL,
    max_participants INTEGER DEFAULT 20,
    asl_optimized BOOLEAN DEFAULT true,
    visual_attention_system BOOLEAN DEFAULT true,
    deaf_cultural_features JSONB,
    accessibility_rating INTEGER DEFAULT 0,
    created_by TEXT,
    space_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- VR Training Modules Table
CREATE TABLE IF NOT EXISTS vr_training_modules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    module_name TEXT NOT NULL,
    training_type TEXT NOT NULL, -- 'asl-learning', 'deaf-awareness', 'vr-skills'
    visual_learning_optimized BOOLEAN DEFAULT true,
    asl_instruction_included BOOLEAN DEFAULT false,
    completion_rate DECIMAL(5,2) DEFAULT 0.00,
    accessibility_score INTEGER DEFAULT 0,
    target_audience TEXT, -- 'deaf-users', 'hearing-users', 'mixed'
    created_by TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- VURI System Metrics Table
CREATE TABLE IF NOT EXISTS vuri_system_metrics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    metric_name TEXT NOT NULL,
    metric_value DECIMAL(10,2) NOT NULL,
    metric_type TEXT NOT NULL, -- 'accessibility', 'performance', 'usage'
    agent_type TEXT,
    measurement_date TIMESTAMPTZ DEFAULT NOW(),
    platform TEXT DEFAULT 'vr4deaf',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_vuri_interactions_user_id ON vuri_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_vuri_interactions_agent_type ON vuri_interactions(agent_type);
CREATE INDEX IF NOT EXISTS idx_vuri_interactions_timestamp ON vuri_interactions(timestamp);
CREATE INDEX IF NOT EXISTS idx_vr_accessibility_audits_score ON vr_accessibility_audits(score);
CREATE INDEX IF NOT EXISTS idx_asl_avatar_configs_dialect ON asl_avatar_configs(asl_dialect);
CREATE INDEX IF NOT EXISTS idx_haptic_patterns_type ON haptic_patterns(pattern_type);
CREATE INDEX IF NOT EXISTS idx_vr_social_spaces_asl_optimized ON vr_social_spaces(asl_optimized);
CREATE INDEX IF NOT EXISTS idx_vr_training_modules_type ON vr_training_modules(training_type);
CREATE INDEX IF NOT EXISTS idx_vuri_system_metrics_type ON vuri_system_metrics(metric_type);

-- Insert sample VURI system metrics
INSERT INTO vuri_system_metrics (metric_name, metric_value, metric_type, agent_type) VALUES
('accessibility_score', 98.0, 'accessibility', 'vr-accessibility'),
('response_time_ms', 1200.0, 'performance', 'asl-avatar'),
('deaf_optimization_rate', 100.0, 'accessibility', 'spatial-audio-visual'),
('user_satisfaction', 96.5, 'usage', 'deaf-social-vr'),
('vr_compatibility', 100.0, 'performance', 'vr-training-deaf'),
('haptic_accuracy', 94.8, 'accessibility', 'haptic-feedback-designer');

-- Create RLS policies for security
ALTER TABLE vuri_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE vr_accessibility_audits ENABLE ROW LEVEL SECURITY;
ALTER TABLE asl_avatar_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE haptic_patterns ENABLE ROW LEVEL SECURITY;
ALTER TABLE vr_social_spaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE vr_training_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE vuri_system_metrics ENABLE ROW LEVEL SECURITY;

-- Grant access to authenticated users
CREATE POLICY "Allow authenticated users to access VURI data" ON vuri_interactions
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to access VR audits" ON vr_accessibility_audits
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to access ASL configs" ON asl_avatar_configs
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to access haptic patterns" ON haptic_patterns
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to access VR social spaces" ON vr_social_spaces
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to access VR training" ON vr_training_modules
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated users to access system metrics" ON vuri_system_metrics
    FOR ALL USING (auth.role() = 'authenticated');
