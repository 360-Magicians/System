import { Monitoring } from "@google-cloud/monitoring"

export class GCPMonitoringClient {
  private monitoring: Monitoring
  private projectId: string

  constructor() {
    this.projectId = process.env.GOOGLE_CLOUD_PROJECT!
    this.monitoring = new Monitoring.MetricServiceClient({
      projectId: this.projectId,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })
  }

  /**
   * Create custom metric for accessibility compliance
   */
  async createAccessibilityMetric(
    metricType: string,
    displayName: string,
    description: string,
    valueType: "DOUBLE" | "INT64" | "BOOL" = "DOUBLE",
  ) {
    try {
      const projectPath = this.monitoring.projectPath(this.projectId)

      const metricDescriptor = {
        type: `custom.googleapis.com/${metricType}`,
        displayName,
        description,
        metricKind: "GAUGE" as const,
        valueType,
        labels: [
          {
            key: "service_name",
            description: "Name of the service being monitored",
          },
          {
            key: "accessibility_category",
            description: "Category of accessibility being measured",
          },
          {
            key: "deaf_optimized",
            description: "Whether the service is deaf-first optimized",
          },
        ],
      }

      const [descriptor] = await this.monitoring.createMetricDescriptor({
        name: projectPath,
        metricDescriptor,
      })

      return {
        success: true,
        metricType: descriptor.type,
        displayName: descriptor.displayName,
      }
    } catch (error) {
      console.error("Failed to create metric:", error)
      throw new Error(`Failed to create metric: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * Write accessibility compliance metric
   */
  async writeAccessibilityMetric(
    metricType: string,
    value: number,
    serviceName: string,
    accessibilityCategory: string,
    deafOptimized = true,
  ) {
    try {
      const projectPath = this.monitoring.projectPath(this.projectId)

      const dataPoint = {
        interval: {
          endTime: {
            seconds: Math.floor(Date.now() / 1000),
          },
        },
        value: {
          doubleValue: value,
        },
      }

      const timeSeries = {
        metric: {
          type: `custom.googleapis.com/${metricType}`,
          labels: {
            service_name: serviceName,
            accessibility_category: accessibilityCategory,
            deaf_optimized: deafOptimized.toString(),
          },
        },
        resource: {
          type: "global",
          labels: {
            project_id: this.projectId,
          },
        },
        points: [dataPoint],
      }

      await this.monitoring.createTimeSeries({
        name: projectPath,
        timeSeries: [timeSeries],
      })

      return {
        success: true,
        metricType,
        value,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to write metric:", error)
      throw new Error(`Failed to write metric: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * Write ASL video processing metrics
   */
  async writeASLVideoMetric(
    processingStage: string,
    successRate: number,
    processingTime: number,
    videoQuality: string,
  ) {
    try {
      const metrics = [
        {
          type: "asl_video_processing_success_rate",
          value: successRate,
          labels: {
            processing_stage: processingStage,
            video_quality: videoQuality,
          },
        },
        {
          type: "asl_video_processing_time",
          value: processingTime,
          labels: {
            processing_stage: processingStage,
            video_quality: videoQuality,
          },
        },
      ]

      const results = await Promise.all(
        metrics.map((metric) =>
          this.writeAccessibilityMetric(metric.type, metric.value, "asl-video-processing", "video_processing", true),
        ),
      )

      return {
        success: true,
        metricsWritten: results.length,
        processingStage,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to write ASL video metrics:", error)
      throw error
    }
  }

  /**
   * Write Vertex AI performance metrics
   */
  async writeVertexAIMetrics(
    agentType: string,
    responseTime: number,
    successRate: number,
    accessibilityScore: number,
    tokensUsed: number,
  ) {
    try {
      const metrics = [
        {
          type: "vertex_ai_response_time",
          value: responseTime,
          category: "performance",
        },
        {
          type: "vertex_ai_success_rate",
          value: successRate,
          category: "reliability",
        },
        {
          type: "vertex_ai_accessibility_score",
          value: accessibilityScore,
          category: "accessibility",
        },
        {
          type: "vertex_ai_tokens_used",
          value: tokensUsed,
          category: "usage",
        },
      ]

      const results = await Promise.all(
        metrics.map((metric) =>
          this.writeAccessibilityMetric(metric.type, metric.value, `vertex-ai-${agentType}`, metric.category, true),
        ),
      )

      return {
        success: true,
        agentType,
        metricsWritten: results.length,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to write Vertex AI metrics:", error)
      throw error
    }
  }

  /**
   * Write deaf community satisfaction metrics
   */
  async writeDeafSatisfactionMetrics(
    featureArea: string,
    satisfactionScore: number,
    accessibilityRating: number,
    aslQualityRating: number,
    userSegment: string,
  ) {
    try {
      const projectPath = this.monitoring.projectPath(this.projectId)

      const timeSeries = [
        {
          metric: {
            type: "custom.googleapis.com/deaf_user_satisfaction",
            labels: {
              feature_area: featureArea,
              user_segment: userSegment,
              metric_type: "satisfaction",
            },
          },
          resource: {
            type: "global",
            labels: { project_id: this.projectId },
          },
          points: [
            {
              interval: { endTime: { seconds: Math.floor(Date.now() / 1000) } },
              value: { doubleValue: satisfactionScore },
            },
          ],
        },
        {
          metric: {
            type: "custom.googleapis.com/deaf_user_satisfaction",
            labels: {
              feature_area: featureArea,
              user_segment: userSegment,
              metric_type: "accessibility",
            },
          },
          resource: {
            type: "global",
            labels: { project_id: this.projectId },
          },
          points: [
            {
              interval: { endTime: { seconds: Math.floor(Date.now() / 1000) } },
              value: { doubleValue: accessibilityRating },
            },
          ],
        },
        {
          metric: {
            type: "custom.googleapis.com/deaf_user_satisfaction",
            labels: {
              feature_area: featureArea,
              user_segment: userSegment,
              metric_type: "asl_quality",
            },
          },
          resource: {
            type: "global",
            labels: { project_id: this.projectId },
          },
          points: [
            {
              interval: { endTime: { seconds: Math.floor(Date.now() / 1000) } },
              value: { doubleValue: aslQualityRating },
            },
          ],
        },
      ]

      await this.monitoring.createTimeSeries({
        name: projectPath,
        timeSeries,
      })

      return {
        success: true,
        featureArea,
        userSegment,
        metricsWritten: 3,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to write satisfaction metrics:", error)
      throw error
    }
  }

  /**
   * Get accessibility compliance dashboard data
   */
  async getAccessibilityDashboard(timeRange: "1h" | "24h" | "7d" | "30d" = "24h") {
    try {
      const projectPath = this.monitoring.projectPath(this.projectId)
      const endTime = Math.floor(Date.now() / 1000)
      const intervals = {
        "1h": 3600,
        "24h": 86400,
        "7d": 604800,
        "30d": 2592000,
      }
      const startTime = endTime - intervals[timeRange]

      // Query accessibility compliance metrics
      const filter = 'metric.type="custom.googleapis.com/accessibility_compliance_score"'

      const request = {
        name: projectPath,
        filter,
        interval: {
          startTime: { seconds: startTime },
          endTime: { seconds: endTime },
        },
        view: "FULL" as const,
      }

      const [timeSeries] = await this.monitoring.listTimeSeries(request)

      const dashboardData = {
        overallCompliance: 0,
        serviceCompliance: {} as Record<string, number>,
        trends: [] as Array<{ timestamp: string; value: number }>,
        alerts: [] as Array<{ service: string; issue: string; severity: string }>,
      }

      // Process time series data
      let totalCompliance = 0
      let serviceCount = 0

      for (const series of timeSeries) {
        const serviceName = series.metric?.labels?.service_name || "unknown"
        const points = series.points || []

        if (points.length > 0) {
          const latestValue = points[0].value?.doubleValue || 0
          dashboardData.serviceCompliance[serviceName] = latestValue
          totalCompliance += latestValue
          serviceCount++

          // Add to trends
          for (const point of points) {
            dashboardData.trends.push({
              timestamp: new Date((point.interval?.endTime?.seconds || 0) * 1000).toISOString(),
              value: point.value?.doubleValue || 0,
            })
          }

          // Check for alerts
          if (latestValue < 0.95) {
            dashboardData.alerts.push({
              service: serviceName,
              issue: `Accessibility compliance below 95% (${(latestValue * 100).toFixed(1)}%)`,
              severity: latestValue < 0.9 ? "critical" : "warning",
            })
          }
        }
      }

      dashboardData.overallCompliance = serviceCount > 0 ? totalCompliance / serviceCount : 0

      return {
        success: true,
        timeRange,
        data: dashboardData,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to get dashboard data:", error)
      throw error
    }
  }

  /**
   * Create alert policy for accessibility compliance
   */
  async createAccessibilityAlert(displayName: string, threshold = 0.95, notificationChannels: string[] = []) {
    try {
      const alertClient = new Monitoring.AlertPolicyServiceClient({
        projectId: this.projectId,
        keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
      })

      const projectPath = alertClient.projectPath(this.projectId)

      const alertPolicy = {
        displayName,
        documentation: {
          content: `Alert when accessibility compliance drops below ${threshold * 100}%`,
          mimeType: "text/markdown",
        },
        conditions: [
          {
            displayName: "Accessibility Compliance Low",
            conditionThreshold: {
              filter: 'metric.type="custom.googleapis.com/accessibility_compliance_score"',
              comparison: "COMPARISON_LT" as const,
              thresholdValue: threshold,
              duration: { seconds: 300 }, // 5 minutes
              aggregations: [
                {
                  alignmentPeriod: { seconds: 60 },
                  perSeriesAligner: "ALIGN_MEAN" as const,
                  crossSeriesReducer: "REDUCE_MEAN" as const,
                },
              ],
            },
          },
        ],
        notificationChannels,
        alertStrategy: {
          autoClose: { seconds: 1800 }, // 30 minutes
        },
        enabled: true,
      }

      const [policy] = await alertClient.createAlertPolicy({
        name: projectPath,
        alertPolicy,
      })

      return {
        success: true,
        policyName: policy.name,
        displayName: policy.displayName,
        threshold,
      }
    } catch (error) {
      console.error("Failed to create alert policy:", error)
      throw error
    }
  }

  /**
   * Health check for monitoring service
   */
  async healthCheck() {
    try {
      const projectPath = this.monitoring.projectPath(this.projectId)

      // Test basic connectivity
      await this.monitoring.listMetricDescriptors({
        name: projectPath,
        pageSize: 1,
      })

      return {
        status: "healthy",
        projectId: this.projectId,
        timestamp: new Date().toISOString(),
        services: {
          monitoring: "connected",
          alerting: "available",
          customMetrics: "enabled",
        },
      }
    } catch (error) {
      return {
        status: "unhealthy",
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      }
    }
  }

  /**
   * Initialize all required metrics for the platform
   */
  async initializePlatformMetrics() {
    try {
      const metrics = [
        {
          type: "accessibility_compliance_score",
          displayName: "Accessibility Compliance Score",
          description: "Overall accessibility compliance score for platform services",
        },
        {
          type: "asl_video_processing_success_rate",
          displayName: "ASL Video Processing Success Rate",
          description: "Success rate of ASL video processing pipeline",
        },
        {
          type: "deaf_user_satisfaction",
          displayName: "Deaf User Satisfaction Score",
          description: "Satisfaction score from deaf community feedback",
        },
        {
          type: "vertex_ai_response_time",
          displayName: "Vertex AI Response Time",
          description: "Response time for Vertex AI agent requests",
        },
        {
          type: "vertex_ai_accessibility_score",
          displayName: "Vertex AI Accessibility Score",
          description: "Accessibility score for AI-generated content",
        },
      ]

      const results = await Promise.allSettled(
        metrics.map((metric) => this.createAccessibilityMetric(metric.type, metric.displayName, metric.description)),
      )

      const successful = results.filter((r) => r.status === "fulfilled").length
      const failed = results.filter((r) => r.status === "rejected").length

      return {
        success: true,
        metricsInitialized: successful,
        metricsFailed: failed,
        totalMetrics: metrics.length,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      console.error("Failed to initialize metrics:", error)
      throw error
    }
  }
}

// Export singleton instance
export const gcpMonitoring = new GCPMonitoringClient()
