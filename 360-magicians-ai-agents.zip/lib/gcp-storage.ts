import { Storage } from "@google-cloud/storage"
import { v4 as uuidv4 } from "uuid"

export class GCPStorageClient {
  private storage: Storage
  private aslVideoBucket: string
  private staticAssetsBucket: string
  private userUploadsBucket: string

  constructor() {
    this.storage = new Storage({
      projectId: process.env.GOOGLE_CLOUD_PROJECT,
      keyFilename: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    })

    this.aslVideoBucket = process.env.ASL_VIDEO_BUCKET || "mbtq-asl-videos"
    this.staticAssetsBucket = process.env.STATIC_ASSETS_BUCKET || "mbtq-static-assets"
    this.userUploadsBucket = process.env.USER_UPLOADS_BUCKET || "mbtq-user-uploads"
  }

  /**
   * Upload ASL video with automatic processing
   */
  async uploadASLVideo(
    fileBuffer: Buffer,
    fileName: string,
    metadata: {
      userId: string
      videoType: "instruction" | "interpretation" | "community"
      duration?: number
      language?: string
      description?: string
    },
  ) {
    try {
      const fileId = uuidv4()
      const processedFileName = `${fileId}-${fileName}`

      const bucket = this.storage.bucket(this.aslVideoBucket)
      const file = bucket.file(`videos/${processedFileName}`)

      // Upload with metadata
      await file.save(fileBuffer, {
        metadata: {
          contentType: "video/mp4",
          cacheControl: "public, max-age=31536000",
          metadata: {
            uploadedBy: metadata.userId,
            videoType: metadata.videoType,
            duration: metadata.duration?.toString() || "unknown",
            language: metadata.language || "ASL",
            description: metadata.description || "",
            processedAt: new Date().toISOString(),
            deafAccessible: "true",
          },
        },
      })

      // Generate signed URL for secure access
      const [signedUrl] = await file.getSignedUrl({
        version: "v4",
        action: "read",
        expires: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
      })

      // Generate thumbnail
      const thumbnailUrl = await this.generateVideoThumbnail(processedFileName)

      return {
        success: true,
        fileId,
        fileName: processedFileName,
        publicUrl: `https://storage.googleapis.com/${this.aslVideoBucket}/videos/${processedFileName}`,
        signedUrl,
        thumbnailUrl,
        metadata: {
          bucket: this.aslVideoBucket,
          size: fileBuffer.length,
          uploadedAt: new Date().toISOString(),
          contentType: "video/mp4",
        },
      }
    } catch (error) {
      console.error("ASL video upload error:", error)
      throw new Error(`Failed to upload ASL video: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * Upload static assets (images, documents)
   */
  async uploadStaticAsset(
    fileBuffer: Buffer,
    fileName: string,
    contentType: string,
    metadata?: Record<string, string>,
  ) {
    try {
      const fileId = uuidv4()
      const processedFileName = `${fileId}-${fileName}`

      const bucket = this.storage.bucket(this.staticAssetsBucket)
      const file = bucket.file(`assets/${processedFileName}`)

      await file.save(fileBuffer, {
        metadata: {
          contentType,
          cacheControl: "public, max-age=31536000",
          metadata: {
            ...metadata,
            uploadedAt: new Date().toISOString(),
            processedBy: "360-magicians-platform",
          },
        },
      })

      return {
        success: true,
        fileId,
        fileName: processedFileName,
        publicUrl: `https://storage.googleapis.com/${this.staticAssetsBucket}/assets/${processedFileName}`,
        cdnUrl: `https://cdn.mbtq.dev/assets/${processedFileName}`,
        metadata: {
          bucket: this.staticAssetsBucket,
          size: fileBuffer.length,
          contentType,
          uploadedAt: new Date().toISOString(),
        },
      }
    } catch (error) {
      console.error("Static asset upload error:", error)
      throw new Error(`Failed to upload static asset: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * Generate video thumbnail using Cloud Video Intelligence API
   */
  private async generateVideoThumbnail(fileName: string): Promise<string> {
    try {
      // This would integrate with Google Cloud Video Intelligence API
      // For now, return a placeholder thumbnail
      const thumbnailFileName = fileName.replace(".mp4", "-thumb.jpg")
      return `https://storage.googleapis.com/${this.aslVideoBucket}/thumbnails/${thumbnailFileName}`
    } catch (error) {
      console.error("Thumbnail generation error:", error)
      return "/placeholder-video-thumb.jpg"
    }
  }

  /**
   * Delete file from storage
   */
  async deleteFile(bucketName: string, fileName: string) {
    try {
      const bucket = this.storage.bucket(bucketName)
      const file = bucket.file(fileName)

      await file.delete()

      return {
        success: true,
        deletedFile: fileName,
        deletedAt: new Date().toISOString(),
      }
    } catch (error) {
      console.error("File deletion error:", error)
      throw new Error(`Failed to delete file: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * List files with filtering
   */
  async listFiles(
    bucketName: string,
    options: {
      prefix?: string
      maxResults?: number
      delimiter?: string
    } = {},
  ) {
    try {
      const bucket = this.storage.bucket(bucketName)
      const [files] = await bucket.getFiles({
        prefix: options.prefix,
        maxResults: options.maxResults || 100,
        delimiter: options.delimiter,
      })

      const fileList = files.map((file) => ({
        name: file.name,
        size: file.metadata.size,
        updated: file.metadata.updated,
        contentType: file.metadata.contentType,
        publicUrl: `https://storage.googleapis.com/${bucketName}/${file.name}`,
      }))

      return {
        success: true,
        files: fileList,
        bucket: bucketName,
        count: fileList.length,
      }
    } catch (error) {
      console.error("File listing error:", error)
      throw new Error(`Failed to list files: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * Get file metadata
   */
  async getFileMetadata(bucketName: string, fileName: string) {
    try {
      const bucket = this.storage.bucket(bucketName)
      const file = bucket.file(fileName)

      const [metadata] = await file.getMetadata()

      return {
        success: true,
        metadata: {
          name: metadata.name,
          size: metadata.size,
          contentType: metadata.contentType,
          updated: metadata.updated,
          created: metadata.timeCreated,
          customMetadata: metadata.metadata,
        },
      }
    } catch (error) {
      console.error("Metadata retrieval error:", error)
      throw new Error(`Failed to get metadata: ${error instanceof Error ? error.message : "Unknown error"}`)
    }
  }

  /**
   * Health check for storage connectivity
   */
  async healthCheck() {
    try {
      // Test connectivity to each bucket
      const buckets = [this.aslVideoBucket, this.staticAssetsBucket, this.userUploadsBucket]
      const results = await Promise.all(
        buckets.map(async (bucketName) => {
          try {
            const bucket = this.storage.bucket(bucketName)
            await bucket.getMetadata()
            return { bucket: bucketName, status: "healthy" }
          } catch (error) {
            return {
              bucket: bucketName,
              status: "unhealthy",
              error: error instanceof Error ? error.message : "Unknown error",
            }
          }
        }),
      )

      const allHealthy = results.every((r) => r.status === "healthy")

      return {
        status: allHealthy ? "healthy" : "degraded",
        buckets: results,
        project: process.env.GOOGLE_CLOUD_PROJECT,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      return {
        status: "unhealthy",
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: new Date().toISOString(),
      }
    }
  }
}

// Export singleton instance
export const gcpStorage = new GCPStorageClient()
