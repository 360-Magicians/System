/**
 * 360 Magicians API Client - Deaf-First Developer SDK
 * Official JavaScript/Node.js SDK for the world's first deaf-first AI platform
 */

import axios, { type AxiosInstance, type AxiosResponse } from "axios"
import WebSocket from "ws"

export interface MagiciansConfig {
  apiKey: string
  baseURL?: string
  timeout?: number
  enableAccessibilityLogging?: boolean
  preferredLanguage?: "asl" | "bsl" | "auslan" | "lsf"
}

export interface CareerMatchingRequest {
  skills: string[]
  experience: string
  accommodations: string[]
  preferences?: string[]
  aslProficiency?: "beginner" | "intermediate" | "advanced" | "native"
}

export interface VRCoordinationRequest {
  clientId: string
  vrAgency: string
  accommodationNeeds: string[]
  aslRequirements: string
  communicationPreference?: "visual" | "tactile" | "mixed"
}

export interface DocumentTranslationRequest {
  documentType: string
  content: string
  targetAudience: "deaf-community" | "general" | "professional"
  accessibilityLevel: "basic" | "high" | "maximum"
  includeASLGlossing?: boolean
}

export interface APIResponse<T = any> {
  success: boolean
  data: T
  requestId: string
  processingTime: string
  accessibilityMetadata?: {
    visualElementsDescribed: boolean
    aslInterpretationAvailable: boolean
    captionsGenerated: boolean
  }
}

export class MagiciansAPI {
  private client: AxiosInstance
  private config: MagiciansConfig
  private wsConnection?: WebSocket

  constructor(config: MagiciansConfig) {
    this.config = {
      baseURL: "https://mbtq.dev/api",
      timeout: 30000,
      enableAccessibilityLogging: true,
      preferredLanguage: "asl",
      ...config,
    }

    this.client = axios.create({
      baseURL: this.config.baseURL,
      timeout: this.config.timeout,
      headers: {
        Authorization: `Bearer ${this.config.apiKey}`,
        "Content-Type": "application/json",
        "X-Client-Version": "1.0.0",
        "X-Accessibility-Mode": "deaf-first",
        "X-Preferred-Language": this.config.preferredLanguage,
      },
    })

    // Add response interceptor for accessibility logging
    this.client.interceptors.response.use(
      (response) => {
        if (this.config.enableAccessibilityLogging) {
          this.logAccessibilityUsage(response)
        }
        return response
      },
      (error) => {
        console.error("360 Magicians API Error:", error.response?.data || error.message)
        return Promise.reject(error)
      },
    )
  }

  /**
   * Career Matching AI - Intelligent pairing of skills, accommodations, and job requirements
   */
  async matchCareer(request: CareerMatchingRequest): Promise<APIResponse> {
    const response = await this.client.post("/agents/career-matching", {
      ...request,
      deafFirstFeatures: {
        visualJobDescriptions: true,
        accommodationCompatibility: true,
        aslWorkplaceSupport: true,
      },
    })
    return response.data
  }

  /**
   * VR Coordination AI - VURA AI integration for VR/AR rehabilitation
   */
  async coordinateVR(request: VRCoordinationRequest): Promise<APIResponse> {
    const response = await this.client.post("/agents/vr-coordination", {
      ...request,
      vuraIntegration: {
        signLanguageModeling: true,
        hapticFeedback: true,
        visualAccessibility: true,
      },
    })
    return response.data
  }

  /**
   * Document Translation AI - Complex document simplification and accessibility
   */
  async translateDocument(request: DocumentTranslationRequest): Promise<APIResponse> {
    const response = await this.client.post("/agents/document-translation", {
      ...request,
      accessibilityEnhancements: {
        plainLanguage: true,
        visualStructure: true,
        screenReaderOptimized: true,
        aslGlossing: request.includeASLGlossing || false,
      },
    })
    return response.data
  }

  /**
   * Interview Prep AI - Accessibility-focused interview preparation
   */
  async prepareInterview(request: {
    jobRole: string
    company: string
    accommodations: string[]
    experienceLevel: string
    practiceMode?: "visual" | "asl" | "mixed"
  }): Promise<APIResponse> {
    const response = await this.client.post("/agents/interview-prep", {
      ...request,
      deafFirstPreparation: {
        visualCues: true,
        accommodationPlanning: true,
        aslPractice: request.practiceMode === "asl" || request.practiceMode === "mixed",
      },
    })
    return response.data
  }

  /**
   * Startup Incubation AI - Resource identification and business model validation
   */
  async incubateStartup(request: {
    businessIdea: string
    targetMarket: string
    accessibilityFocus: string
    founderProfile: {
      isDeaf: boolean
      aslProficiency?: string
      accessibilityExperience: string
    }
  }): Promise<APIResponse> {
    const response = await this.client.post("/agents/startup-incubation", {
      ...request,
      deafEntrepreneurSupport: {
        accessibilityMarketAnalysis: true,
        deafCommunityValidation: true,
        inclusiveBusinessModeling: true,
      },
    })
    return response.data
  }

  /**
   * Real-time streaming for live AI interactions
   */
  async streamAgent(agentType: string, request: any, onMessage: (data: any) => void): Promise<void> {
    const wsUrl = this.config.baseURL?.replace("https://", "wss://").replace("http://", "ws://") + "/stream"

    this.wsConnection = new WebSocket(wsUrl, {
      headers: {
        Authorization: `Bearer ${this.config.apiKey}`,
        "X-Agent-Type": agentType,
        "X-Accessibility-Mode": "deaf-first",
      },
    })

    this.wsConnection.on("open", () => {
      this.wsConnection?.send(
        JSON.stringify({
          type: "request",
          agent: agentType,
          data: request,
          accessibilityOptions: {
            visualFeedback: true,
            hapticAlerts: true,
            aslInterpretation: this.config.preferredLanguage === "asl",
          },
        }),
      )
    })

    this.wsConnection.on("message", (data) => {
      try {
        const message = JSON.parse(data.toString())
        onMessage(message)
      } catch (error) {
        console.error("WebSocket message parsing error:", error)
      }
    })

    this.wsConnection.on("error", (error) => {
      console.error("WebSocket error:", error)
    })
  }

  /**
   * Get API usage statistics with accessibility metrics
   */
  async getUsageStats(): Promise<APIResponse> {
    const response = await this.client.get("/usage/stats")
    return response.data
  }

  /**
   * Health check with accessibility status
   */
  async healthCheck(): Promise<APIResponse> {
    const response = await this.client.get("/health")
    return response.data
  }

  /**
   * Close WebSocket connection
   */
  disconnect(): void {
    if (this.wsConnection) {
      this.wsConnection.close()
      this.wsConnection = undefined
    }
  }

  /**
   * Private method for accessibility usage logging
   */
  private logAccessibilityUsage(response: AxiosResponse): void {
    if (response.data?.accessibilityMetadata) {
      console.log("🌟 Accessibility features used:", response.data.accessibilityMetadata)
    }
  }
}

// Export types for TypeScript users
export * from "./types"

// Default export
export default MagiciansAPI

// Convenience factory function
export function createMagiciansClient(apiKey: string, options?: Partial<MagiciansConfig>): MagiciansAPI {
  return new MagiciansAPI({ apiKey, ...options })
}
