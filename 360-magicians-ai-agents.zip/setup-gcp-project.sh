#!/bin/bash

echo "🚀 SETTING UP GOOGLE CLOUD PROJECT FOR 360 MAGICIANS"
echo "🌟 Creating Production-Ready Infrastructure"

# Set project variables
PROJECT_ID="mbtq-dev-production"
BILLING_ACCOUNT_ID="your-billing-account-id"
REGION="us-central1"

# Create new GCP project
echo "📋 Creating GCP project..."
gcloud projects create $PROJECT_ID \
  --name="MBTQ Dev Production" \
  --set-as-default

# Link billing account
echo "💳 Linking billing account..."
gcloud billing projects link $PROJECT_ID \
  --billing-account=$BILLING_ACCOUNT_ID

# Set default project
gcloud config set project $PROJECT_ID

# Enable required APIs (comprehensive list)
echo "🔧 Enabling all required Google Cloud APIs..."
gcloud services enable \
  aiplatform.googleapis.com \
  cloudbuild.googleapis.com \
  cloudresourcemanager.googleapis.com \
  compute.googleapis.com \
  container.googleapis.com \
  containerregistry.googleapis.com \
  dns.googleapis.com \
  firebase.googleapis.com \
  firestore.googleapis.com \
  iam.googleapis.com \
  logging.googleapis.com \
  monitoring.googleapis.com \
  run.googleapis.com \
  secretmanager.googleapis.com \
  sql-component.googleapis.com \
  storage-component.googleapis.com \
  translate.googleapis.com \
  vision.googleapis.com \
  speech.googleapis.com \
  videointelligence.googleapis.com

# Create service accounts
echo "👤 Creating service accounts..."

# Main application service account
gcloud iam service-accounts create mbtq-app-service \
  --display-name="MBTQ Application Service Account" \
  --description="Service account for MBTQ application"

# Vertex AI service account
gcloud iam service-accounts create mbtq-vertex-ai \
  --display-name="MBTQ Vertex AI Service Account" \
  --description="Service account for Vertex AI operations"

# Storage service account
gcloud iam service-accounts create mbtq-storage \
  --display-name="MBTQ Storage Service Account" \
  --description="Service account for Cloud Storage operations"

# Grant necessary permissions
echo "🔐 Granting IAM permissions..."

# Application service account permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:mbtq-app-service@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/run.invoker"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:mbtq-app-service@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/cloudsql.client"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:mbtq-app-service@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/storage.objectAdmin"

# Vertex AI service account permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:mbtq-vertex-ai@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/aiplatform.user"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:mbtq-vertex-ai@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/ml.developer"

# Storage service account permissions
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:mbtq-storage@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/storage.admin"

# Create service account keys
echo "🔑 Creating service account keys..."
gcloud iam service-accounts keys create ./credentials/mbtq-app-service.json \
  --iam-account=mbtq-app-service@$PROJECT_ID.iam.gserviceaccount.com

gcloud iam service-accounts keys create ./credentials/mbtq-vertex-ai.json \
  --iam-account=mbtq-vertex-ai@$PROJECT_ID.iam.gserviceaccount.com

gcloud iam service-accounts keys create ./credentials/mbtq-storage.json \
  --iam-account=mbtq-storage@$PROJECT_ID.iam.gserviceaccount.com

# Set up Secret Manager for sensitive data
echo "🔒 Setting up Secret Manager..."
echo -n "$(openssl rand -base64 32)" | gcloud secrets create database-password --data-file=-
echo -n "$(openssl rand -base64 32)" | gcloud secrets create jwt-secret --data-file=-
echo -n "$(openssl rand -base64 32)" | gcloud secrets create api-encryption-key --data-file=-

# Create VPC network for secure communication
echo "🌐 Creating VPC network..."
gcloud compute networks create mbtq-vpc \
  --subnet-mode=custom \
  --bgp-routing-mode=regional

gcloud compute networks subnets create mbtq-subnet \
  --network=mbtq-vpc \
  --range=10.0.0.0/24 \
  --region=$REGION

# Set up firewall rules
echo "🔥 Configuring firewall rules..."
gcloud compute firewall-rules create mbtq-allow-internal \
  --network=mbtq-vpc \
  --allow=tcp,udp,icmp \
  --source-ranges=10.0.0.0/24

gcloud compute firewall-rules create mbtq-allow-https \
  --network=mbtq-vpc \
  --allow=tcp:443,tcp:80 \
  --source-ranges=0.0.0.0/0

# Reserve static IP addresses
echo "📍 Reserving static IP addresses..."
gcloud compute addresses create mbtq-api-ip \
  --global

gcloud compute addresses create mbtq-docs-ip \
  --global

gcloud compute addresses create mbtq-community-ip \
  --global

# Set up Cloud Armor security policies
echo "🛡️ Setting up Cloud Armor security policies..."
gcloud compute security-policies create mbtq-security-policy \
  --description="Security policy for MBTQ platform"

# Add DDoS protection
gcloud compute security-policies rules create 1000 \
  --security-policy=mbtq-security-policy \
  --expression="true" \
  --action=rate-based-ban \
  --rate-limit-threshold-count=100 \
  --rate-limit-threshold-interval-sec=60 \
  --ban-duration-sec=600

# Add geo-blocking for known bad actors
gcloud compute security-policies rules create 2000 \
  --security-policy=mbtq-security-policy \
  --expression="origin.region_code == 'CN' || origin.region_code == 'RU'" \
  --action=deny-403

# Initialize Firebase for real-time features
echo "🔥 Initializing Firebase..."
firebase projects:addfirebase $PROJECT_ID
firebase use $PROJECT_ID

# Set up Cloud Monitoring workspace
echo "📊 Setting up Cloud Monitoring..."
gcloud alpha monitoring workspaces create \
  --display-name="MBTQ Dev Monitoring"

# Create notification channels
gcloud alpha monitoring channels create \
  --display-name="Deaf Dev Team Email" \
  --type=email \
  --channel-labels=email_address=alerts@vr4deaf.org

# Set up Cloud Logging sinks
echo "📝 Setting up Cloud Logging..."
gcloud logging sinks create mbtq-accessibility-logs \
  bigquery.googleapis.com/projects/$PROJECT_ID/datasets/accessibility_logs \
  --log-filter='jsonPayload.accessibilityCompliant=true'

# Create BigQuery dataset for analytics
echo "📈 Setting up BigQuery for analytics..."
bq mk --dataset --location=US $PROJECT_ID:accessibility_logs
bq mk --dataset --location=US $PROJECT_ID:user_analytics
bq mk --dataset --location=US $PROJECT_ID:api_metrics

echo ""
echo "🎉 GCP PROJECT SETUP COMPLETE!"
echo "📋 Project ID: $PROJECT_ID"
echo "🌍 Region: $REGION"
echo "🔐 Service accounts created with keys in ./credentials/"
echo "🔒 Secrets stored in Secret Manager"
echo "🌐 VPC network configured"
echo "🛡️ Security policies active"
echo "🔥 Firebase initialized"
echo "📊 Monitoring and logging configured"
echo ""
echo "🚀 Ready to deploy 360 Magicians Deaf-First Platform!"
echo "Next step: Run ./deploy-gcp.sh"
