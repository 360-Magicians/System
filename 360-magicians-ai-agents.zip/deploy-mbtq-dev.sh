#!/bin/bash

echo "🚀 DEPLOYING DEAF-FIRST DEVELOPER ECOSYSTEM TO mbtq.dev"
echo "🌟 World's First Accessible Developer Platform"

# Set environment variables
export VERCEL_ORG_ID="team_mbtq"
export VERCEL_PROJECT_ID="mbtq-dev-api"

# Deploy main API hub
echo "📦 Deploying mbtq.dev API Hub..."
vercel --prod --domain mbtq.dev --project-name mbtq-dev-api

# Deploy documentation site
echo "📚 Deploying docs.mbtq.dev..."
vercel --prod --domain docs.mbtq.dev --project-name mbtq-docs

# Deploy community forum
echo "👥 Deploying community.mbtq.dev..."
vercel --prod --domain community.mbtq.dev --project-name mbtq-community

# Deploy SDK playground
echo "🛠️ Deploying playground.mbtq.dev..."
vercel --prod --domain playground.mbtq.dev --project-name mbtq-playground

# Deploy developer onboarding
echo "🎯 Deploying onboard.mbtq.dev..."
vercel --prod --domain onboard.mbtq.dev --project-name mbtq-onboard

# Setup DNS and SSL
echo "🌐 Configuring DNS and SSL..."
vercel domains add mbtq.dev
vercel domains add docs.mbtq.dev
vercel domains add community.mbtq.dev
vercel domains add playground.mbtq.dev
vercel domains add onboard.mbtq.dev

# Verify all deployments
echo "✅ Verifying deployments..."
curl -f https://mbtq.dev/api/health || exit 1
curl -f https://docs.mbtq.dev/api/health || exit 1
curl -f https://community.mbtq.dev/api/health || exit 1
curl -f https://playground.mbtq.dev/api/health || exit 1
curl -f https://onboard.mbtq.dev/api/health || exit 1

# Setup monitoring
echo "📊 Setting up monitoring..."
curl -X POST https://api.uptimerobot.com/v2/newMonitor \
  -d "api_key=$UPTIMEROBOT_API_KEY" \
  -d "format=json" \
  -d "type=1" \
  -d "url=https://mbtq.dev/api/health" \
  -d "friendly_name=MBTQ Dev API"

echo "🎉 DEPLOYMENT COMPLETE!"
echo "🌟 Main API: https://mbtq.dev"
echo "📚 Docs: https://docs.mbtq.dev"
echo "👥 Community: https://community.mbtq.dev"
echo "🛠️ Playground: https://playground.mbtq.dev"
echo "🎯 Onboarding: https://onboard.mbtq.dev"
echo ""
echo "🚀 DEAF-FIRST DEVELOPER ECOSYSTEM IS LIVE!"
