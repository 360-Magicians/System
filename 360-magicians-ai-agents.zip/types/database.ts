export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export type Database = {
  public: {
    Tables: {
      ai_agent_results: {
        Row: {
          id: string
          user_id: string
          agent_type: string
          request_payload: Json
          result_data: Json
          success: boolean
          processing_time: number
          accessibility_score: number
          deaf_optimized: boolean
          asl_compatible: boolean
          visual_first: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          agent_type: string
          request_payload: Json
          result_data: Json
          success?: boolean
          processing_time?: number
          accessibility_score?: number
          deaf_optimized?: boolean
          asl_compatible?: boolean
          visual_first?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          agent_type?: string
          request_payload?: Json
          result_data?: Json
          success?: boolean
          processing_time?: number
          accessibility_score?: number
          deaf_optimized?: boolean
          asl_compatible?: boolean
          visual_first?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      chat_interactions: {
        Row: {
          id: string
          user_id: string
          agent_type: string
          user_message: string
          ai_response: string
          metadata: Json
          accessibility_score: number
          deaf_optimized: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          agent_type: string
          user_message: string
          ai_response: string
          metadata?: Json
          accessibility_score?: number
          deaf_optimized?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          agent_type?: string
          user_message?: string
          ai_response?: string
          metadata?: Json
          accessibility_score?: number
          deaf_optimized?: boolean
          created_at?: string
        }
      }
      user_profiles: {
        Row: {
          id: string
          user_id: string
          full_name: string | null
          email: string
          role: string
          deaf_community_member: boolean
          asl_proficiency: string | null
          accessibility_preferences: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          full_name?: string | null
          email: string
          role?: string
          deaf_community_member?: boolean
          asl_proficiency?: string | null
          accessibility_preferences?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          full_name?: string | null
          email?: string
          role?: string
          deaf_community_member?: boolean
          asl_proficiency?: string | null
          accessibility_preferences?: Json
          created_at?: string
          updated_at?: string
        }
      }
      accessibility_compliance: {
        Row: {
          id: string
          service_name: string
          compliance_score: number
          deaf_accessible: boolean
          asl_supported: boolean
          visual_indicators: boolean
          screen_reader_compatible: boolean
          tested_at: string
          test_results: Json
        }
        Insert: {
          id?: string
          service_name: string
          compliance_score: number
          deaf_accessible?: boolean
          asl_supported?: boolean
          visual_indicators?: boolean
          screen_reader_compatible?: boolean
          tested_at?: string
          test_results?: Json
        }
        Update: {
          id?: string
          service_name?: string
          compliance_score?: number
          deaf_accessible?: boolean
          asl_supported?: boolean
          visual_indicators?: boolean
          screen_reader_compatible?: boolean
          tested_at?: string
          test_results?: Json
        }
      }
      deaf_community_feedback: {
        Row: {
          id: string
          user_id: string
          feature_area: string
          satisfaction_score: number
          accessibility_rating: number
          asl_quality_rating: number
          user_segment: string
          feedback_text: string | null
          suggestions: Json
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          feature_area: string
          satisfaction_score: number
          accessibility_rating: number
          asl_quality_rating: number
          user_segment: string
          feedback_text?: string | null
          suggestions?: Json
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          feature_area?: string
          satisfaction_score?: number
          accessibility_rating?: number
          asl_quality_rating?: number
          user_segment?: string
          feedback_text?: string | null
          suggestions?: Json
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_top_performing_agents: {
        Args: {
          p_limit: number
          p_days: number
        }
        Returns: {
          agent_type: string
          success_rate: number
          avg_processing_time: number
          avg_accessibility_score: number
          total_requests: number
        }[]
      }
      update_vertex_ai_metrics: {
        Args: {
          p_model_name: string
          p_agent_type: string
          p_success: boolean
          p_response_time: number
          p_tokens_processed: number
        }
        Returns: void
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
